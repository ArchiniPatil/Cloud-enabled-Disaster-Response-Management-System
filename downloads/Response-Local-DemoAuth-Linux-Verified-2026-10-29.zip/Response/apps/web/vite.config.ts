import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { localRequestOnly } from "../../packages/core/src/local-access.js";
export default defineConfig({
  plugins: [
    {
      name: "local-development-access",
      configureServer(server) {
        server.middlewares.use((req, res, next) =>
          localRequestOnly(req, res, next, { allowOAuthNavigation: true }),
        );
      },
      configurePreviewServer(server) {
        server.middlewares.use((req, res, next) =>
          localRequestOnly(req, res, next, { allowOAuthNavigation: true }),
        );
      },
    },
    react(),
  ],
  server: {
    host: "127.0.0.1",
    port: 5173,
    strictPort: true,
    proxy: { "/api": "http://127.0.0.1:4000" },
  },
  preview: { host: "127.0.0.1", strictPort: true },
  build: { chunkSizeWarningLimit: 900 },
});

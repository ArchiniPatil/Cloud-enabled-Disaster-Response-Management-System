import { describe, expect, it } from "vitest";
import type { IncomingMessage, ServerResponse } from "node:http";
import {
  isLoopbackPeer,
  isLoopbackHost,
  localRequestOnly,
} from "../packages/core/src/local-access";

// Preserve the uploaded repair's helper coverage against the shared guard
// actually used by both API and Vite, rather than a second unused helper.
function allowed(peer: string, headers: Record<string, string>) {
  let proceeded = false;
  localRequestOnly(
    {
      socket: { remoteAddress: peer },
      headers,
      rawHeaders: Object.entries(headers).flat(),
    } as unknown as IncomingMessage,
    { writeHead() {}, end() {} } as unknown as ServerResponse,
    () => {
      proceeded = true;
    },
  );
  return proceeded;
}

describe("uploaded repair metadata coverage on the active security boundary", () => {
  it.each(["127.0.0.1", "127.23.4.5", "::1", "::ffff:127.0.0.1"])(
    "recognizes loopback peer %s",
    (peer) => {
      expect(isLoopbackPeer(peer)).toBe(true);
    },
  );
  it.each(["192.168.1.4", "10.0.0.2", "::ffff:192.168.1.4", "203.0.113.8", ""])(
    "rejects non-loopback peer %s",
    (peer) => {
      expect(isLoopbackPeer(peer)).toBe(false);
    },
  );
  it.each(["localhost:5173", "127.0.0.1:4000", "[::1]:5173"])(
    "accepts local Host %s",
    (host) => {
      expect(isLoopbackHost(host)).toBe(true);
    },
  );
  it.each([
    "example.com",
    "attacker.example:5173",
    "localhost.evil",
    "127.0.0.1.evil",
    "localhost:abc",
    "localhost,attacker.example",
  ])("rejects unsafe Host %s", (host) => {
    expect(isLoopbackHost(host)).toBe(false);
  });
  it.each([
    "x-forwarded-for",
    "x-forwarded-host",
    "forwarded",
    "x-real-ip",
    "via",
    "x-original-host",
    "x-original-url",
    "x-rewrite-url",
  ])("rejects forwarding metadata %s", (header) => {
    expect(
      allowed("127.0.0.1", { host: "localhost:4000", [header]: "127.0.0.1" }),
    ).toBe(false);
  });
  it("allows a direct localhost request with a valid local origin", () => {
    expect(
      allowed("::ffff:127.0.0.1", {
        host: "localhost:4000",
        origin: "http://localhost:5173",
      }),
    ).toBe(true);
  });
  it("rejects a remote peer even with local Host and Origin", () => {
    expect(
      allowed("192.168.1.20", {
        host: "localhost:4000",
        origin: "http://localhost:5173",
      }),
    ).toBe(false);
  });
  it("rejects spoofed forwarding headers on an otherwise local request", () => {
    expect(
      allowed("127.0.0.1", {
        host: "localhost:4000",
        origin: "http://localhost:5173",
        "x-forwarded-for": "203.0.113.9",
      }),
    ).toBe(false);
  });
  it("rejects an invalid origin on an otherwise local request", () => {
    expect(
      allowed("127.0.0.1", {
        host: "localhost:4000",
        origin: "https://attacker.example",
      }),
    ).toBe(false);
  });
});

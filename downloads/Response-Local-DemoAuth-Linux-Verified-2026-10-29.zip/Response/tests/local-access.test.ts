import { afterAll, beforeAll, expect, it } from "vitest";
import {
  createServer,
  request as httpRequest,
  type IncomingMessage,
} from "node:http";
import type { AddressInfo } from "node:net";
import { execFileSync, spawnSync } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve, join } from "node:path";
import {
  createServer as viteServer,
  loadConfigFromFile,
  preview,
  type Plugin,
} from "vite";
import { app } from "../apps/api/src/app";
import { config } from "../apps/api/src/config";
import { pool } from "../apps/api/src/db";
import { hash } from "../apps/api/src/auth";
import { migrate } from "../scripts/migrations";
import {
  isLoopbackPeer,
  localRequestOnly,
} from "../packages/core/src/local-access";
import type { ServerResponse } from "node:http";

// Test-only transport simulation. Every actual listener binds to 127.0.0.1.
// Never add this injection middleware or its header to application code.
function simulatePeer(req: IncomingMessage) {
  const peer = req.headers["x-test-socket-peer"];
  if (typeof peer === "string") {
    Object.defineProperty(req.socket, "remoteAddress", { value: peer });
    delete req.headers["x-test-socket-peer"];
  }
}
const api = createServer((req, res) => {
  simulatePeer(req);
  app(req, res);
});
let base: string;
const frontends: { mode: string; base: string; close: () => Promise<void> }[] =
  [];
let temporary: string;
function getPort(server: { address(): unknown }) {
  return (server.address() as AddressInfo).port;
}
function call(
  target: string,
  path: string,
  headers: Record<string, string | undefined> = {},
  body?: object,
  method = body ? "POST" : "GET",
) {
  return new Promise<{ status: number; body: any; cookie?: string }>(
    (resolve, reject) => {
      const req = httpRequest(
        target + path,
        {
          method,
          agent: false,
          headers: { "Content-Type": "application/json", ...headers },
        },
        (res) => {
          let text = "";
          res.on("data", (data) => {
            text += data;
          });
          res.on("end", () =>
            resolve({
              status: res.statusCode!,
              body: res.headers["content-type"]?.includes("application/json")
                ? JSON.parse(text)
                : text,
              cookie: res.headers["set-cookie"]?.[0]?.split(";")[0],
            }),
          );
        },
      );
      req.on("error", reject);
      req.end(body ? JSON.stringify(body) : undefined);
    },
  );
}
const origin = "http://localhost:5173";
const adminLogin = (
  target = base,
  headers: Record<string, string | undefined> = {},
) =>
  call(
    target,
    "/api/v1/auth/demo",
    { Origin: origin, ...headers },
    { email: "admin@demo.invalid" },
  );
beforeAll(async () => {
  if (!new URL(process.env.DATABASE_URL!).pathname.endsWith("_test"))
    throw new Error("Dedicated _test database required");
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public");
  await migrate();
  execFileSync(process.execPath, ["--import", "tsx", "scripts/seed.ts"], {
    env: process.env,
    stdio: "pipe",
  });
  await new Promise<void>((resolve) => api.listen(0, "127.0.0.1", resolve));
  base = `http://127.0.0.1:${getPort(api)}`;
  temporary = await mkdtemp(join(tmpdir(), "response-auth-preview-"));
  await writeFile(
    join(temporary, "index.html"),
    "<html>Local preview fixture</html>",
  );
  for (const mode of ["dev", "preview"]) {
    const injection: Plugin = {
      name: "test-only-socket-peer",
      enforce: "pre",
      configureServer(server) {
        server.middlewares.use((req, _res, next) => {
          simulatePeer(req);
          next();
        });
      },
      configurePreviewServer(server) {
        server.middlewares.use((req, _res, next) => {
          simulatePeer(req);
          next();
        });
      },
    };
    const settings = {
      configFile: resolve("apps/web/vite.config.ts"),
      root: resolve("apps/web"),
      plugins: [injection],
      logLevel: "silent" as const,
      server: { host: "127.0.0.1", port: 0, proxy: { "/api": base } },
      preview: { host: "127.0.0.1", port: 0, proxy: { "/api": base } },
      build: { outDir: temporary },
    };
    if (mode === "dev") {
      const server = await viteServer(settings);
      await server.listen();
      frontends.push({
        mode,
        base: `http://127.0.0.1:${getPort(server.httpServer!)}`,
        close: () => server.close(),
      });
    } else {
      const server = await preview(settings);
      frontends.push({
        mode,
        base: `http://127.0.0.1:${getPort(server.httpServer)}`,
        close: () => server.close(),
      });
    }
  }
});
afterAll(async () => {
  for (const frontend of frontends) await frontend.close();
  if (api.listening)
    await new Promise<void>((resolve, reject) =>
      api.close((error) => (error ? reject(error) : resolve())),
    );
  if (temporary) await rm(temporary, { recursive: true, force: true });
  await pool.end();
});

it.each(["localhost", "127.0.0.1"])(
  "allows legitimate local Admin login, reads and logout via %s",
  async (host) => {
    const login = await adminLogin(base, {
      Host: host,
      Origin: `http://${host}:5173`,
    });
    expect(login.status).toBe(200);
    expect(login.cookie).toBeTruthy();
    const headers = { Cookie: login.cookie! };
    const me = await call(base, "/api/v1/auth/me", headers);
    expect(me.status).toBe(200);
    expect(me.body.user.role).toBe("ADMIN");
    expect((await call(base, "/api/v1/admin/users", headers)).status).toBe(200);
    expect(
      (
        await call(
          base,
          "/api/v1/auth/logout",
          { ...headers, Origin: origin, "X-CSRF-Token": me.body.csrf },
          {},
        )
      ).status,
    ).toBe(200);
    expect((await call(base, "/api/v1/auth/me", headers)).status).toBe(401);
  },
);
it.each(["203.0.113.8", "::ffff:192.0.2.9", "2001:db8::1"])(
  "rejects socket peer %s even with forged local headers",
  async (peer) => {
    const count = Number(
      (await pool.query("SELECT count(*) FROM sessions")).rows[0].count,
    );
    const denied = await adminLogin(base, {
      Host: "localhost",
      "x-test-socket-peer": peer,
    });
    expect(denied.status).toBe(403);
    expect(denied.cookie).toBeUndefined();
    expect(
      Number((await pool.query("SELECT count(*) FROM sessions")).rows[0].count),
    ).toBe(count);
  },
);
it("rejects non-loopback reuse and renewal of an existing Admin cookie before database changes", async () => {
  const login = await adminLogin();
  const id = hash(login.cookie!.split("=")[1]);
  await pool.query(
    "UPDATE sessions SET access_expires=now()-interval '1 second' WHERE id_hash=$1",
    [id],
  );
  const before = (
    await pool.query("SELECT access_expires FROM sessions WHERE id_hash=$1", [
      id,
    ])
  ).rows[0];
  const headers = {
    Cookie: login.cookie!,
    Host: "localhost",
    "x-test-socket-peer": "198.51.100.4",
  };
  for (const path of [
    "/api/v1/auth/me",
    "/api/v1/admin/users",
    "/api/v1/incidents",
  ])
    expect((await call(base, path, headers)).status).toBe(403);
  expect(
    (
      await pool.query("SELECT access_expires FROM sessions WHERE id_hash=$1", [
        id,
      ])
    ).rows[0],
  ).toEqual(before);
  expect(
    (await call(base, "/api/v1/auth/me", { Cookie: login.cookie! })).status,
  ).toBe(200);
});
it.each([
  "Forwarded",
  "X-Forwarded-For",
  "X-Forwarded-Host",
  "X-Forwarded-Proto",
  "Via",
  "X-Real-IP",
  "CF-Connecting-IP",
  "True-Client-IP",
  "Fastly-Client-IP",
  "X-Original-Host",
  "X-Original-URL",
  "X-Rewrite-URL",
])("rejects spoofed %s even when it claims loopback", async (name) => {
  const login = await adminLogin();
  const headers = { [name]: "127.0.0.1", Cookie: login.cookie! };
  expect((await adminLogin(base, headers)).status).toBe(403);
  expect((await call(base, "/api/v1/admin/users", headers)).status).toBe(403);
});
it.each([
  { Host: "public-tunnel.example", Origin: origin },
  { Host: "localhost.attacker.example", Origin: origin },
  { Host: "localhost.", Origin: origin },
  { Host: "localhost", Origin: "https://attacker.example" },
  { Host: "localhost", Origin: "null" },
  { Host: "localhost", Origin: "http://localhost:5173/path" },
  { Host: "localhost", Origin: origin, "Sec-Fetch-Site": "cross-site" },
])("rejects invalid Host/Origin/site metadata %#", async (headers) => {
  expect((await adminLogin(base, headers)).status).toBe(403);
  expect((await call(base, "/api/v1/auth/config", headers)).status).toBe(403);
  expect(
    (await call(base, "/api/v1/auth/demo", headers, undefined, "OPTIONS"))
      .status,
  ).toBe(403);
});
it.each(["dev", "preview"])(
  "protects the real Vite %s proxy and preserves local login",
  async (mode) => {
    const target = frontends.find((f) => f.mode === mode)!.base;
    const login = await adminLogin(target);
    expect(login.status).toBe(200);
    expect(
      (await call(target, "/api/v1/admin/users", { Cookie: login.cookie! }))
        .status,
    ).toBe(200);
    for (const headers of [
      { "x-test-socket-peer": "203.0.113.4", Host: "localhost" },
      { "X-Forwarded-For": "127.0.0.1" },
      { "X-Original-Host": "localhost" },
      { "X-Original-URL": "/api/v1/auth/demo" },
      { "X-Rewrite-URL": "/api/v1/auth/demo" },
      { Host: "public-tunnel.example" },
      { Origin: "https://attacker.example" },
    ]) {
      expect((await adminLogin(target, headers)).status).toBe(403);
      expect(
        (
          await call(target, "/api/v1/admin/users", {
            ...headers,
            Cookie: login.cookie!,
          })
        ).status,
      ).toBe(403);
    }
  },
);
it("rejects an unexpired fixture Admin session when switched to Cognito", async () => {
  const login = await adminLogin();
  config.AUTH_MODE = "cognito";
  try {
    expect(
      (await call(base, "/api/v1/auth/me", { Cookie: login.cookie! })).status,
    ).toBe(401);
    expect(
      (await call(base, "/api/v1/admin/users", { Cookie: login.cookie! }))
        .status,
    ).toBe(401);
    expect((await adminLogin()).status).toBe(404);
  } finally {
    config.AUTH_MODE = "demo";
  }
});
it("rejects fixture sessions in Cognito even if their profile subject was changed", async () => {
  const login = await adminLogin();
  const user = (
    await pool.query(
      "SELECT id,cognito_sub FROM user_profiles WHERE email='admin@demo.invalid'",
    )
  ).rows[0];
  await pool.query(
    "UPDATE user_profiles SET cognito_sub='changed-subject-for-test' WHERE id=$1",
    [user.id],
  );
  config.AUTH_MODE = "cognito";
  try {
    expect(
      (await call(base, "/api/v1/admin/users", { Cookie: login.cookie! }))
        .status,
    ).toBe(401);
  } finally {
    config.AUTH_MODE = "demo";
    await pool.query("UPDATE user_profiles SET cognito_sub=$2 WHERE id=$1", [
      user.id,
      user.cognito_sub,
    ]);
  }
});
it("uses socket identity even if Express trust proxy is enabled", async () => {
  const previous = app.get("trust proxy");
  app.set("trust proxy", true);
  try {
    expect(
      (
        await adminLogin(base, {
          "x-test-socket-peer": "192.0.2.8",
          "X-Forwarded-For": "127.0.0.1",
        })
      ).status,
    ).toBe(403);
  } finally {
    app.set("trust proxy", previous);
  }
});
it("rejects duplicate/missing Host and unknown socket peers before proceeding", () => {
  for (const [peer, rawHeaders] of [
    [undefined, ["Host", "localhost"]],
    ["127.0.0.1", []],
    ["127.0.0.1", ["Host", "localhost", "hOsT", "localhost"]],
  ] as const) {
    let status: number | undefined;
    let proceeded = false;
    localRequestOnly(
      {
        socket: { remoteAddress: peer },
        headers: { host: "localhost" },
        rawHeaders,
      } as unknown as IncomingMessage,
      {
        writeHead(code: number) {
          status = code;
        },
        end() {},
      } as unknown as ServerResponse,
      () => {
        proceeded = true;
      },
    );
    expect(status).toBe(403);
    expect(proceeded).toBe(false);
  }
  for (const peer of ["127.0.0.1", "::1", "::ffff:127.0.0.1"])
    expect(isLoopbackPeer(peer)).toBe(true);
});
it("binds Vite dev and preview to IPv4 loopback without a wildcard npm override", async () => {
  const loaded = await loadConfigFromFile(
    { command: "serve", mode: "development" },
    resolve("apps/web/vite.config.ts"),
  );
  expect(loaded!.config.server!.host).toBe("127.0.0.1");
  expect(loaded!.config.preview!.host).toBe("127.0.0.1");
  const manifest = JSON.parse(await readFile("apps/web/package.json", "utf8"));
  expect(manifest.scripts.dev).toBe("vite");
});
it("does not accept OAuth callbacks in demo mode", async () => {
  expect(
    (await call(base, "/api/v1/auth/callback?state=unused&code=unused")).status,
  ).toBe(404);
});
it("preserves local Cognito callback navigation without allowing demo or remote access", async () => {
  const path = "/api/v1/auth/callback?state=local-test&code=local-test";
  const headers = {
    "Sec-Fetch-Site": "cross-site",
    "Sec-Fetch-Mode": "navigate",
  };
  for (const frontend of frontends) {
    expect((await call(frontend.base, path, headers)).status).toBe(403);
    config.AUTH_MODE = "cognito";
    try {
      const result = await call(frontend.base, path, headers);
      expect(result.status).toBe(400);
      expect(result.body.error.code).toBe("OAUTH_STATE");
      expect(
        (
          await call(frontend.base, path, {
            ...headers,
            "x-test-socket-peer": "192.0.2.8",
          })
        ).status,
      ).toBe(403);
    } finally {
      config.AUTH_MODE = "demo";
    }
  }
});
it("does not issue fixture login for a real identity sharing a fixture email", async () => {
  const user = (
    await pool.query(
      "SELECT id,cognito_sub FROM user_profiles WHERE email='admin@demo.invalid'",
    )
  ).rows[0];
  await pool.query(
    "UPDATE user_profiles SET cognito_sub='real-identity-for-local-test' WHERE id=$1",
    [user.id],
  );
  try {
    expect((await adminLogin()).status).toBe(503);
  } finally {
    await pool.query("UPDATE user_profiles SET cognito_sub=$2 WHERE id=$1", [
      user.id,
      user.cognito_sub,
    ]);
  }
});
it.each([
  {
    NODE_ENV: "production",
    APP_ORIGIN: "https://app.example.com",
    API_ORIGIN: "https://api.example.com",
    SESSION_KEY: "not-used-by-this-demo-rejection-test",
  },
  { APP_ORIGIN: "https://public.example.com" },
  { API_ORIGIN: "https://public.example.com" },
  { APP_ORIGIN: "http://localhost:5173/path" },
])("rejects unsafe fixture startup configuration %#", (overrides) => {
  const result = spawnSync(
    process.execPath,
    [
      "--import",
      "tsx",
      "--input-type=module",
      "-e",
      "await import('./apps/api/src/config.ts')",
    ],
    {
      env: { ...process.env, ...overrides, AUTH_MODE: "demo" },
      encoding: "utf8",
    },
  );
  expect(result.status).toBe(1);
  expect(result.stderr).toMatch(
    /Production requires Cognito|Demo authentication requires/,
  );
});

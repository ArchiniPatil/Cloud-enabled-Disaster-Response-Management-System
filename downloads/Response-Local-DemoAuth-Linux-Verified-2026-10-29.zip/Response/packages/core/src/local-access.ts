import type { IncomingMessage, ServerResponse } from "node:http";
import { isIP } from "node:net";

export function isLoopbackPeer(address: string | undefined) {
  const ipv4 = address?.toLowerCase().replace(/^::ffff:/, "");
  return (
    address === "::1" ||
    (ipv4 !== undefined && isIP(ipv4) === 4 && ipv4.startsWith("127."))
  );
}

export function isLoopbackHost(host: string | undefined) {
  const match = host?.match(
    /^(localhost|127\.0\.0\.1|\[::1\])(?::([0-9]{1,5}))?$/i,
  );
  return (
    !!match &&
    (!match[2] || (Number(match[2]) >= 1 && Number(match[2]) <= 65535))
  );
}

export function isLoopbackOrigin(origin: string) {
  try {
    const url = new URL(origin);
    return (
      ["http:", "https:"].includes(url.protocol) &&
      url.origin === origin &&
      isLoopbackHost(url.host)
    );
  } catch {
    return false;
  }
}

// Check the real transport socket, never req.ip/trust-proxy or claimed headers.
// Apply before a proxy, CORS preflight, login and session/cookie authentication.
export function localRequestOnly(
  req: IncomingMessage,
  res: ServerResponse,
  next: () => void,
  options: { allowOAuthNavigation?: boolean } = {},
) {
  const forwarded = Object.keys(req.headers).some(
    (name) =>
      name === "forwarded" ||
      name.startsWith("x-forwarded-") ||
      [
        "via",
        "x-real-ip",
        "x-original-host",
        "x-original-url",
        "x-rewrite-url",
        "cf-connecting-ip",
        "true-client-ip",
        "fastly-client-ip",
      ].includes(name),
  );
  const hostCount = req.rawHeaders.filter(
    (value, index) => index % 2 === 0 && value.toLowerCase() === "host",
  ).length;
  // Cognito returns to local Vite as a cross-site top-level GET. This narrow
  // exception never skips socket/Host/Origin/proxy checks. The demo API does
  // not enable it; Cognito still validates OAuth state, PKCE and signed tokens.
  const oauthNavigation =
    options.allowOAuthNavigation === true &&
    req.method === "GET" &&
    req.url?.split("?")[0] === "/api/v1/auth/callback" &&
    req.headers["sec-fetch-mode"] === "navigate";
  if (
    !isLoopbackPeer(req.socket.remoteAddress) ||
    hostCount !== 1 ||
    !isLoopbackHost(req.headers.host) ||
    forwarded ||
    (req.headers.origin !== undefined &&
      !isLoopbackOrigin(req.headers.origin)) ||
    (req.headers["sec-fetch-site"] === "cross-site" && !oauthNavigation)
  ) {
    res.writeHead(403, {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    });
    res.end(
      JSON.stringify({
        error: {
          code: "LOCAL_ACCESS_ONLY",
          message:
            "Local development requires a direct loopback connection. Proxies and tunnels are not supported.",
        },
      }),
    );
    return;
  }
  next();
}

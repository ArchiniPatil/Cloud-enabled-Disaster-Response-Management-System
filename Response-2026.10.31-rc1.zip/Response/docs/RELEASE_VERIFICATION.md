# Task 4 release candidate review — 31 October 2026

Version: **2026.10.31-rc1**, Linux local verification. This is a complete source release candidate for Tasks 1–3, not a live deployment or emergency-operational approval. The authoritative source is the preserved `work` working tree over `eb9e622e5c09fce799509efd90cf1984f8587c72`; that base commit alone does not contain these fixes. A source backup and starting diff were saved before Task 4. No migrations 001–008 or dependency lockfiles were changed in Task 4.

## Verification evidence

Environment: Linux x86_64, Node 24.19.0/npm 11.9.0, PostgreSQL 16/PostGIS 3.5 and local Chromium. The rebuilt Docker runtime uses Node 22 on Debian bookworm, nonroot `node`. No Windows paths were accessed or modified. No AWS CLI, deployment, resource, IAM or notification operation was performed. Offline synthesis used no account credentials/lookups. Provider contracts in tests use explicit SDK stubs.

| Check | Current workspace result |
|---|---|
| Tasks 1–3 and schema provenance | PASS: fixture guards, production validation, schema readiness, workflow/GPS/resource fixes present; all eight migration hashes match the contract (496 schema objects). |
| Focused security/readiness/workflow suite | PASS: **219/219**, six files, 67.87s, no skips. |
| Full suite | PASS: **272/272**, eight files, 57.96s, no skips. |
| Chromium browser suite | PASS: **21/21**, 2.8m; separate local database, synthetic browser geolocation. |
| TypeScript, lint, production build | PASS: exit 0 each; unchanged large MapLibre chunk warning. |
| Clean install / upgrade / least-privilege role | PASS within the full suite: clean 001–008; representative populated pre-008 upgrade/backfill and repeated migration; restricted runtime writes and rejected audit/schema mutation. No live RDS snapshot restoration claimed. |
| Worker retry, concurrency and restart | PASS within full suite: persisted deadlines/escalation, transaction rollback/retry, notification dedupe and new worker process. Provider failures are stubs. |
| Offline infrastructure | PASS: academic, reference and optional receipt variants each synthesized and passed assertions (three variants). Existing CDK deprecation/feature-flag notices remain. |
| Dependency advisory check | PASS at configured high-severity threshold; **two moderate findings**, `aws-cdk-lib` / nested `minimatch`, GHSA-g3hv-75wg-m249, no fix available in this report. This is not a zero-vulnerability result. |
| Docker rebuild | PASS after writable-config retry: `response-task4:rc1`, image `sha256:614a9dde59b5d73836a3cc7eedbf1877b86eb3a517d7aa9199f574d907bb5af8`, linux/amd64, user `node`. Builds static frontend plus API/worker/migration bundles. |
| Container runtime | PASS: migrations twice, seeded dedicated DB, API health/schema failure/recovery, worker restart/deadline review, transactional closure, API restart, health status healthy and smoke twice; exit 0. |
| Fresh archive | Exact final archive checks are recorded in the adjacent release verification JSON after extraction; they are separate from host results. |
| Windows, physical GPS/background devices, production load, live AWS/provider acceptance | NOT RUN. |

Commands (public disposable local fixture credentials, never production):

```bash
TEST_DATABASE_URL=postgresql://response:local-development-only@127.0.0.1:5432/response_task2_test ./node_modules/.bin/vitest run tests/workflow.test.ts tests/readiness.test.ts tests/readiness-timeout.test.ts tests/configuration.test.ts tests/local-access.test.ts tests/local-access-metadata.test.ts
TEST_DATABASE_URL=postgresql://response:local-development-only@127.0.0.1:5432/response_task2_test npm test
DATABASE_URL=postgresql://response:local-development-only@127.0.0.1:5432/response_task2_browser_test APP_ORIGIN=http://localhost:5173 API_ORIGIN=http://localhost:4000 CI=1 npm run test:e2e
npm run typecheck
npm run lint
npm run build
npm audit --omit=dev --audit-level=high --cache .local/npm-cache
DOCKER_CONFIG=/tmp/response-task4-docker-config IMAGE_TAG=response-task4:rc1 bash scripts/build-container.sh
```

Create disposable test databases first (using the existing Compose database); tests reset their `_test` schema. Browser tests migrate/seed their separately configured database. Stop the ordinary dev server before browser tests. Do not point tests at operational data. Full offline commands and environment isolation are documented in TESTING.md; Task 4 used `cdk.out/task4-{academic,reference,receipts}`. The source/ZIP verification manifest provides exact commands, exits and archive hashes. Logs are local artifacts, excluded from public source.

### Initial failures retained in the record

The first Docker invocation failed before building with `mkdir /home/agent/.docker/buildx: read-only file system`; a writable `DOCKER_CONFIG` corrected this environment limitation. The first container harness allowed only 15 seconds for startup; Docker's `vfs` layer copying outlasted it, and cleanup sent SIGTERM before API startup completed, then Docker killed it (exit 137). This failed probe is not counted as passing. The rerun allows 180 seconds to start, waits for actual readiness and retains the 12-second graceful-stop assertion; all containers then exited 0. Logs contain an expected `worker_tick_failed` while a required index was deliberately renamed, followed by recovery. Only probe-owned containers were stopped/removed; the existing Compose DB and volume were preserved.

`node .local/task4/container-smoke.mjs` is an ignored scratch harness, not a shipped package command. It invokes the actual compiled migrator twice, host demo seed and existing smoke script, plus API/worker commands from the rebuilt image. Reproducible lifecycle/schema/retry assertions remain in the shipped integration/readiness/workflow tests. No Windows/container-network equivalence is implied.

## Role journeys and backend boundaries

- **Citizen:** real local cookie login, incident creation with coordinates, scoped status/notifications, supplementary updates, permitted own-report cancellation and invalid cancellation cases pass API/browser regressions. Cognito enrollment/login/recovery verifies local OAuth state/PKCE routing with provider stubs; real registration is NOT TESTED. Evidence initiation explicitly fails when unconfigured; S3 size/type/signature/finalization and scoped download have stubbed integration coverage, not a local file-storage substitute.
- **Authority:** triage, offers, acceptance versus dispatch, cancel/reassign/close, multi-team incident aggregation, deadline review, resource allocation, shelter creation/capacity and append-only history have real local API/DB coverage. Browser scenarios exercise dispatch/arrival/withdrawal/reassignment and scoped shelter forms. Cross-department/jurisdiction/team actions are rejected on the backend.
- **Rescuer:** duty, explicit location consent, eligible assignments, accept/decline, dispatch permission boundaries, en-route/arrival/progress/completion and reasoned withdrawal pass existing tests. Accepted/progress deadlines request control-room review; they do not invent dispatch, arrival or failure. GPS remains mounted above navigation; eight browser scenarios cover navigation, explicit disablement, off-duty, denial, unsupported location, stale/inaccurate samples, upload failure, revocation and logout. Synthetic browser GPS is not field validation.
- **Admin:** protected organization/department/jurisdiction/user configuration, metrics, immutable history and account revocation are covered. Invitation failure when Cognito is unconfigured is explicit. Public/client role injection, self-modification, unauthorized scope/resource/audit mutation, demo-cookie reuse and cross-origin mutations are rejected by server tests.

Reviewed main/management pages, shared action metadata, session/GPS ownership, API routing/authentication, policy/incident/resource/evidence modules, deadlines/outbox/notifications and migrations. Dashboard and operational lists use backend queries; the demo catalog/identities and illustrative sign-in timeline are labeled fixtures/illustration. No real incident or GPS dataset is silently manufactured. Loading/empty/error/retry and revoked-session paths have browser coverage. There was no newly demonstrated application defect requiring UI or workflow rewriting in this audit; this is not an exhaustive UX or penetration audit.

Security remains: real socket/Host/Origin/proxy checks before fixture session reuse; loopback Vite dev/preview; production Cognito-only validation; secure production session cookies, server CSRF, strict role/scope checks, SQL parameters and transactions, append-only audit triggers, short-lived scoped evidence URLs, redacted API/worker errors and citizen location privacy. Evidence still lacks full malicious-image scanning/EXIF sanitization; rate limits are process-local. A trusted local relay stripping metadata cannot be distinguished from a local client: never tunnel fixture ports. See SECURITY.md.

## Containers, configuration and deployment boundaries

Compose defines **PostgreSQL only**, with `pg_isready` and a loopback port; it does not automatically launch/migrate the application. The single Dockerfile compiles the frontend and builds an API image that can also execute the long-running local worker or migrator. There are no separate frontend/worker Dockerfiles. The final image does not serve frontend files; local Vite or later Amplify publication does that. AWS worker deployment uses the Lambda bundle, not a second ECS service.

Local demo API binds loopback **inside its container**; bridge-port exposure is deliberately unsuitable. The Linux probe uses `--network host` with explicit demo/test/simulator settings, an isolated `_test` database and an API health command on `127.0.0.1:4014`. This is a Linux test method, not a claim that host networking works identically on Windows. No public port, proxy or tunnel is introduced. Ordinary Windows instructions run Node/Vite on the host and only PostgreSQL in Docker.

Run migration before seed/API/worker. The rebuilt migrator is idempotent. Liveness `/api/v1/health` is independent of redacted schema readiness `/api/v1/health/ready`; worker readiness failures pause processing and emit only `worker_tick_failed`. Deployment assertions check API/worker migration dependencies, separate owner/runtime secret references and ALB readiness timeout. No standalone Docker HEALTHCHECK is baked into this image; the local probe supplies one, and AWS uses the target-group check. Existing consumers must still be coordinated during a live upgrade.

The existing CodePipeline/CodeBuild path updates **ECS only**. Matched migration, Lambda worker, frontend publication and account bootstrap remain coordinated/manual work. IAM, organization SCPs, current account eligibility and costs are NOT CHECKED by local tests. NAT, ALB, Fargate, RDS/storage/backups, Amplify, Location, secrets, logs, messaging, data transfer and retained resources can charge. A budget alert is not a spending cap. No cloud service was provisioned or tested. Rollback requires matched security-fixed artifacts, preserved backups, paused incompatible consumers and a reviewed forward-schema or separate restore/reconciliation procedure; never erase migration history or revert to a vulnerable build. See DEPLOYMENT_READINESS_REVIEW.md.

## Package contract and public review

The archive contains one `Response/` root, all current source/tests/migrations/docs/infra, manifests and exact lockfile, plus `.env.example`, `.env.demo.example`, `.env.production.example`. It omits dependencies, builds, caches, test results, Git state, historical downloadable ZIPs, actual env files, credentials, all certificates/private keys and database data. Fetch the official public RDS CA with `node scripts/fetch-rds-ca.mjs` before offline infrastructure/RDS artifact work; TLS verification remains enabled. The CI workflow now fetches that public prerequisite and runs offline synthesis/assertions rather than requiring account lookups.

Only the public staging copy resets historical deployment approval/account-credit metadata and redacts old account-specific policy/principal details. The working configuration is preserved. The adjacent manifest lists every source hash and every deliberate public-copy difference; source code/tests/migrations/manifests remain byte-for-byte copies. Known fixture addresses/passwords and synthetic account IDs are intentionally retained for reproducible tests. Public scan checks forbidden file types, private-key/key/token patterns, contact data and archive path safety; it is not a guarantee against all possible secret formats.

The separate download branch contains only this archive and its checksum/verification metadata, not a replacement of main. Publication occurs only after fresh extraction, locked installation and checks of the exact ZIP. Its adjacent `.verification.json` records final extracted-copy commands/results and SHA-256 without requiring a self-referential checksum inside the ZIP. Older Task 1 archives remain historical. Use the newly published version rather than an earlier Windows extraction.

## Fresh candidate extraction — actual results

The 149-file candidate ZIP was extracted into a new directory. Its manifests, all three environment examples, migrations 001–008 and exact lockfile were verified against the per-file manifest. `npm ci --no-audit --no-fund` installed **391 packages in 13 seconds**, `npm ls --all` passed, and the lockfile hash remained `be61276c93065e57793366acc852d5c1062a55930a14cc89129954b5ff5819c7`.

From that extracted copy: **219/219 focused tests (65.20s), 272/272 full tests (53.98s), 21/21 browser tests (2.6m)**; lint, typecheck and production build exited 0. Separate new local `_test` databases were used. An additional public CA prerequisite initially failed with `fetch failed`, `ECONNREFUSED`/`ENETUNREACH` because this environment requires a proxy. Retrying the unchanged helper with Node 24's `NODE_USE_ENV_PROXY=1` succeeded with HTTPS verification and X.509 parsing intact. No certificate is added to the ZIP. The final archive is extracted and verified again after these release-only documentation/privacy changes; exact final commands, counts, exits and hash are in its adjacent `.verification.json`. Candidate results alone do not authorize publication.

## Task 4 changed files and remaining gates

Task 4 changes `README.md` and `START_HERE.md` (current archive links instead of the incomplete main-branch download); `.github/workflows/ci.yml` (public CA prerequisite and offline assertion step); `certs/README.md` (certificate omission/fetch guidance); `docs/RELEASE_VERIFICATION.md` (this review); and current-status addenda in `docs/TESTING.md`, `docs/POST_IMPLEMENTATION_AUDIT.md`, `docs/IMPLEMENTATION_STATUS.md`, `docs/CONFIGURATION.md`, `docs/DEPLOYMENT_READINESS_REVIEW.md`, `docs/PACKAGE_VERIFICATION.md`, `LOCAL_TEST_WALKTHROUGH.md`. All earlier Tasks 1–3 changes remain. No new schema migration or product feature is added in Task 4.

Before operational deployment: live identity/MFA/session/cookie and provider acceptance; effective IAM/network/TLS review; backup/restore/reconciliation drill; physical device/background behavior; dependency/security review, upload scanning/privacy/retention and distributed abuse controls; capacity/load/failover testing and staffed response governance. Local tests alone do not satisfy these gates.

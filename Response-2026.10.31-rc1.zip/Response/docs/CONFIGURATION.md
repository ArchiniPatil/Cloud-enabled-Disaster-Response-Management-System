# Runtime configuration and database readiness

## Release archive prerequisites — Task 4

The release includes all three environment examples and the original dependency lockfile. Actual environment files, account credentials and certificates are excluded. Local demo setup needs no AWS credentials or RDS certificate. Before offline infrastructure synthesis or preparing an RDS-connected image, run `node scripts/fetch-rds-ca.mjs` to fetch and validate the official public RDS trust bundle. Never disable TLS verification to compensate for a missing bundle. CI now performs this prerequisite before offline synthesis/assertions.

The public release's deployment policy is deliberately unapproved, with no carried-over account credit details or historical authorization. Source infrastructure is included for review; publication of a source ZIP grants no authorization to deploy. Production remains Cognito-only and cannot use fixture sessions. [RELEASE_VERIFICATION.md](RELEASE_VERIFICATION.md) distinguishes local, container and extracted-source checks from live AWS acceptance.


Updated for Task 3, 30 October 2026. These are local validation rules, not proof that AWS services, credentials, TLS endpoints or IAM permissions work. Current results and known failures are recorded in [TESTING.md](TESTING.md) and [POST_IMPLEMENTATION_AUDIT.md](POST_IMPLEMENTATION_AUDIT.md).

## Startup paths

API (`server.ts`), long-running worker (`worker.ts`), Lambda worker (`lambda.ts`), optional SMS-receipt Lambda (`sms-receipts.ts`), CLI migrator (`scripts/migrate.ts`), administrator bootstrap CLI and administrative migration/bootstrap handler (`scripts/migration-handler.ts`) import the same configuration parser and database initialization. Invalid production configuration throws a redacted field-level error before API listening or processing work. Secrets Manager payloads are validated before creating the database pool. The administrative migrator validates its runtime-role secret before schema writes.

`NODE_ENV=production` uses the production rules below; authentication is always Cognito. Missing `AUTH_MODE` defaults to Cognito, never fixtures. Cookie flags are fixed in code: HttpOnly, Secure in production, SameSite=Lax, path `/api/v1`; there is no environment switch to disable those flags. Cross-origin mutation checks and CSRF enforcement remain unchanged. Frontend API requests use the existing `/api` proxy; callback registration must match the configured frontend `/api/v1/auth/callback` exactly. Provider registration, cookie delivery and proxy behavior still require live acceptance testing.

Local development remains separate. `setup:demo` / `dev:demo` use `.env.demo`, fixture identities, loopback-only access and simulated notifications. `setup:local` / `dev:local` use `.env.cognito` and real provider identities. Incomplete nonproduction Cognito configuration can still display the existing unconfigured-identity page; it cannot issue fixture sessions. No local setup script was changed or pointed at AWS in this task.

## Production settings

| Setting | Rule |
|---|---|
| `AWS_REGION` | Explicit region syntax for the existing commercial AWS deployment; not inferred from the development default. Syntax is not proof of service availability. |
| `APP_ORIGIN`, `API_ORIGIN` | Explicit canonical HTTPS origins, no credentials/path/query/fragment. Reject loopback and reserved placeholder domains. Existing infrastructure uses DNS hostnames. |
| `COGNITO_POOL_ID` | Region prefix must equal `AWS_REGION`, followed by `_` and 1–55 alphanumeric characters. Reject placeholder values. |
| `COGNITO_CLIENT_ID` | 1–128 lowercase alphanumeric characters, matching the provider identifier shape; reject placeholders. Format does not prove that the client exists. |
| `COGNITO_DOMAIN` | Canonical HTTPS origin for managed login or a custom login domain. Managed `.amazoncognito.com` domains must match the configured region. |
| `COGNITO_ISSUER` | Optional consistency assertion. If supplied, must exactly equal `https://cognito-idp.<region>.amazonaws.com/<pool-id>`. The authentication implementation derives this issuer. |
| `DATABASE_URL` **or** `DATABASE_SECRET_ARN` | Exactly one nonempty source. No production fallback to local development credentials. |
| `DATABASE_URL` | `postgres:` or `postgresql:`, explicit user/password/host/database. Password policy below. Reject URL fragments and query parameters except `sslmode=verify-full`. TLS always uses `rejectUnauthorized: true`; validated URL SSL options are removed before passing to pg so they cannot override this. |
| `DATABASE_SECRET_ARN` | Complete commercial Secrets Manager ARN, matching region and numeric 12-digit account syntax, including the generated six-character suffix. Loaded JSON requires valid host, port 1–65535, username, password and dbname; invalid/missing payloads fail closed. |
| `SESSION_KEY` **or** `SESSION_SECRET_ARN` | Exactly one nonempty source. Session secret ARN follows the same ARN rules and must differ from the database ARN. Loaded session material must satisfy the same strength policy as a direct key. |
| `EVENT_TOPIC_ARN` | Required standard SNS topic ARN in the configured region. Production outbox processing has no local fallback. FIFO topics are rejected because this publisher does not supply FIFO group/deduplication fields. |
| `EVENT_TRANSPORT` | Omitted or `aws` in production. `database` remains restricted to a loopback nonproduction database. |
| `NOTIFICATION_TRANSPORT` | `aws` in production (also its default). Simulator is allowed only for explicit nonproduction demo mode. This does not require enabling SMS or email. |
| `PORT` | Integer 1–65535, default 4000. |
| `READINESS_TIMEOUT_MS` | Integer 100–5000, default 2000; covers pool acquisition and the complete probe. |
| `NODE_TLS_REJECT_UNAUTHORIZED` | Must not be `0` in production; disabling global TLS verification would undermine provider authentication. |

The minimal production application still needs SNS event transport for durable incident processing. Evidence storage, analytics, maps/routes/place search and external notifications are optional: omit `EVIDENCE_BUCKET`, `ANALYTICS_BUCKET`, `LOCATION_MAP_NAME`, `LOCATION_ROUTE_CALCULATOR`, `LOCATION_PLACE_INDEX`, and `EMAIL_FROM` when unused. Configured bucket/resource names are syntax-checked and placeholder values rejected. Missing optional services retain the existing unavailable/no-op behavior; this task does not simulate their availability.

`SMS_ENABLED` defaults to `false`; `EMAIL_FROM` enables the existing SES email adapter and must be a valid nonplaceholder email address. Sender verification, sandbox restrictions, IAM and delivery are live-service prerequisites, not properties established by environment parsing. `LOCATION_RETENTION_HOURS` remains bounded to 1–168 (default 24). `REALTIME_TRANSPORT` remains `sse` or `poll`. The existing academic template uses polling.

For RDS, the existing container and Lambda templates set `NODE_EXTRA_CA_CERTS` to their packaged public RDS CA bundle, respectively `/app/certs/rds-global.pem` and `/var/task/certs/rds-global.pem`. Direct deployments must supply appropriate trusted CA material when the system trust store is insufficient. Validation never sets `rejectUnauthorized: false` and does not replace certificate/hostname verification with a configuration-presence check.

## Secret policy and errors

Session material must contain at least 32 UTF-8 bytes, at least 16 distinct characters, at most 512 characters, no whitespace, no repeated short pattern, and no recognizable dummy/placeholder values. Database passwords require at least 16 bytes and eight distinct characters with the same upper bound and placeholder/repetition checks. Generate cryptographically random values; the validator detects obvious weakness but cannot prove randomness. The existing CDK 64-character session secret and 40-character runtime database password generators satisfy the policy in normal use. The local Cognito helper already generates random material into an ignored file without printing it.

The encryption derivation and session schema are unchanged. Replacing an old weak key invalidates decryption of existing refresh sessions; plan reauthentication/rotation rather than silently changing a deployed key. No production secrets were generated, printed or rotated in this task.

Errors identify only field names or fixed categories. Raw environment values, rejected secrets, provider errors and connection strings are not copied into validation errors. Secret fetches have a five-second abort deadline and at most two SDK attempts. Application connectivity, provider acceptance and IAM still need separate operational checks.

## Migration credentials and ordering

The API/worker use the runtime database secret and `response_app` role. The administrative migration handler uses the owner database secret plus a distinct `APP_DB_SECRET_ARN` referring to runtime credentials. It validates that secret and `response_app` username before applying migrations or changing the role password. Runtime grants remain DML-only, with no DDL or migration-ledger mutation and no UPDATE/DELETE/TRUNCATE on append-only audit/history/revision/update tables. Plain `npm run db:migrate` does not create/grant the production runtime role; `prepareDatabase` does that during the existing infrastructure migration path.

Local Compose defines only PostgreSQL and its `pg_isready` server check. That check intentionally does not require application tables, so a fresh database can start before migrations. Existing setup and Playwright startup run migrations before seeding/starting the app. The Docker image copies `db/` and the compiled runtime; schema-contract JSON is bundled into API/worker/migrator code. The existing Dockerfile has no standalone HEALTHCHECK directive; hosted API health is checked by the ALB.

The ALB keeps `/api/v1/health/ready`, success code 200, with a ten-second timeout exceeding the maximum five-second application deadline. ECS, the worker Lambda and the optional receipt Lambda functions depend on the migration custom resource. Only each function receives that dependency; putting it on an entire worker construct also makes its security group dependent and creates a CloudFormation cycle. The migration resource revision includes the SQL and contract, so contract changes also trigger the existing migration/validation path. Lambda assets embed the contract; the administrative bundle additionally copies SQL/DB assets via `cdk-assets.mjs`. Offline synthesis/assertions check this structure without deploying anything.

## Liveness, readiness and schema maintenance

- `/api/v1/health`: 200 `{ "status": "ok" }` means the API process can serve the request. It does not query or claim database readiness.
- `/api/v1/health/ready`: 200 `{ "status": "ready" }` only after validating the migration ledger and schema; otherwise 503 `{ "status": "unavailable" }`. No schema names, SQL or infrastructure details are returned. Responses are not cached.
- Task 1's demo transport guard remains before both endpoints; neither endpoint is a fixture-authentication bypass.
- Probes share one in-flight operation, use a read-only repeatable-read transaction, bound connection/query/lock waiting and destroy timed-out connections, including connections acquired after the deadline. They never apply migrations. There is no success cache that conceals later schema damage.
- Long-running and Lambda workers check the same schema before processing. Invalid configuration fails startup; temporarily unready databases are retried by the existing worker loop or Lambda retry mechanism.

`db/schema-contract.json` describes the eight expected migrations (001–008), normalized SQL hashes and 496 required objects: relations, columns/defaults/nullability/types, constraints/validation, semantic index definitions/validity, enabled audit triggers/functions, and PostGIS/pgcrypto extensions. Ledger entries must be known, unique, timestamped and complete. Migrating accepts a valid ordered prefix; unknown versions and gaps fail closed. Additional unrelated schema objects are allowed. This release intentionally refuses a database with unknown future migrations; rollback to an older binary therefore requires a compatible database snapshot or a reviewed compatibility change.

The contract is for the project's PostgreSQL 16 schema, not arbitrary database versions or hand-modified schemas. Physical index tuning/tablespaces do not affect the semantic index check. `ENABLE ALWAYS` audit triggers are accepted as stronger than normal enabled triggers; disabled/replica-only protection is rejected. Inspection normalizes session display settings and CRLF function text; migration asset checks normalize CRLF before hashing/execution. Extension patch versions are not pinned by readiness. The check does not attest provider connectivity, available disk space, data correctness, workload capacity or every effective privilege.

Task 2 added no SQL migration; Task 3 adds forward-only `008_assignment_deadlines.sql`. Migrations 001–007 retain their original bytes. For a future schema change, review a new migration, generate the updated contract from a **new empty local database ending in `_test`**, review the diff and run upgrade/regression tests:

```text
TEST_DATABASE_URL=<disposable loopback PostgreSQL URL ending in _test> npx tsx scripts/generate-schema-contract.ts
```

This notation describes the environment input; use the appropriate environment-variable syntax for your shell. The generator refuses a nonempty application database and never provisions AWS. Do not regenerate from a damaged operational database to make readiness pass. Missing deployed schema requires a reviewed migration/restore plan, not bypassing the contract or disabling health checks.

## Assignment deadlines and resource workflow (Task 3)

No new environment variables or secrets are required. Policy windows are stored in `escalation_policies`: `offer_timeout_seconds` (default 120), `dispatch_timeout_seconds` (180), and `progress_timeout_seconds` (900), all integers from 10 to 86400 seconds. Administration edits these alongside the existing radii/delays using `offerTimeoutSeconds`, `dispatchTimeoutSeconds` and `progressTimeoutSeconds` in the policy API. Omitted fields preserve current policy values. Existing pending deadlines are not silently extended when a policy changes.

The new `assignment_deadlines` table stores each phase, due time and completion/review outcome. Migration 008 gives existing active assignments a full window from upgrade and preserves actual status. It also adds escalation radius and resource allocation actor/state metadata. The 496-object contract comprises 44 relations, 236 columns, 139 constraints, 70 indexes, four audit triggers, one audit function and two extensions. Existing migration permissions grant runtime DML on the new table through the existing owner-only `prepareDatabase` path; no IAM policies or grants were expanded.

Offer expiry withdraws an unanswered offer; accepted/field deadline expiry requests human review without manufacturing a field outcome. Worker restart resumes persisted work. See [INCIDENT_WORKFLOW.md](INCIDENT_WORKFLOW.md) for transitions, scope, geographic policy, resource states and browser GPS limitations.

For a real upgrade, stop old writers/workers, back up the database, apply migrations with the owner path, verify readiness with the matching new runtime, then resume traffic. Older Task 2 binaries reject unknown migration 008; rollback requires a compatible database/application pair or a reviewed forward fix. Local clean/upgrade tests are not live RDS backup/restore evidence.

# Test commands and actual results

## Task 4 release verification — 31 October 2026

The current verification record is [RELEASE_VERIFICATION.md](RELEASE_VERIFICATION.md). It supersedes earlier counts for this release candidate: 219/219 focused regressions, 272/272 full tests and 21/21 Chromium browser scenarios passed again with no skips. TypeScript, lint, production build and all three offline infrastructure assertions passed. Database clean-install, pre-008 upgrade, restricted-role and worker retry/concurrency cases are included in the full suite. Earlier failures below remain historical records, not current acceptance claims. Fresh-extraction and Docker results are recorded separately in the current release review and the archive's external verification manifest.


## Task 3 final verification — 31 October 2026

Scope: incident/assignment lifecycle, persistent deadlines/escalation, GPS continuity, resource/shelter capacity, scoped UI actions and audit/notification consistency. [INCIDENT_WORKFLOW.md](INCIDENT_WORKFLOW.md) defines behavior; [POST_IMPLEMENTATION_AUDIT.md](POST_IMPLEMENTATION_AUDIT.md) lists root causes and all changed files. Earlier Task 1/2 results below are historical, not claims about the new migration.

Before changing implementation, inspected the existing diff, AGENTS.md, authentication/readiness/configuration source, migrations 001–007 and requested documentation, and saved `/workspace/task3-backup-20261030`. Baseline was rerun: **222/222 full tests**, seven files, 34.01s; **11/11 browser tests**, 1.4m; TypeScript, lint and build exit 0. Task 2 infrastructure sources/assertions were preserved and their three recorded offline results reviewed; all three variants were synthesized again after Task 3 changes.

Executed on Linux, Node 24.19.0, PostgreSQL 16/PostGIS 3.5 and Chromium. Integration/readiness/workflow suites used the dedicated `response_task2_test` database sequentially; browsers used separate `response_task2_browser_test`. Contract generation used a new empty `response_task3_contract_test`; built runtime smoke used a new `response_task3_smoke_test`. No original project database/volume was reset. The database name suffix is enforced by the tests. Sample credentials below are the existing public local-development fixture, not real secrets.

```bash
TEST_DATABASE_URL=postgresql://response:local-development-only@127.0.0.1:5432/response_task2_test ./node_modules/.bin/vitest run tests/workflow.test.ts tests/readiness.test.ts tests/readiness-timeout.test.ts tests/configuration.test.ts tests/local-access.test.ts tests/local-access-metadata.test.ts
TEST_DATABASE_URL=postgresql://response:local-development-only@127.0.0.1:5432/response_task2_test npm test
DATABASE_URL=postgresql://response:local-development-only@127.0.0.1:5432/response_task2_browser_test APP_ORIGIN=http://localhost:5173 API_ORIGIN=http://localhost:4000 CI=1 npm run test:e2e
npm run typecheck
npm run lint
npm run build
```

The workflow suite adds 48 cases. Readiness retains all prior coverage and adds two migration/constraint cases; migration-count assertions follow the new expected ledger, and the original pre-007 test still starts before 007. Ten browser cases were added without deleting/changing existing scenarios. Authentication regression source, configuration validation and timeout regression source remain unchanged.

Coverage includes original 409 failures, reasoned rescuer withdrawal, atomic whole-incident closure, invalid transitions, duplicate acceptance, concurrent offers/cancellation, reassignment/history, multi-team aggregation, cross-department/jurisdiction/team scope, historical reporter ownership, offer expiry, persisted configured windows, dispatch/progress review without fictional outcomes, restart/rollback recovery, geographic radius/deduplication/actual alert counts, unavailable/stale/missing GPS, location privacy, nonnegative inventory, capacity contention, scoped shelter creation/publication, resource use/release and both directions of state/audit failure. Runtime-role checks exercise the new deadline/cancellation writes while refusing DDL/audit mutation. Notification tests distinguish SIMULATED, definite FAILED, SUBMITTED and ambiguous outcomes; provider requests are SDK stubs.

Offline infrastructure commands were run in a subprocess with inherited `AWS_*`/`CDK_*` variables removed and `AWS_EC2_METADATA_DISABLED=true`, `AWS_SHARED_CREDENTIALS_FILE=/dev/null`, `AWS_CONFIG_FILE=/dev/null`, plus a writable local npm cache:

```bash
node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/app.ts' --lookups=false --quiet -c offlinePreview=true --output cdk.out/task3-release-academic -c hosting=academic
node --import tsx scripts/verify-infra.ts cdk.out/task3-release-academic/DisasterResponse-academic.template.json
node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/app.ts' --lookups=false --quiet -c offlinePreview=true --output cdk.out/task3-release-reference
node --import tsx scripts/verify-infra.ts cdk.out/task3-release-reference/DisasterResponse-dev.template.json
node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/app.ts' --lookups=false --quiet -c offlinePreview=true --output cdk.out/task3-release-receipts -c hosting=academic -c smsDeliveryLogs=sns/ap-south-1/123456789012/DirectPublishToPhoneNumber
node --import tsx scripts/verify-infra.ts cdk.out/task3-release-receipts/DisasterResponse-academic.template.json
```

The receipt log-group/account input is synthetic. No AWS identity/service/permission or live notification check occurred. No IAM policy or infrastructure source changed in Task 3. All generated assets stay in the existing ignored `cdk.out` tree.

`node .local/task3/built-smoke.mjs` (an ignored local verification harness) ran the compiled migrator, demo seed, built API on loopback port 4013 and built worker with a minimal environment containing no inherited AWS credentials. It invoked the existing `scripts/smoke-local.ts` for readiness/cookie/scoped query/logout, created an accepted assignment through the API, stopped the worker, made the persisted dispatch deadline due in the isolated database, restarted the worker and verified control-room review without changing ACCEPTED/ACKNOWLEDGED. It then closed the incident/assignment atomically through the API. Child processes were cleaned up. Reproducible source coverage for the same behavior is in `tests/workflow.test.ts`; this scratch harness is not a shipped npm script.

Initial four regressions: **4 failures**, reproducing both 409s, missing deadline persistence and false resource success. First partial implementation: **3 failed / 1 passed**, with TypeScript exposing misplaced action metadata and helper types; corrected before expanding coverage. Off-duty and historical-reporter reproductions each failed once (other tests were intentionally unselected with `-t`). The final alert-count regression reproduced `ALERTED_2_TEAMS` when only one new team's notifications were inserted; the count now uses inserted jobs. These focused diagnostic filters were not permanent skips.

Browser iterations: **18 passed / 1 failed** (new test used the wrong existing logout label), then **20 passed / 1 failed** (new assertion matched both assignment and incident history). Exact selectors were corrected without removing assertions or changing product wording. A later lint run reported **two errors in the ignored local smoke harness** (unused variable, empty catch); the harness was corrected, not excluded by changing lint rules. Injected audit/resource-write/provider/transaction errors are expected test inputs. Final source checks and their counts are recorded in the result table below.

Remaining warnings: large MapLibre frontend chunk, Lambda bundle-size notices, 84 unset CDK feature flags, existing optional receipt `logRetention` deprecation, browser color-environment notices and expected generic logs for deliberate provider failures. **NOT RUN:** native Windows/PowerShell, physical GPS/background delivery/multiple-device failover, real AWS/Cognito/SMS/email/RDS/TLS/IAM, load/chaos/restore validation, application Docker-image rebuild and dependency vulnerability audit. No cloud provisioning, provider switch, credential output or dependency/lockfile regeneration occurred. Earlier downloadable ZIPs were not republished as Task 3.


### Task 3 recorded results

| Check | Result |
|---|---|
| Focused workflow + Task 1/2 security/readiness/configuration | **PASS — 219/219**, six files, 61.57s, no skips. 169 original focused cases + 48 workflow + two migration cases. |
| Full suite | **PASS — 272/272**, eight files, 62.63s, no skips; baseline 222 retained. |
| Browser workflows (`npm run test:e2e`) | **PASS — 21/21**, 2.7m, no skips; original 11 plus ten new scenarios. |
| TypeScript (`npm run typecheck`) | **PASS**, exit 0. |
| Lint (`npm run lint`) | **PASS**, exit 0 after correcting the scratch harness errors. |
| Production build (`npm run build`) | **PASS**, exit 0, existing bundle warnings retained. |
| Clean migration and pre-007/pre-008 upgrade | **PASS** within readiness/integration tests; clean compiled migrator also exercised. |
| Restricted runtime role | **PASS**: deadline/cancellation/audit DML succeeds; DDL and audit deletion denied. |
| Worker concurrency/restart/transaction retry | **PASS** in workflow regressions and built worker smoke. |
| Built migrator/API/worker smoke | **PASS**, exit 0; readiness, cookie login/scoped list/logout, dispatch review after restart and atomic incident closure. |
| Offline academic/reference/optional receipt templates | **PASS**, all three syntheses and all three assertion runs exit 0. |
| Final diff / Task 1/2 preservation | **PASS**: no old SQL/manifests/lockfile/IAM/auth/config/readiness-engine changes; new contract and migration-aware tests are intentional. |
| Native Windows / physical GPS / live AWS/provider deployment | **NOT RUN**. No live-service or deployment-readiness claim. |
| Application container rebuild / load / live restore / vulnerability audit | **NOT RUN** in Task 3. |

Final logs: `.local/task3/targeted-release.log`, `full-release.log`, `typecheck-release.log`, `lint-release.log`, `build-release.log`, `browser-release.log`, `built-smoke-release.log`, `infra-release-*.log`. Earlier failure logs remain alongside them. These ignored logs and the scratch harness are local verification artifacts, not source-package requirements.

## Task 2 final verification — 30 October 2026

Scope: database readiness and production configuration only. See [CONFIGURATION.md](CONFIGURATION.md) for the contract and deployment requirements and [POST_IMPLEMENTATION_AUDIT.md](POST_IMPLEMENTATION_AUDIT.md) for findings, changed files and limitations. Historical results below describe earlier releases; they do not replace this run.

Verified on Linux, Node 24.19.0, PostgreSQL 16/PostGIS 3.5 in the existing local Docker database, and Chromium. All database tests used isolated loopback databases ending in `_test`; no operational database or volume was reset. Commands below run from the repository root using Bash. The displayed password is the existing public local-development fixture, not a production credential.

```bash
TEST_DATABASE_URL=postgresql://response:local-development-only@127.0.0.1:5432/response_task2_test ./node_modules/.bin/vitest run tests/readiness.test.ts tests/readiness-timeout.test.ts tests/configuration.test.ts tests/local-access.test.ts tests/local-access-metadata.test.ts
TEST_DATABASE_URL=postgresql://response:local-development-only@127.0.0.1:5432/response_task2_test npm test
DATABASE_URL=postgresql://response:local-development-only@127.0.0.1:5432/response_task2_browser_test APP_ORIGIN=http://localhost:5173 API_ORIGIN=http://localhost:4000 CI=1 npm run test:e2e
npm run typecheck
npm run lint
npm run build
```

| Check | Final result |
|---|---|
| Focused Task 2 + preserved Task 1 regressions | **PASS: 169/169**, five files, 28.42s, no skips (100 Task 2 + 69 Task 1). |
| Full suite | **PASS: 222/222**, seven files, 56.58s, no skips. |
| Browser workflows | **PASS: 11/11**, 1.6m, no skips. |
| TypeScript | **PASS**, exit 0. |
| Lint | **PASS**, exit 0. |
| Production build | **PASS**, exit 0; frontend, API, workers and administrative bundles. |
| Offline infrastructure | **PASS**, three syntheses and three assertion runs, exit 0. |
| Built-runtime smoke/recovery | **PASS**, exit 0, compiled migrator/API/worker and local session smoke. |
| Schema upgrade and least-privilege runtime role | **PASS** within the regression suite: representative pre-007 upgrade preserves existing data; runtime role can inspect schema but cannot perform protected DDL/audit/ledger writes. |
| Task 1, dependency lockfile and SQL preservation | **PASS**, compared with the saved Task 1 tree; no package/lockfile or SQL migration changes. |
| Native Windows, physical remote devices, live AWS/Cognito/RDS/TLS/IAM | **NOT RUN**. No credentials or deployed resources were exercised. |
| Application Docker image rebuild | **NOT RUN** in Task 2; Dockerfile/Compose/assets were reviewed, with built Node runtime and local Docker PostgreSQL exercised. |
| Dependency vulnerability audit | **NOT RUN** in Task 2; dependencies were not changed. |

Regression coverage includes empty migration ledger without application tables, missing/altered columns/constraints/indexes/audit triggers/function/extensions, ledger gaps/unknown migrations, checksums, CRLF compatibility, additive objects, semantic index tuning, ALWAYS-enabled triggers, session display settings, lock/connection deadlines and late connection cleanup. Configuration tests cover missing/malformed/dummy settings, resolved secret payloads, optional integrations, API/worker/receipt/migration/bootstrap entry points, TLS and explicit local demo compatibility. Original security tests still cover socket/Host/Origin/forwarding checks and cookie reuse.

Offline synthesis used a subprocess environment with inherited `AWS_*` and `CDK_*` variables removed, then `AWS_EC2_METADATA_DISABLED=true`, `AWS_SHARED_CREDENTIALS_FILE=/dev/null`, `AWS_CONFIG_FILE=/dev/null` and a writable `.local/npm-cache`. Commands:

```bash
node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/app.ts' --lookups=false --quiet -c offlinePreview=true --output cdk.out/task2-verified-academic -c hosting=academic
node --import tsx scripts/verify-infra.ts cdk.out/task2-verified-academic/DisasterResponse-academic.template.json
node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/app.ts' --lookups=false --quiet -c offlinePreview=true --output cdk.out/task2-verified-reference
node --import tsx scripts/verify-infra.ts cdk.out/task2-verified-reference/DisasterResponse-dev.template.json
node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/app.ts' --lookups=false --quiet -c offlinePreview=true --output cdk.out/task2-verified-receipts -c hosting=academic -c smsDeliveryLogs=sns/ap-south-1/123456789012/DirectPublishToPhoneNumber
node --import tsx scripts/verify-infra.ts cdk.out/task2-verified-receipts/DisasterResponse-academic.template.json
```

The account in the receipt log-group input is synthetic. These commands only produced local templates/assets; they did not test deployment permission, service availability or delivery. Assertions cover API/worker/migrator production settings, distinct owner/runtime secrets, readiness timeout, migration ordering and the pre-existing infrastructure security assertions.

The ignored local harness `node .local/task2/check-built-runtime.mjs` ran `node dist/scripts/migrate.js`, `node --import tsx scripts/seed.ts`, `node dist/api/server.js`, `node dist/api/worker.js` and `node --import tsx scripts/smoke-local.ts` against `response_task2_built_test`. It supplied a minimal environment with explicit demo/test mode, simulated notifications and no inherited AWS credentials. It verified readiness/login/scoped query/logout, then removed a required index only in that disposable DB: readiness became 503, liveness remained 200, worker heartbeats paused, and restoring the original index restored readiness and heartbeats. Two generic `worker_tick_failed` events during the intentional schema damage were expected. This scratch harness is not a shipped npm command; reproducible schema-failure coverage is in the committed test sources.

Actual logs are retained locally in `.local/task2/verified-*.log`. Earlier results and failures were investigated, not silently discarded: the intermediate focused run was rerun at **89/89**; initial Task 2 reproduction was **4 failed / 4 passed**; review-specific filtered runs produced **6 failed / 1 passed / 87 unselected** and **1 failed / 29 unselected** before fixes. An initial catalog cast error and a CloudFormation dependency cycle were corrected. Synthesis originally staged duplicate source/config files under `.local/task2`, causing **308 lint errors**; only those confirmed generated directories were moved to the existing ignored `cdk.out` tree, and lint passed without changing lint rules or excluding application source. Final full suites have no skips.

Remaining nonfatal warnings: MapLibre chunk above 900 kB, Lambda bundle-size notices, 84 unset CDK feature flags, existing optional receipt `logRetention` deprecation, and browser `NO_COLOR`/`FORCE_COLOR` notices. No SQL migration was added: this recovered release has 001–007, not 008. Emergency-workflow repairs remain out of scope. Prior published Task 1 ZIPs were not replaced with Task 2 artifacts. Local passes do not establish live deployment readiness.

## Source package baseline — 29 October 2026

See [PACKAGE_VERIFICATION.md](PACKAGE_VERIFICATION.md) for uploaded ZIP comparison, backups and full scope. Both uploads contain the same compatible lockfile; it was preserved unchanged. The stronger existing workspace demo-auth fix was reconciled with uploaded repair coverage and proxy-header checks.

- **PASS:** `npm ci --cache .local/npm-cache --no-audit --no-fund`, 391 packages in 12s; `npm ls --all`, exit 0. First default-cache install and test invocation failed with `/home/agent/.npm/_cacache` ENOENT; retry used a writable cache, not new dependencies.
- **FAIL before reconciliation:** 9 failed / 60 passed focused cases, identifying missing proxy-header checks and valid 127/8 loopback compatibility. No assertions were removed to fix these failures.
- **PASS:** focused security, **69/69**, two files, 3.25s; full suite, **122/122**, four files, 13.61s; no skips.
- **PASS:** browser suite, **11/11**, 1.4m, against a separate local `_test` database with simulated notifications.
- **PASS:** lint, TypeScript, production build and local smoke against the built API, exit 0. Existing large MapLibre bundle warning and harmless browser color-environment warnings remain.
- **PASS:** candidate ZIP CRC/path/category/hash checks; fresh extraction contains all manifests/lockfile; clean `npm ci` installs 391 packages in 10s; extracted security suite **69/69**, 3.58s. Lockfile hash remains unchanged after installation.
- **NOT RUN:** native Windows/PowerShell, physical remote clients, transparent tunnels, live Cognito/AWS, or an npm vulnerability audit. Package transport/download in the user's chat client cannot be verified here.

No missing readiness/production-validation/emergency-workflow changes or migration 008 were implemented. The 28 October results below are historical runs, not replacements for this baseline.

## Demo-authentication reconstruction — 28 October 2026

Source baseline is the user's uploaded `Response-Local (1).zip`, verified byte-for-byte against the existing checkout. **Only demo-authentication security was reconstructed.** See [DEMO_AUTH_REPAIR.md](DEMO_AUTH_REPAIR.md) for route coverage, changed files, safe Windows application and limits.

- Original suite before changes: **PASS, 47 tests / 2 files**, 6.93s.
- New pre-fix regressions: **24 failed / 4 passed**, reproducing the exposed login/proxy/cookie paths. No network-facing server was opened; remote socket peers were explicitly simulated on loopback listeners.
- Final targeted suite: **PASS, 34 tests**, 3.31s. Final full suite: **PASS, 81 tests / 3 files**, 13.05s, no skips. Original tests retained.
- Browser suite: **PASS, 11 scenarios**, 1.3m. Two earlier 10-pass/1-fail runs timed out at the duty control; an added load wait fixes the existing test's immediate-visibility race without removing assertions or changing GPS behavior.
- TypeScript, lint and production build: **PASS**, exit 0. Existing large MapLibre chunk warning remains.
- Intermediate Vite plain-text rejection parsing/timeouts and test-header typing errors were corrected and rerun; full details/log paths are in the repair report.
- **NOT RUN:** native Windows/PowerShell execution, physical remote clients, transparent tunnelling, live Cognito/provider acceptance or AWS deployment. No AWS resources provisioned. Missing readiness/configuration/workflow fixes and migration 008 are not part of this repair.

## Local UI release — 26 October 2026

The final source passes ESLint, TypeScript, production build and **47 unit/integration tests** (2 files). A clean combined Playwright run passes **11 scenarios** (the existing 7 workflows plus 4 presentation checks), with none skipped. `npm run setup:demo` again passed frozen installation, Docker database startup, migrations and seed. `npm run dev:demo`, `doctor:local` and `smoke:local` also passed: all three local ports, database readiness, fixture session, scoped report query and logout. Four final light/dark desktop/mobile screenshots are in `docs/design-previews/`. These checks ran on Linux/Chromium; native Windows remains unverified.

Each requested design stage (tokens/sign-in, shell, shared pages) passed build, the 47-test suite and the existing seven browser workflows before the final combined checks. The added browser checks cover remembered sidebar collapse, keyboard shortcuts/dialog, notification disclosure, stable row sorting, 360px light/dark layouts across the main views, reduced motion, persistent emergency notice and 4.5:1 contrast for the authored token pairs. This is targeted accessibility evidence, not full accessibility certification.

Testing found and fixed mobile overflow from long incident filters and admin dropdowns. The new test initially measured a table before its account rows loaded and matched only part of the banner's combined text; it now waits for actual account data and checks the existing banner. A pre-existing supplementary-update assertion could observe the saved paragraph before the textarea reset after tracking refresh; the original assertion is preserved and now waits for the form's successful clearing first. No tests or assertions were removed.

The complete rapid page traversal also exhausted the normal per-user request limit. Playwright's managed server now explicitly uses the **existing NODE_ENV=test limits** and the local notification simulator. Application/default local/production limits are unchanged; this suite does not validate production throughput limits. Stop an existing dev server before testing, or use `CI=1` on Linux to require the managed server. The final 11-pass run used a fresh managed server.

Provider maps, local-browser physical GPS, actual email/SMS, hosted authentication and AWS deployment are not claimed as tested. The map fallback and simulated coordinates remain explicit. Earlier Docker/infrastructure/polling checks below describe their recorded releases; this visual update does not imply new live-provider acceptance.


## Latest operational redesign verification

Executed locally on Linux with Node 24, PostgreSQL 16/PostGIS 3.5 and Chromium; the container uses Node 22. No live provider acceptance or native Windows run is claimed.

| Check | Actual result |
|---|---|
| `npm run setup:demo` | Passed: locked dependency install, preserved Docker volume, migrations through 007, repeatable fixture seed |
| `npm run lint` | Passed |
| `npm test` | **47 passed**, 2 files, none skipped |
| `npm run test:e2e` | **7 passed** with SSE; **7 passed** with `REALTIME_TRANSPORT=poll` |
| `npm run build` (includes TypeScript) | Passed; lazy MapLibre chunk size warning remains |
| `npm run cloud:plan` + `npx tsx scripts/verify-infra.ts cdk.out/academic/DisasterResponse-academic.template.json` | Passed: offline default academic template/security checks |
| Optional SES/pipeline/analytics offline synthesis | Passed with synthetic configuration; one `ses:SendEmail` grant, worker only, exact sender identity; pipeline present |
| `DOCKER_CONFIG="$PWD/.local/docker-config" bash scripts/build-container.sh` | Passed with TLS verification intact; production install reported 0 vulnerabilities |
| New container with explicit nonproduction fixture config + `SMOKE_API_ORIGIN=http://127.0.0.1:4001 npm run smoke:local` | Passed DB readiness, cookie sign-in, scoped list and logout; temporary container removed |
| Native Windows and live Cognito/SES/SMS/S3/Location/hosted acceptance | Not run |

New coverage verifies loopback-origin boundaries, missing fixture guidance, scoped aggregates beyond 30 rows, literal search/priority/filtering, hazard fields, immutable/idempotent supplements, closed-report rejection, outcome requirements, current-cycle acceptance pause, decline/access revocation and recipient-specific notification links. A simulator test drains bounded batches while asserting **zero SNS/SES sends**. A stubbed SES acceptance test verifies SUBMITTED rather than DELIVERED.

The seven browser cases cover the citizen→authority→rescuer lifecycle and outcomes; mobile session/GPS/layout; admin scopes; organization/announcement/metrics workflows; separate development login and failed session refresh; queue filters/report hazards/supplements/empty map; and revoked sessions/unconfigured Cognito. Browser geolocation is controlled test data. Screenshots under ignored `test-results/` contain local fixture data, not actual emergencies.

The first expanded browser run found three failures: shared-IP API throttling affected multi-role sessions, and a filter lacked an unambiguous accessible label. The implementation now limits authenticated API traffic per user, retains separate IP-based auth limits, and explicitly labels filters. The full suites passed after correction; no failing tests were deleted or skipped. Earlier compile/lint issues and the bounded simulator-test backlog were also resolved and rerun.

Run the same checks from [START_HERE.md](../START_HERE.md). Stop an existing development server before browser testing so Playwright starts the intended isolated configuration. The standard test database must end in `_test`; browser tests write labelled fixtures to the development database. Never use an operational database.

## Historical verification record

The sections below describe earlier releases, including their then-current counts and startup behaviour. The latest results and explicit `setup:demo` / `dev:demo` commands above supersede them.


Validation performed locally on 24 October 2026, using Node 24 on the host, Node 22 in the container, PostgreSQL 16 / PostGIS 3.5, and Chromium. No live AWS services were provisioned or used for acceptance testing.

| Command / check | Actual outcome |
|---|---|
| `npm run lint` | Passed |
| `npm run typecheck` / `npm run build` | Passed; MapLibre's lazy-loaded map bundle has a size warning |
| `npm test` | **41 passed**, 2 files; no skipped tests |
| `npm run test:e2e` | **4 passed** with SSE and polling; no skipped scenarios |
| `npm run infra:check` | Synthesis plus private-network/encryption/MFA/queue/scheduler/budget/secret-output assertions passed |
| `npm run infra:synth -- -c analytics=true -c pipeline=true --quiet` | Passed; optional resources defined only |
| `npm audit --omit=dev --audit-level=high` | 0 vulnerabilities reported |
| `npm run setup:local` | Node-based setup: frozen reinstall, existing volume startup, repeatable migrations/seed passed on Linux |
| `bash scripts/build-container.sh` | Image built with TLS verification intact using the managed proxy/CA |
| `npm run dev:local` + `npm run smoke:local` | Passed from the saved local launcher; API, Vite and worker running |
| Container HTTP smoke | Liveness, DB readiness, cookie sign-in/profile and scoped incident list passed |
| `aws sts get-caller-identity --region ap-south-1` | Failed: configured environment identity profile unavailable |
| Live Cognito/S3/SMS/SQS/RDS/Location/Amplify checks | **Not run**; account/configuration/provisioning prerequisites remain |

## Isolation and safety

`npm test` requires a database name ending in `_test`. It resets only that schema. `npm run setup:demo` creates `response_test`; `TEST_DATABASE_URL` can select another explicitly named test database. Never point it at operational data. Unit/integration tests run sequentially because the integration file exercises a full workflow and carefully restores SDK/configuration stubs.

The default browser tests use the separate development database and clearly labeled demo accounts, create controlled incidents and administrative fixtures, and exercise mocked browser geolocation. They never claim physical GPS validation or real SMS delivery. Browser screenshots/traces are generated under ignored `test-results/`.

## Coverage that can fail

- A $0-budget deployment guard refuses paid provisioning before accessing credentials or AWS, even with a stale approval flag.
- Strict report validation and role injection rejection; illegal incident/assignment transitions; critical escalation and stale-location/ETA presentation.
- Locally signed Cognito-shaped JWT verification: signature/key, issuer, token use, client and expiry. **This is not a live Cognito sign-in/refresh test.**
- Real database persistence, SRID/spatial radius, department/jurisdiction scope, unrelated-citizen denial, on-duty/qualification eligibility and capacity-lock concurrency.
- Immediate control-room record creation, duplicate reports/events, persisted no-team escalation, a separate worker process recovering deadlines, and reopened-incident response cycles.
- Responder acceptance distinct from authority dispatch; en-route/arrival/completion; authorized tracking, stale GPS and tracking cessation.
- Append-only history/audit triggers and production-style runtime-role denial of DDL/audit/schema-ledger mutation.
- Resource over-allocation, authority-only notices, sensitive publication denial, suspension, permission-change session revocation, logout location stop, pagination validation, and DB-failure readiness.
- SDK-stubbed SNS acceptance/ambiguous failure and duplicate suppression; failed outbox publication/recovery; S3 verified-version finalization outside the writable upload prefix. No external call is represented as a provider integration pass.
- Local Lambda event handler partial-batch failure and duplicate records.
- Browser scenario: citizen report → authority acknowledgement/offer → rescue acceptance → authority dispatch → active tracking → en route/arrival/in progress/completed → citizen resolved view → logout.
- Browser mobile scenario: persistent cookie session, automatic GPS capture, manual location inputs and no horizontal overflow.
- Browser admin scenario: protected department and jurisdiction forms, configuration outcomes and notification-status visibility.

## Investigated failures corrected

Initial checks caught a type/import mismatch, a test-runner API change, a sign-in rate limit incorrectly counting ordinary session/config requests, a CloudFormation migration dependency cycle, and reopened incidents incorrectly treating previous dispatch as a current response. A final launch check also caught a changed dependency CLI path and environment-file propagation issue; the explicit `dev-local.mjs` launcher now forwards the loaded environment and passes a sign-in/database/logout smoke check. Each affected check was rerun after correction.

Docker initially lacked the managed proxy DNS mapping and CA trust context. `build-container.sh` supplies the existing proxy hostname mapping and mounts the CA only at build time; npm signatures/integrity and TLS checks stay enabled. The proxy certificate and credentials are not copied into image layers. Plain `docker build` remains appropriate in an ordinary network; the helper supports this managed environment.

## Windows local setup correction

The reported Windows failure occurred before installation: PowerShell resolved `bash` to an unavailable WSL shell. `setup:local` now runs a Node script with no shell-specific environment assignments. It checks Docker, installs dependencies into the existing checkout, preserves an existing `.env`, creates it when absent, and prepares the demo and test databases. The development launcher invokes npm through Node without shell quoting and provides a useful message when `.env` is missing. Playwright passes `AUTH_MODE` through its environment configuration instead of POSIX command syntax.

For this correction, setup, lint, typechecking, development startup, the database/session smoke check, and all three browser scenarios (including automatic server startup) passed on Linux. A missing-environment check from a directory containing spaces also passed. Native Windows execution remains unverified in this environment. At that point the paid-deployment guard test still used Bash; the Windows handoff below replaces it with a shared Node guard.

## Remaining acceptance gates

After approved AWS provisioning, run a real-identity and real-provider version of the workflow: Cognito enrollment/session renewal/revocation, least-privilege S3 and DB access, provider route results, bounded queue retries and DLQ recovery, validated SMS sandbox receipt handling, deployed SSE/cookies, alarm notification and RDS restore. Validate rate limits/load, timezone and jurisdiction edge cases, accessibility, malicious evidence handling, and operational policies before any real emergency use.

## Academic expansion checks

The new tests exercise PKCE login/registration/recovery redirects without contacting Cognito, organization deactivation and qualification expiry, scoped metrics, announcement revision/withdrawal, duplicate/out-of-order SMS receipts, encrypted three-dataset analytics exports using an S3 stub, private/public resource locations, bounded address search using a Location stub, and the unapproved academic-deployment guard. No test result represents live Cognito, SNS, S3 or Location acceptance.

The test database now runs the actual ordered migration runner, including management/receipt and resource-location migrations. An added analytics test exposed a reserved SQL alias in the previous export path; it was corrected and the test rerun. The initial integration run encountered a stopped local database; Docker was started before rerunning successfully.

Native Windows remains unverified here. The Windows handoff removes the test suite's Bash dependency; the optional legacy custom-domain deploy/cleanup scripts still use Bash. The academic template's internal ALB/HTTPS gateway, database privacy, MFA and no-secret-output checks are local template assertions, not a deployed networking test.

Release verification on 25 October 2026: the updated Node 22 container built successfully and passed database readiness, cookie sign-in, scoped incident listing and logout. The first smoke request arrived before container startup completed; it passed after the startup event. The managed build used a writable ignored Docker configuration directory because the default home directory was read-only. No application TLS checks were disabled.

The identity-only template, default-hostname academic template and custom-domain reference all synthesized successfully. The optional pipeline/analytics/SMS-receipt-subscription variant also synthesized, using a clearly synthetic account ID solely for the template test. The academic template includes three Glue tables; local security assertions passed for private database/tasks, internal ALB/VPC Link, MFA, redrive, scheduler, migrations, budget and secret-free outputs. These remain undeployed definitions.

Default-authentication checks now verify that normal startup cannot enter fixture mode. The deployment-guard test uses an explicitly unapproved temporary configuration, so configuration cannot cause these tests to invoke AWS. Local fixture setup/startup commands are now `setup:demo` / `dev:demo`; normal startup uses Cognito.


## Live account preflight — 25 October 2026

- Historical account-specific preflight details are omitted; current account access and eligibility are unverified.
- `aws freetier get-account-plan-state --region us-east-1` confirmed ACTIVE FREE, [historical account credit balance redacted], and expiry on [historical account expiry redacted].
- Historical account-specific preflight details are omitted; current account access and eligibility are unverified.
- The installed CLI rejects `--no-cli-pager`; read-only checks were rerun without that option. Cloud deployment requires a compatible AWS CLI before using the existing helper.
- No resources were provisioned, no account plan was changed, and no application/provider acceptance tests were claimed. No credentials were printed or committed.


## VS Code / Windows source handoff — 25 October 2026

- Added root `START_HERE.md`, VS Code tasks, and `docs/AWS_WINDOWS_DEPLOYMENT.md` covering installation, real Cognito accounts, every service, full hosted deployment, frontend upload, first administrator/invitations, optional pipeline, live acceptance and cleanup.
- Replaced the Bash-dependent paid-policy unit test with a Node policy guard shared by the legacy deploy script. The full suite passed: **41 tests, 2 files** on Linux. Native Windows execution is still pending on the user's computer.
- ESLint, TypeScript and production build passed. The existing MapLibre bundle-size warning remains. No application/UI changes require a new browser acceptance claim; the prior four SSE/polling browser scenarios remain the recorded browser evidence.
- Corrected CloudWatch's notification metric filter to reference the worker's configured log group. Added a synthesis assertion comparing the filter and Lambda log-group references; academic synthesis and assertions passed, both with and without the optional pipeline. The pipeline preview used a synthetic connection ARN solely for synthesis and included one CodeBuild project, one CodePipeline and three Glue tables; no connection or resource was created.
- An initial account-bound preview was denied on `ec2:DescribeAvailabilityZones` by the same Organizations SCP. `cloud:plan` now explicitly synthesizes an environment-agnostic preview with lookups disabled; actual deployment still resolves the real account/region/AZs and requires permissions. The offline preview passed; it is not evidence that AWS permitted deployment.
- AWS helpers disable the pager through `AWS_PAGER` rather than a CLI-version-specific flag and expose the actual preflight failure reason. The new frontend PowerShell helper verifies local outputs against the live stack, keeps signed upload URLs in memory and checks publication/readiness. Its live execution and native PowerShell behavior have not been tested in this Linux environment.
- Added a portable official RDS CA download/parse helper; syntax checked, with no CA refresh/network download claimed. Optional CodeBuild now includes the production dependency audit.
- No cloud resources, emails, invitations, SMS or deployments were created during this source handoff.

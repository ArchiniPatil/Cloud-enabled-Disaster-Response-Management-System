# Demo-authentication repair — 28 October 2026

**29 October package reconciliation:** see [PACKAGE_VERIFICATION.md](PACKAGE_VERIFICATION.md) for the current source/ZIP provenance, preserved lockfile and fresh verification. The historical updater/patch described below predates that reconciliation. The current shared guard also accepts validated IPv4 loopback addresses in `127.0.0.0/8` (including IPv4-mapped peers) and rejects `X-Original-Host`, `X-Original-URL` and `X-Rewrite-URL`. Host/origin restrictions remain canonical; no remote subnet is permitted.

This change addresses **demo authentication only**, using the user's uploaded `Response-Local (1).zip`. Its 123 files matched the existing checkout byte-for-byte before editing. Archive SHA-256: `605a2c064d0960472cfa42bf5675e6fa7fab41fd602dd1e423ba84aea0538703`. The underlying checkout was `eb9e622e5c09fce799509efd90cf1984f8587c72`. Pre-existing untracked preflight/download artifacts were preserved and are not part of this repair.

The Windows project cannot be edited remotely from this workspace. The supplied single-file PowerShell updater applies only this repair's changed files in place; it is not a replacement project ZIP. No database migration, schema change, AWS operation, provider change, UI redesign or emergency-workflow reconstruction was performed. The missing broader readiness/configuration and migration-008 workflow work remains outstanding.

## Exposure and session paths

The uploaded npm web command used `vite --host 0.0.0.0`. Vite proxied `/api` to `127.0.0.1:4000`; the backend saw the proxy's local socket. The demo login required an allowed Origin but did not check the original transport/Host/proxy metadata. Clients can forge Origin. Existing cookies could also bypass a login-only restriction.

| Path | Role in authentication / repair |
|---|---|
| `POST /api/v1/auth/demo` | Password-free fixture session issuance through `newSession`. Now covered by the backend local guard and requires an active allowlisted profile with a `demo:` subject; a real identity sharing a fixture email is rejected. |
| `GET /api/v1/auth/me` | Authenticates existing cookies and may renew expired fixture access; local guard runs first. |
| `/api/v1/admin/*`, other protected API routes, incident SSE | All pass through `authenticate` after the demo guard. Old Admin cookies do not grant a non-loopback client access. The SSE route also checks session validity periodically; initial admission is guarded. |
| `POST /api/v1/auth/logout` | Cookie authentication and CSRF remain required; local guard precedes them. Existing location/session cleanup remains unchanged. |
| `/auth/login`, `/register`, `/recover` | Cognito redirects, not alternative fixture login paths. Existing mode/configuration requirements remain. |
| `/auth/callback` | The other caller of `newSession`, after Cognito state/PKCE/access+ID token verification. Now unavailable in demo mode and rejects a fixture subject. |
| `authenticate` | Checks profile status/session version, then rejects fixture subjects **or absent encrypted provider refresh material** in Cognito mode before the unexpired-access shortcut. Covers unexpired fixture cookies and fixture sessions whose profile subject was later changed. |
| `scripts/seed.ts` | Creates `demo:` identities only in explicit nonproduction demo mode; does not issue cookies. Existing guard is retained. |

## Enforced boundary

- Shared `localRequestOnly` reads `req.socket.remoteAddress`, not `req.ip` or forwarding claims. Only `127.0.0.1`, `::1`, and `::ffff:127.0.0.1` are accepted.
- Require exactly one Host header naming localhost, 127.0.0.1 or [::1], with a valid optional port. Reject foreign/malformed/missing/duplicate Host.
- Reject `Forwarded`, every `X-Forwarded-*`, Via, X-Real-IP, CF-Connecting-IP, True-Client-IP and Fastly-Client-IP, including values claiming localhost. Reject a noncanonical/non-loopback Origin when supplied, and cross-site fetch metadata.
- Backend applies the guard to **every demo API request before CORS/OPTIONS and authentication**, including reads and existing-cookie reuse/renewal. No mutation to the session occurs on the rejected remote renewal path.
- Vite dev and preview bind to `127.0.0.1` and use the guard before proxying. The wildcard npm argument is removed. The guard remains present if someone overrides a listener option; no wildcard listener was opened in testing.
- Vite alone permits cross-site GET **navigation** to the exact `/api/v1/auth/callback` path, preserving local Cognito redirects. All transport/Host/Origin/forwarding checks remain. The demo backend never enables that exception; Cognito still enforces OAuth state/PKCE/token checks. Tests reach invalid-state rejection without contacting Cognito.
- Demo configuration requires canonical loopback APP_ORIGIN and API_ORIGIN, with no path/credentials/query. Existing production demo prohibition remains. Existing CSRF, role/department/jurisdiction checks, cookie attributes and production proxy handling remain intact.

**Threat-model limit:** a trusted local process can connect to loopback. A transparent local relay that strips/rewrites all identifying metadata can look identical to that process. These checks cannot guarantee rejection of such a relay while preserving password-free local access. Do not publish demo ports, forward them through tunnels, or use demo mode on a shared/untrusted machine. A stronger boundary needs an authenticated capability/client certificate or OS isolation. No new secret or bypass configuration was introduced.

## Verification and actual failures

Linux Node 24.19.0/npm 11.9.0, PostgreSQL 16/PostGIS 3.5 and Chromium. Only dedicated local `_test` databases were reset/seeded; operational project data was not reset. Every actual application/test listener bound to `127.0.0.1`. Non-loopback socket addresses are **test-only simulations**, not requests from a physical remote machine. Vite proxying, session persistence and cookie reuse are real local HTTP/database operations. No simulation hook is installed in production code.

| Check | Actual result |
|---|---|
| Uploaded baseline's existing tests | **PASS — 47 tests, two files**, 6.93s, before implementation changes. |
| Initial security regressions against unmodified code | **FAIL as expected — 24 failed / 4 passed**, 28 cases, 3.89s. Reproduced remote-peer Admin login/cookie reuse, spoofed proxy headers, invalid metadata, dev/preview proxy bypass, Cognito fixture reuse and unsafe configuration. |
| Final focused regressions | **PASS — 34 tests**, 3.31s, no skips. Additional checks cover missing/duplicate Host, unknown peers, trust proxy, changed profile subjects, callback-mode isolation, binding configuration and Cognito callback-navigation compatibility. |
| Full suite | **PASS — 81 tests, three files**, 13.05s, no skips; original 47 tests retained. |
| Browser suite | **PASS — 11 scenarios**, 1.3 minutes. Local fixture flows, not live Cognito. |
| TypeScript, lint, production build | **PASS**, exit 0; build includes frontend/API/worker/Lambda/migration bundles. Existing large MapLibre chunk warning remains. |
| In-place patch verification | **PASS** — `git apply --check` and actual patch application to a temporary copy of all uploaded files; all 15 changed-file hashes matched and every other uploaded file remained unchanged. Embedded PowerShell payload matches the same bytes. This does not verify native PowerShell execution. |
| Native Windows / physical non-loopback client / transparent tunnel / live Cognito / AWS | **NOT RUN**. No deployed-service validation is claimed. |

Intermediate errors are not counted as passes:

1. After the first implementation, 26/28 focused cases passed; two Vite cases timed out with two unhandled JSON parsing errors because Vite's own Host rejection returned plain text. The test HTTP reader now respects Content-Type. HTTP status and authentication assertions were preserved.
2. TypeScript rejected the heterogeneous test-header objects against `Record<string,string>`. The helper now accepts optional header values, matching Node's HTTP request type. Runtime validation was not relaxed.
3. Two browser runs each had **10 passed / 1 failed**, timing out waiting for “Share device location.” The screenshot showed an off-duty team with “Start duty” available. The immediate `isVisible()` check had run before team data loaded. One added wait for the Start/End duty control fixes that test race. No existing assertions, browser scenarios or application GPS behavior were removed or changed. A fresh dedicated database full run then passed all eleven.

Evidence logs: `.local/auth-repair/baseline-existing.log`, `before-fix.log`, `targeted.log`, `full.log`, `browser.log`, `typecheck.log`, `lint.log`, `build.log`, and saved intermediate failure logs. Ignored logs/traces are not shipped as source.

Repeat locally after the in-place repair (Docker must be running):

```powershell
npm run setup:demo
npx vitest run tests/local-access.test.ts
npm test
npm run typecheck
npm run lint
npm run build
# Stop any running app before this command so Playwright starts its managed server:
npm run test:e2e
```

`setup:demo` installs dependencies/migrates/seeds the existing explicit local demo workflow; it is **not** required just to apply the patch and is never a production command. Tests reset the dedicated `response_test` database by default; `TEST_DATABASE_URL` must point only to a disposable database ending in `_test`. Browser tests add labelled fixtures to the configured local demo database. The repair itself does not change actual `.env` files, databases, dependencies or infrastructure.

## Apply to the existing Windows folder

Save `Apply-Response-DemoAuthFix.ps1` outside or inside the existing project. Stop its npm processes and close unsaved edits to affected files. Run from PowerShell, using the actual saved script path:

```powershell
$project = 'C:\Projects\Response-Previous'
powershell -NoProfile -ExecutionPolicy Bypass -File .\Apply-Response-DemoAuthFix.ps1 -ProjectRoot $project -CheckOnly
powershell -NoProfile -ExecutionPolicy Bypass -File .\Apply-Response-DemoAuthFix.ps1 -ProjectRoot $project
```

The updater compares each affected file against the uploaded ZIP's SHA-256 or the already-patched SHA-256. Any unexpected local edit/missing file/conflicting new file aborts **before changes**. Successful updates preserve backups under `.local/auth-repair-backup-*`; already-patched files are skipped. It contains the exact changed-file bytes, no secrets, does not unpack a project ZIP, and does not run npm, database or AWS commands. Do not force it past a mismatch: review/merge your local changes first. The alternative `Response-DemoAuthFix.patch` can be checked with `git apply --check` before `git apply`, including in an extracted folder with Git installed.

The updater's payload/diff can be verified locally against this source. **Native PowerShell execution is not claimed as tested in the Linux workspace.** Review the script before execution; ExecutionPolicy Bypass applies only to that process. Existing downloaded project archives remain older artifacts and must not be mistaken for this patch.

## Every changed project file

| File | Reason |
|---|---|
| `packages/core/src/local-access.ts` (new) | Shared transport/Host/Origin/forwarding guard; narrow Vite OAuth-navigation option. |
| `apps/api/src/app.ts` | Apply guard before any demo API route or cookie use. |
| `apps/api/src/auth.ts` | Reject fixture cookies in Cognito; isolate callback mode; prevent fixture login for nonfixture profiles. |
| `apps/api/src/config.ts` | Validate both demo origins with the canonical loopback parser. |
| `apps/web/vite.config.ts` | Loopback dev/preview bindings and pre-proxy checks, preserving Cognito callback navigation. |
| `apps/web/package.json` | Remove wildcard host override. |
| `tests/local-access.test.ts` (new) | 34 regression cases, all actual listeners on loopback; explicitly simulated hostile peers. |
| `tests/browser/workflow.spec.ts` | Add a wait for loaded duty controls; retain every existing assertion. |
| `.env.demo.example` | Document canonical local origins, cookie-mode separation and no tunnelling. |
| `.env.example` | Document local Vite restriction and Cognito session requirements. |
| `LOCAL_TEST_WALKTHROUGH.md` | Document repaired local boundary and focused scope. |
| `docs/SECURITY.md` | Explain enforcement, OAuth compatibility and transparent-relay limitation. |
| `docs/TESTING.md` | Record actual baseline/failing regressions/final results and limitations. |
| `docs/IMPLEMENTATION_STATUS.md` | Record auth-only reconstruction; do not imply other missing fixes are restored. |
| `docs/DEMO_AUTH_REPAIR.md` (new) | Route inventory, evidence, file explanations and Windows handoff. |

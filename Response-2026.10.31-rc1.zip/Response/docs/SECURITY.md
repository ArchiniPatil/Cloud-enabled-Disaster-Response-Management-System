# Security and privacy

## Workflow scope and integrity — Task 3, 30 October 2026

Incident ownership grants the Citizen role access to its own reports; historical reporter ownership cannot bypass Authority department/jurisdiction or Rescuer assignment scope. Team mutations check membership/scope independently of incident visibility. Incident closure cannot let an Authority cancel another department’s team. Backend-derived frontend action lists supplement, and never replace, server authorization.

State changes, phase deadlines, notifications and audit writes commit transactionally. Geographic and deadline workers lock incident before execution rows, with idempotent persisted outcomes. Deadline expiry is a human-review signal, not evidence of dispatch or field failure. Resource updates return not found before auditing missing rows; stock allocation and use lock inventory.

GPS sharing survives same-tab navigation but still requires explicit consent and current team/session authorization. Citizens receive response/tracking state without precise responder coordinates or route distance. Browser background delivery and multiple-tab/device behavior are not guaranteed. See [INCIDENT_WORKFLOW.md](INCIDENT_WORKFLOW.md) and [TESTING.md](TESTING.md). Task 1 fixture restrictions, Task 2 validation/TLS and existing IAM definitions are preserved.

## Readiness and production configuration — 30 October 2026

Production rejects fixture mode, absent/malformed database and Cognito settings, weak session/password material, contradictory secret sources and TLS bypasses. Loaded Secrets Manager payloads are also validated with redacted failures. Runtime database credentials are checked before administrative migration writes. Production PostgreSQL TLS verification remains mandatory. See [CONFIGURATION.md](CONFIGURATION.md) for exact rules and optional-provider handling; variable presence does not establish live provider connectivity or effective privileges.

Readiness checks the migration ledger and required schema (including append-only audit triggers), returns only ready/unavailable, and bounds acquisition/query/lock waiting. Liveness remains independent. Schema readiness does not certify data correctness, disk capacity, every privilege or an emergency-operational deployment. Task 1 transport/session boundaries remain unchanged and passed all 69 regressions again. Actual failures, fixes and unverified areas are listed in [POST_IMPLEMENTATION_AUDIT.md](POST_IMPLEMENTATION_AUDIT.md).

## Local fixture boundary — repaired 28 October 2026

The 29 October package reconciliation preserves these controls and merges the uploaded repair's rejection of `X-Original-Host`, `X-Original-URL` and `X-Rewrite-URL`. Socket parsing validates IPv4 syntax before accepting the loopback-only `127.0.0.0/8` range, including mapped addresses; `::1` is also allowed. Canonical Host/origin checks are unchanged. See [PACKAGE_VERIFICATION.md](PACKAGE_VERIFICATION.md) for current results and limits.

Vite dev and preview bind to `127.0.0.1`. The wildcard npm dev argument was removed. Vite checks every request before proxying; the backend independently checks every request while `AUTH_MODE=demo`, before CORS/OPTIONS, login, cookies and protected APIs. It requires a real loopback socket peer, exactly one canonical loopback Host, no forwarding/proxy metadata, and a canonical loopback Origin when one is supplied. Express `trust proxy` and client-supplied forwarding headers cannot establish locality. Cross-site fetch metadata is rejected. Existing CSRF and role/scope authorization remain unchanged.

For local Cognito development, only Vite permits cross-site **GET navigation to the exact `/api/v1/auth/callback` path**. Socket/Host/Origin/forwarding checks still apply; the backend's demo guard never enables this exception. Cognito still requires state/PKCE/token verification. The callback route rejects demo mode. This is not a public callback server.

Both configured demo origins must be canonical loopback origins. Production continues to reject demo mode at startup. Demo login requires the allowlisted active profile to have a `demo:` subject. Cognito rejects fixture subjects and sessions without encrypted provider refresh material before the unexpired-access shortcut; changing modes does not legitimize an old Admin fixture cookie. No session schema, secret or bypass flag was added.

**Limit:** a trusted local process can connect to loopback. A deliberately transparent local relay that rewrites Host/Origin and strips forwarding metadata can make remote traffic indistinguishable from a direct local connection. These checks do not authenticate the human at the keyboard and cannot guarantee isolation from such a relay. Never forward demo ports or use fixtures on a shared/untrusted machine. Stronger isolation would require an additional authenticated capability/client certificate or OS-level controls. Physical remote-machine/tunnel testing and live Cognito were not performed; regression socket peers are explicitly simulated on loopback-only listeners. See [DEMO_AUTH_REPAIR.md](DEMO_AUTH_REPAIR.md).

## Enforced boundaries

- Cognito authorization-code flow with PKCE, state cookie and single-use expiring database state. Backend RS256 verification checks issuer, expiration, token type and app client. ID token subject must match access token and email must be verified.
- Cognito production pool requires TOTP MFA for all users, stronger than privileged-only MFA. Deployment must validate managed-login enrollment/recovery behavior.
- Random 256-bit opaque session handles; only their hashes are stored. Refresh tokens are AES-256-GCM encrypted using a separate Secrets Manager key. Cookies are HttpOnly, Secure in production, SameSite=Lax, and path scoped. Access window is 15 minutes and sessions expire after seven days.
- Mutation requests require exact configured Origin and session-bound CSRF header. Session metadata is memory-only in the browser; no long-lived tokens in localStorage. Logout deletes local session, stops sharing and attempts provider refresh revocation.
- Profiles determine permissions; client role/owner injection is rejected by strict schemas. Authority department AND jurisdiction constraints are evaluated on the backend. Citizens see their own reports; rescuers see eligible assigned work only. All protected location reads apply incident and team authorization.
- Per-process IP rate limits protect API/authentication; JSON request limit 32 KiB. Scaling requires a shared rate-limit store or reviewed WAF policy; local limits are not a distributed abuse defense.
- Parameterized SQL, bounded result pages, assignment locks, resource-capacity locks, immutable audit/history/revision records and idempotent event consumption.
- Private encrypted S3 evidence: five attachments per report, JPEG/PNG only, five MiB maximum, signed upload policy, length/type/header checks, finalized copy outside the upload prefix, and short-lived authorized attachment downloads. Evidence authorization is checked before issuing a URL. These checks do not constitute malware scanning or full image decoding; add scanning and EXIF sanitization before operational use.
- RDS is private and encrypted; the runtime database login lacks DDL/role privileges and audit mutation. AWS IAM is separated between API, worker, migration, scheduler, pipeline and deployment. The API cannot read the database owner secret.
- No secrets in logs, source, frontend variables or CDK outputs. Structured application errors contain request IDs and event codes, not tokens, coordinates, phone numbers or report descriptions.

## Configuration obligations

Use approved short-lived AWS roles/SSO profiles. Do not put raw keys in chat or Git. `.env` is ignored; `.env.example` contains local-only disposable values. RDS trusts the official downloaded AWS CA bundle with verification enabled. Rotate database/app encryption secrets through a tested procedure: rotating the encryption key without re-encryption invalidates encrypted refresh sessions and requires sign-in.

Use same-site custom frontend/API HTTPS domains and test Amplify forwarding of cookies, Origin, SSE and cache headers. Cognito callbacks use the frontend `/api/v1/auth/callback` proxy path and must match exactly, so host-only session cookies are set on the correct browser origin. All sensitive responses use `Cache-Control: no-store`.

Controlled administrator bootstrap requires an existing verified, MFA-enrolled Cognito identity and database access through an approved operational path. The process is serialized and refuses when any admin exists. No reusable bootstrap secret or setup endpoint is created.

## Known deployment/security validation gaps

Live Cognito registration/MFA/renewal/revocation, RDS restore, S3 permissions and finalized-file flow, AWS Location route/map rights, SNS/SQS/Lambda retries, Amplify cookie/stream behavior and deployed IAM need approved AWS integration testing. Mocked provider-contract tests are not substitutes.

No independent penetration test, high-load test, official emergency-service integration, regulatory approval, medical triage validation, malicious-image scanner, or operational field validation has occurred. The system is not approved for actual emergency dispatch.

Operational admins can access sensitive records by design. Review governance, audit export, need-to-know permissions and jurisdiction-specific retention before real personal data is introduced. Public situation entries omit identity, free text, photos, IDs and exact location; sensitive categories are never published.

## Academic additions

The identity-only local workflow uses a separate unseeded database and ignored encryption-key file; it never enables fixture logins in Cognito mode. Initial administrator bootstrap still verifies email and TOTP and refuses if an administrator exists. Invitations use Cognito-generated temporary passwords delivered by email; no password is accepted or stored by application provisioning. Invitation resending is limited to pending invitations.

Organization deactivation and team configuration lock records and reject incompatible active assignments. Unpublished resource locations use role/department/jurisdiction/team scope; public listing is an explicit audited scoped-authority or administrator action. SMS feedback persists only provider IDs/outcomes from allowlisted log subscriptions.

The academic default-hostname template has HTTPS at Amplify/API Gateway and private HTTP between the gateway, internal ALB and tasks. It is an explicit demonstration tradeoff, not end-to-end transport encryption. Both cloud plans remain undeployed; independent penetration testing and real provider acceptance remain external gates.

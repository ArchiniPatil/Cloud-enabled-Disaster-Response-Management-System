# Incident workflow and operational rules

Task 3 implementation and review, 30–31 October 2026. Verification results are recorded separately in TESTING.md. These workflows coordinate platform users; notification delivery does not mean emergency services accepted or dispatched a response.

## Incident state and authority

The existing status vocabulary is retained. SUBMITTED is a report, NEEDS_VERIFICATION is triage, ACKNOWLEDGED is an authority-reviewed incident awaiting/holding assignments. Assignment OFFERED and ACCEPTED are separate from incident status. DISPATCHED, TEAM_EN_ROUTE and TEAM_ON_SCENE are driven by assignment milestones. IN_PROGRESS is an assignment state while the incident remains TEAM_ON_SCENE. RESOLVED, CANCELLED, DUPLICATE and UNABLE_TO_RESPOND are terminal; there is no redundant CLOSED state. REOPENED is a deliberate dispatcher operation with a fresh response cycle, not an ordinary assignment side effect.

Citizens can withdraw only their own unacknowledged reports; repeating that withdrawal is harmless. Citizens can add supplementary information to their own open reports. Authorities need DISPATCH permission and both matching department and geographic jurisdiction. Administrators can coordinate across departments. Rescuers can act only through their own team's assignment. Historical reporter ownership cannot grant Authority or Rescuer privileges outside their current role scope. Backend scope and state checks are authoritative; incident detail supplies permitted actions to the frontend.

Incident and assignment changes lock the incident before changing its assignments. Offering also locks the team, so its configured concurrent capacity cannot be oversubscribed. The existing active incident/team unique index prevents duplicate active offers. Different qualified teams may legitimately serve one incident. Their most advanced active milestone determines the aggregate incident state; cancellation of one team must not erase another team's on-scene status. Ordinary assignment and escalation reject terminal incidents.

## Assignment transitions

| From | Rescuer, own team | Dispatcher, scoped team |
|---|---|---|
| OFFERED | ACCEPTED, DECLINED, CANCELLED (unable) | CANCELLED |
| ACCEPTED | CANCELLED (unable) | DISPATCHED, CANCELLED |
| DISPATCHED | EN_ROUTE, CANCELLED (unable) | CANCELLED |
| EN_ROUTE | ARRIVED, CANCELLED (unable) | CANCELLED |
| ARRIVED | IN_PROGRESS, CANCELLED (unable) | CANCELLED |
| IN_PROGRESS | COMPLETED, CANCELLED (unable) | CANCELLED |
| COMPLETED / DECLINED / CANCELLED | None | None |

Acceptance does not record dispatch or arrival. Dispatch still requires a dispatcher; a rescuer cannot authorize their own dispatch. Decline, cancellation and completion require a reason/outcome of at least five characters. A repeated current-state acceptance does not add another audit or reset its deadline. An expired offer cannot be accepted even if the worker is temporarily stopped.

When the last active team withdraws, an operational incident returns to ACKNOWLEDGED for reassignment and control-room review; previous attempts remain visible. The last team's completed response can resolve an on-scene incident only after all active assignments have finished/withdrawn. An authority can close an incident CANCELLED or UNABLE_TO_RESPOND with a reason, cancelling its active assignments in the same transaction. An authority cannot use incident closure to cancel another department's teams; an administrator or the relevant dispatchers must coordinate that case. Field inability cancels the rescuer's assignment, not the entire incident.

## Durable deadlines and geographic review

Each policy has offer, dispatch and progress windows (defaults 120, 180 and 900 seconds; configurable 10–86400 seconds in Administration). A transition snapshots the relevant duration into `assignment_deadlines`. Editing policy windows affects subsequent phases, not already-promised deadlines. One pending deadline exists per assignment. Progress windows apply separately after dispatch, en-route, arrival and starting work; routine notes do not indefinitely extend them.

The worker processes due deadlines from PostgreSQL. Unanswered offers expire to CANCELLED with an explicit expiry reason and release capacity. Accepted-but-undispatched and stalled field phases retain their actual assignment and incident statuses and request CONTROL_REVIEW_REQUIRED. They do not manufacture decline, inability, dispatch or resolution. Review outcomes are persisted once; dispatchers must resolve the review by advancing, withdrawing or replacing the assignment. Phase changes supersede the prior deadline; terminal incident closure stops pending work.

Geographic escalation remains an eligibility alert, not automatic dispatch or an unsolicited assignment. Existing policy defaults are 5/10/25 km with cumulative response delays 0/60/180 seconds. Each ring is persisted with its radius, scheduled/completed timestamp and outcome. Active on-duty qualified teams must cover the incident jurisdiction, match a required department, have capacity and an authorized fresh location (at most 90 seconds old, accuracy at most 200 m). Incident location uncertainty reduces the usable search radius. Missing GPS never becomes an invented coordinate.

Automatic rings notify each eligible recipient once per response cycle. Explicit manual review can alert again with a distinct execution/reason. Acceptance pauses geographic expansion but retains the independent dispatch deadline. The final ring ends in regional review rather than an infinite loop. Workers lock the incident before claiming execution rows; repeated workers/queue deliveries are idempotent. No automatic assignment competes with a manual dispatcher offer.

## Location lifecycle and privacy

The sharing controller is mounted above in-app routes for the signed-in browser session. Ordinary navigation in one tab does not stop sharing. Sharing starts only by explicit consent; it stops on explicit disablement, off duty, logout, loss of authorization or an upload/network failure. The client verifies server authorization every ten seconds and requests fresh samples periodically, using the browser's actual sample timestamp. Permission denial stops the watch; unsupported GPS creates no session. Stale/inaccurate samples are not posted as fresh positions. No reload or login silently resumes sharing.

The browser may suspend geolocation/timers when hidden or closed. This is not native background tracking. If stop cannot reach the server, no further samples are sent; freshness excludes old coordinates and the bounded server session expires. Multiple tabs/devices still share the existing one-active-device-per-team boundary; use one tracking tab. A trusted transparent local relay remains outside Task 1's transport guarantees.

Citizens can see assigned-team response/tracking state and available ETA, but not precise responder coordinates/accuracy or route distance. Scoped authorities and assigned rescuers retain necessary operational coordinates. A team's configured duty flag remains separate from its active-assignment count: occupied capacity is derived, not silently set back to AVAILABLE when a field outcome is recorded.

## Shelters, resources and notifications

Shelters use the existing `SHELTER_CAPACITY` resource type. Total quantity is capacity; active reservations and occupied allocations share that capacity. RESERVED holds capacity, DISPATCHED records issued equipment or occupied shelter places, RELEASED returns it, and CONSUMED records used supplies while reducing total stock. Shelter capacity cannot be consumed. This is an aggregate capacity register, not a resident/patient identity database.

Scoped authorities/admins create and update inventory and locations; public listing is explicit and audited. Allocation locks incident and resource and refuses closed incidents or insufficient stock. Rescuers can report dispatch/use only for resources belonging to their own currently dispatched team and incident. Release is repeat-safe. Missing resource edits return 404 without success audit; state and audit writes share a transaction. Stock is nonnegative, and updates cannot reduce total below active allocations.

State changes generate audit entries and authorized notification jobs transactionally. Status outbox events and consumers retain unique logical-event keys. Provider acceptance, delivery, user acknowledgement and dispatch remain distinct. Development uses the existing labelled simulator; no real SMS/email is needed or sent in verification. Unknown provider submissions are not blindly retried; only definitive failures can be retried by an administrator under the existing attempt limit.

## Migration and rollback

Migration 008 is forward-only; 001–007 remain unchanged. It adds policy windows, assignment deadlines/indexes, escalation radius and allocation actor/state metadata. Existing active assignments get a full deadline window starting at upgrade; old timestamps do not cause immediate fabricated expiry. Existing released allocations become RELEASED; other allocations remain RESERVED, not assumed occupied or consumed. The readiness schema contract includes the new objects.

Stop old API/worker versions before applying the reviewed migration with owner credentials. Runtime roles receive DML access through the existing administrative setup, never DDL. Validate readiness before resuming API/worker traffic. Back up first in a real deployment. Older Task 2 binaries intentionally reject unknown migration 008, so rollback requires a compatible application/database restore pair or a reviewed forward fix. Live RDS backup/restore, IAM, Windows and physical GPS require separate validation; no cloud deployment occurred for Task 3.

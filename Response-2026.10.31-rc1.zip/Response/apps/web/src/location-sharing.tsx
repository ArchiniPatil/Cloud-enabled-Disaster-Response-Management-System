import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { api, post, ApiError } from "./api";
type Sharing = {
  active: boolean;
  busy: boolean;
  error: string;
  start: (teamId: string) => Promise<void>;
  stop: () => Promise<void>;
};
const Context = createContext<Sharing>({
  active: false,
  busy: false,
  error: "",
  start: async () => {},
  stop: async () => {},
});
export const useLocationSharing = () => useContext(Context);
// Mounted for the signed-in session, above Routes. No persistence or silent restart.
export function LocationSharing({ children }: { children: ReactNode }) {
  const [active, setActive] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [last, setLast] = useState(0),
    [clock, setClock] = useState(Date.now());
  const session = useRef<string | null>(null),
    watch = useRef<number | null>(null),
    generation = useRef(0),
    starting = useRef(false),
    stopping = useRef(false),
    timer = useRef<ReturnType<typeof setInterval> | null>(null);
  async function stop() {
    if (stopping.current) return;
    stopping.current = true;
    generation.current++;
    starting.current = false;
    if (watch.current !== null)
      navigator.geolocation?.clearWatch(watch.current);
    watch.current = null;
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
    const id = session.current;
    session.current = null;
    setActive(false);
    setBusy(true);
    setLast(0);
    if (id)
      try {
        await api(`/locations/sessions/${id}`, { method: "DELETE" });
      } catch {
        /* No more samples sent; server also expires/stales disconnected sessions. */
      }
    stopping.current = false;
    setBusy(false);
  }
  async function start(teamId: string) {
    if (starting.current || stopping.current || session.current) return;
    setError("");
    if (!navigator.geolocation) {
      setError(
        "Geolocation is not supported by this browser. Sharing has not started.",
      );
      return;
    }
    starting.current = true;
    setBusy(true);
    const token = ++generation.current;
    try {
      const s = await post("/locations/sessions", { teamId });
      if (token !== generation.current) {
        await api(`/locations/sessions/${s.id}`, { method: "DELETE" });
        return;
      }
      session.current = s.id;
      setActive(true);
      const receive = async (p: GeolocationPosition) => {
        if (token !== generation.current) return;
        const age = Date.now() - p.timestamp;
        if (
          !Number.isFinite(age) ||
          age > 60000 ||
          age < -5000 ||
          !Number.isFinite(p.coords.accuracy) ||
          p.coords.accuracy > 200
        ) {
          setError(
            "Location is stale or inaccurate. Waiting for a fresh accurate GPS sample.",
          );
          return;
        }
        try {
          await post("/locations/updates", {
            sessionId: s.id,
            latitude: p.coords.latitude,
            longitude: p.coords.longitude,
            accuracy: p.coords.accuracy,
            observedAt: new Date(p.timestamp).toISOString(),
          });
          if (token === generation.current) {
            setLast(p.timestamp);
            setError("");
          }
        } catch (e) {
          if (token !== generation.current) return;
          if (
            e instanceof ApiError &&
            ["OLD_SAMPLE", "STALE_SAMPLE"].includes(e.code)
          )
            return;
          setError(
            `${(e as Error).message}. Sharing stopped; enable it again when the connection and authorization are restored.`,
          );
          await stop();
        }
      };
      const denied = (e: GeolocationPositionError) => {
        if (token !== generation.current) return;
        if (e.code === 1) {
          setError("Location permission denied. Sharing stopped.");
          void stop();
        } else
          setError(
            "GPS unavailable or timed out. Waiting for a fresh position; old positions are not current.",
          );
      };
      watch.current = navigator.geolocation.watchPosition(
        (p) => void receive(p),
        denied,
        { enableHighAccuracy: true, maximumAge: 0, timeout: 15000 },
      );
      let pulses = 0;
      timer.current = setInterval(() => {
        setClock(Date.now());
        void api(`/locations/sessions/${s.id}`).catch(async (e) => {
          if (token === generation.current) {
            setError(`${e.message}. Sharing stopped.`);
            await stop();
          }
        });
        if (++pulses % 3 === 0)
          navigator.geolocation.getCurrentPosition(
            (p) => void receive(p),
            denied,
            { enableHighAccuracy: true, maximumAge: 0, timeout: 15000 },
          );
      }, 10000);
    } catch (e) {
      if (token === generation.current) {
        setError((e as Error).message);
        await stop();
      }
    } finally {
      if (token === generation.current) {
        starting.current = false;
        setBusy(false);
      }
    }
  }
  useEffect(() => {
    const unauthorized = () => {
      void stop();
    };
    window.addEventListener("response:unauthorized", unauthorized);
    window.addEventListener("response:stop-sharing", unauthorized);
    return () => {
      window.removeEventListener("response:unauthorized", unauthorized);
      window.removeEventListener("response:stop-sharing", unauthorized);
      void stop();
    };
  }, []);
  return (
    <Context.Provider value={{ active, busy, error, start, stop }}>
      {active && (
        <div className="notice success" role="status">
          {last && clock - last <= 90000
            ? "Your device is sharing operational location."
            : "Location sharing enabled; waiting for a fresh position."}{" "}
          <button onClick={() => void stop()}>Stop sharing</button>
          <small>
            Sharing continues across pages in this tab. Background tracking
            depends on the browser.
          </small>
        </div>
      )}
      {error && (
        <div className="notice warning" role="alert">
          {error}
        </div>
      )}
      {children}
    </Context.Provider>
  );
}

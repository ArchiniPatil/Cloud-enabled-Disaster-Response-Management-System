import { parseConfig } from "./config-validation.js";
export const config = parseConfig(process.env);

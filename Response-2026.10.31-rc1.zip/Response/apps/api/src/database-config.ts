import type pg from "pg";
import {
  type Configuration,
  strongSecret,
  validateDatabaseSecret,
} from "./config-validation.js";
// Loader is injected so resolved secret validation can be tested without AWS.
export async function databaseOptions(
  c: Configuration,
  load: (arn: string) => Promise<string>,
): Promise<pg.PoolConfig> {
  const options: pg.PoolConfig = {
    connectionString:
      c.DATABASE_URL ??
      "postgresql://response:local-development-only@127.0.0.1:5432/response",
    max: 10,
    connectionTimeoutMillis: 5000,
    statement_timeout: 15000,
  };
  if (c.NODE_ENV === "production") {
    // Strip validated sslmode before passing the URL to pg: URL SSL options
    // must not override our verified-TLS policy.
    if (c.DATABASE_URL) {
      const u = new URL(c.DATABASE_URL);
      u.search = "";
      options.connectionString = u.toString();
    } else options.connectionString = undefined;
    options.ssl = { rejectUnauthorized: true };
  }
  if (c.DATABASE_SECRET_ARN) {
    try {
      const value = JSON.parse(await load(c.DATABASE_SECRET_ARN));
      const s =
        c.NODE_ENV === "production" ? validateDatabaseSecret(value) : value;
      Object.assign(options, {
        connectionString: undefined,
        host: s.host,
        port: s.port,
        user: s.username,
        password: s.password,
        database: s.dbname ?? "response",
        ssl: { rejectUnauthorized: true },
      });
    } catch {
      throw new Error("Database secret could not be loaded or validated");
    }
  }
  if (c.SESSION_SECRET_ARN) {
    try {
      const key = await load(c.SESSION_SECRET_ARN);
      if (c.NODE_ENV === "production" && !strongSecret(key))
        throw new Error("Invalid key");
      c.SESSION_KEY = key;
    } catch {
      throw new Error("Session secret could not be loaded or validated");
    }
  }
  return options;
}

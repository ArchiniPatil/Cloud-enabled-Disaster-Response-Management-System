import { tick } from "./jobs.js";
import { pool } from "./db.js";
import { config } from "./config.js";
import { createReadinessCheck } from "./readiness.js";
const ready = createReadinessCheck(pool, () => config.READINESS_TIMEOUT_MS);
let stopping = false;
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => {
    stopping = true;
  });
while (!stopping) {
  try {
    if (!(await ready())) throw new Error("Database unavailable");
    await tick();
  } catch {
    console.error(JSON.stringify({ event: "worker_tick_failed" }));
  }
  await new Promise((resolve) => setTimeout(resolve, 2000));
}
await pool.end();

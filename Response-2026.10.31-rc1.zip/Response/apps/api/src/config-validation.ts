import { z } from "zod";
import { isIP } from "node:net";
import { isLoopbackPeer } from "../../../packages/core/src/local-access.js";
import { isLoopbackOrigin } from "../../../packages/core/src/local-access.js";
const schema = (env: Record<string, string | undefined>) =>
  z.object({
    NODE_ENV: z
      .enum(["development", "test", "production"])
      .default("development"),
    AUTH_MODE: z.enum(["cognito", "demo"]).default("cognito"),
    EVENT_TRANSPORT: z.enum(["aws", "database"]).optional(),
    REALTIME_TRANSPORT: z.enum(["sse", "poll"]).default("sse"),
    DATABASE_URL: z.string().optional(),
    DATABASE_SECRET_ARN: z.string().optional(),
    AWS_REGION: z.string().default("ap-south-1"),
    PORT: z.coerce.number().int().min(1).max(65535).default(4000),
    READINESS_TIMEOUT_MS: z.coerce
      .number()
      .int()
      .min(100)
      .max(5000)
      .default(2000),
    COGNITO_ISSUER: z.string().optional(),
    APP_ORIGIN: z.string().url().default("http://localhost:5173"),
    API_ORIGIN: z.string().url().default("http://localhost:4000"),
    COGNITO_POOL_ID: z.string().optional(),
    COGNITO_CLIENT_ID: z.string().optional(),
    COGNITO_DOMAIN: z.string().optional(),
    SESSION_KEY: z.string().optional(),
    SESSION_SECRET_ARN: z.string().optional(),
    EVIDENCE_BUCKET: z.string().optional(),
    EVENT_TOPIC_ARN: z.string().optional(),
    LOCATION_MAP_NAME: z.string().optional(),
    LOCATION_PLACE_INDEX: z.string().optional(),
    LOCATION_ROUTE_CALCULATOR: z.string().optional(),
    ANALYTICS_BUCKET: z.string().optional(),
    NOTIFICATION_TRANSPORT: z
      .enum(["aws", "simulator"])
      .default(
        env.AUTH_MODE === "demo" && env.NODE_ENV !== "test"
          ? "simulator"
          : "aws",
      ),
    EMAIL_FROM: z.string().email().optional(),
    SMS_ENABLED: z.enum(["true", "false"]).default("false"),
    LOCATION_RETENTION_HOURS: z.coerce
      .number()
      .int()
      .min(1)
      .max(168)
      .default(24),
    EMERGENCY_PHONE: z.string().optional(),
  });
export function parseConfig(env: Record<string, string | undefined>) {
  const parsed = schema(env).safeParse(env);
  if (!parsed.success)
    throw new Error(
      `Invalid configuration: ${[...new Set(parsed.error.issues.map((issue) => issue.path[0]))].join(", ")}`,
    );
  const config = parsed.data;
  if (
    config.EVENT_TRANSPORT === "database" &&
    (config.NODE_ENV === "production" ||
      config.DATABASE_SECRET_ARN ||
      !config.DATABASE_URL ||
      !localDatabase(config.DATABASE_URL))
  )
    throw new Error(
      "Database event transport is restricted to a local development database",
    );
  if (
    config.NODE_ENV === "production" &&
    (config.AUTH_MODE === "demo" ||
      (!config.SESSION_KEY && !config.SESSION_SECRET_ARN) ||
      !config.APP_ORIGIN.startsWith("https://") ||
      !config.API_ORIGIN.startsWith("https://"))
  )
    throw new Error(
      "Production requires Cognito, SESSION_KEY, and HTTPS origins",
    );
  if (
    config.AUTH_MODE === "demo" &&
    (!isLoopbackOrigin(config.APP_ORIGIN) ||
      !isLoopbackOrigin(config.API_ORIGIN))
  )
    throw new Error(
      "Demo authentication requires loopback app and API origins",
    );

  if (
    config.AUTH_MODE === "demo" &&
    (config.DATABASE_SECRET_ARN ||
      (config.DATABASE_URL && !localDatabase(config.DATABASE_URL)))
  )
    throw new Error("Demo mode requires a loopback-only development database");

  if (
    config.AUTH_MODE === "demo" &&
    (config.SMS_ENABLED === "true" ||
      config.EMAIL_FROM ||
      config.EVENT_TOPIC_ARN ||
      config.EVIDENCE_BUCKET ||
      config.LOCATION_MAP_NAME ||
      config.LOCATION_PLACE_INDEX ||
      config.LOCATION_ROUTE_CALCULATOR ||
      config.ANALYTICS_BUCKET)
  ) {
    throw new Error(
      "Local demo mode cannot enable billable AWS integrations. Use the reviewed Cognito deployment configuration for cloud integration tests.",
    );
  }

  if (
    config.NOTIFICATION_TRANSPORT === "simulator" &&
    (config.NODE_ENV === "production" || config.AUTH_MODE !== "demo")
  )
    throw new Error(
      "Notification simulator is restricted to explicit local demo mode",
    );

  if (config.NODE_ENV === "production") validateProduction(config, env);
  return config;
}
export type Configuration = ReturnType<typeof parseConfig>;

function invalid(field: string): never {
  throw new Error(`Invalid production configuration: ${field}`);
}
const placeholder =
  /example|placeholder|changeme|change-me|replace[-_ ]?me|dummy|your[-_ ]|local-development-only|^(test|secret|password|undefined|null|none)$/i;
export function strongSecret(value: unknown, minimum = 32) {
  return (
    typeof value === "string" &&
    Buffer.byteLength(value, "utf8") >= minimum &&
    value.length <= 512 &&
    !/\s/.test(value) &&
    !placeholder.test(value) &&
    new Set(value).size >= (minimum >= 32 ? 16 : 8) &&
    !/^(.{1,32})\1+$/.test(value)
  );
}
function httpsOrigin(value: string) {
  try {
    const u = new URL(value);
    return (
      u.protocol === "https:" &&
      u.origin === value &&
      /^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/i.test(u.hostname) &&
      u.hostname.includes(".") &&
      !isLoopbackOrigin(value) &&
      !isLoopbackPeer(u.hostname) &&
      !/\.(invalid|test|example)$/.test(u.hostname) &&
      !u.hostname.endsWith(".localhost") &&
      !placeholder.test(u.hostname)
    );
  } catch {
    return false;
  }
}
export function secretArn(value: string, region: string) {
  const parts = value.split(":");
  return (
    parts.length === 7 &&
    parts[0] === "arn" &&
    parts[1] === "aws" &&
    parts[2] === "secretsmanager" &&
    parts[3] === region &&
    /^\d{12}$/.test(parts[4]) &&
    parts[5] === "secret" &&
    /^[\w/+=.@-]+-[A-Za-z0-9]{6}$/.test(parts[6]) &&
    !placeholder.test(parts[6])
  );
}
export function validateDatabaseSecret(value: unknown) {
  const parsed = z
    .object({
      host: z.string().min(1),
      port: z.coerce.number().int().min(1).max(65535),
      username: z.string().min(1),
      password: z.string(),
      dbname: z.string().min(1),
    })
    .safeParse(value);
  if (!parsed.success) invalid("DATABASE_SECRET_ARN payload");
  const s = parsed.data;
  if (
    (!/^[a-zA-Z0-9.-]+$/.test(s.host) && isIP(s.host) === 0) ||
    placeholder.test(s.host) ||
    !/^[a-zA-Z0-9_-]+$/.test(s.dbname) ||
    !/^[a-zA-Z0-9_-]+$/.test(s.username) ||
    !strongSecret(s.password, 16)
  )
    invalid("DATABASE_SECRET_ARN payload");
  return s;
}
function validateProduction(
  c: Configuration,
  env: Record<string, string | undefined>,
) {
  if (env.NODE_TLS_REJECT_UNAUTHORIZED === "0")
    invalid("NODE_TLS_REJECT_UNAUTHORIZED");
  if (
    !env.AWS_REGION ||
    !/^(af|ap|ca|eu|il|me|mx|sa|us)-(?:[a-z]+-)+\d$/.test(c.AWS_REGION)
  )
    invalid("AWS_REGION");
  for (const field of ["APP_ORIGIN", "API_ORIGIN"] as const)
    if (!env[field] || !httpsOrigin(c[field])) invalid(field);
  if (
    !c.COGNITO_POOL_ID ||
    !new RegExp(`^${c.AWS_REGION}_[A-Za-z0-9]{1,55}$`).test(
      c.COGNITO_POOL_ID,
    ) ||
    placeholder.test(c.COGNITO_POOL_ID)
  )
    invalid("COGNITO_POOL_ID");
  if (
    !c.COGNITO_CLIENT_ID ||
    !/^[a-z0-9]{1,128}$/.test(c.COGNITO_CLIENT_ID) ||
    placeholder.test(c.COGNITO_CLIENT_ID)
  )
    invalid("COGNITO_CLIENT_ID");
  const issuer = `https://cognito-idp.${c.AWS_REGION}.amazonaws.com/${c.COGNITO_POOL_ID}`;
  if (c.COGNITO_ISSUER !== undefined && c.COGNITO_ISSUER !== issuer)
    invalid("COGNITO_ISSUER");
  if (!c.COGNITO_DOMAIN || !httpsOrigin(c.COGNITO_DOMAIN))
    invalid("COGNITO_DOMAIN");
  const domain = new URL(c.COGNITO_DOMAIN).hostname;
  if (
    domain.endsWith(".amazoncognito.com") &&
    !domain.endsWith(`.auth.${c.AWS_REGION}.amazoncognito.com`)
  )
    invalid("COGNITO_DOMAIN region");
  if (Number(!!c.DATABASE_URL) + Number(!!c.DATABASE_SECRET_ARN) !== 1)
    invalid("DATABASE_URL / DATABASE_SECRET_ARN (choose one)");
  if (c.DATABASE_SECRET_ARN && !secretArn(c.DATABASE_SECRET_ARN, c.AWS_REGION))
    invalid("DATABASE_SECRET_ARN");
  if (c.DATABASE_URL) {
    try {
      const u = new URL(c.DATABASE_URL);
      if (
        !["postgres:", "postgresql:"].includes(u.protocol) ||
        !u.hostname ||
        u.hash ||
        !/^[a-zA-Z0-9_.-]+$/.test(decodeURIComponent(u.username)) ||
        !/^\/[a-zA-Z0-9_-]+$/.test(u.pathname) ||
        placeholder.test(u.hostname) ||
        !strongSecret(decodeURIComponent(u.password), 16) ||
        [...u.searchParams].some(
          ([k, v]) => k !== "sslmode" || v !== "verify-full",
        )
      )
        invalid("DATABASE_URL");
    } catch {
      invalid("DATABASE_URL");
    }
  }
  if (Number(!!c.SESSION_KEY) + Number(!!c.SESSION_SECRET_ARN) !== 1)
    invalid("SESSION_KEY / SESSION_SECRET_ARN (choose one)");
  if (c.SESSION_KEY && !strongSecret(c.SESSION_KEY)) invalid("SESSION_KEY");
  if (c.SESSION_SECRET_ARN && !secretArn(c.SESSION_SECRET_ARN, c.AWS_REGION))
    invalid("SESSION_SECRET_ARN");
  if (c.DATABASE_SECRET_ARN && c.DATABASE_SECRET_ARN === c.SESSION_SECRET_ARN)
    invalid("distinct database and session secrets required");
  // Durable outbox delivery always needs SNS in production; local database
  // transport remains development-only. Evidence, maps and email are optional.
  if (
    !c.EVENT_TOPIC_ARN ||
    !new RegExp(`^arn:aws:sns:${c.AWS_REGION}:\\d{12}:[A-Za-z0-9_-]+$`).test(
      c.EVENT_TOPIC_ARN,
    ) ||
    placeholder.test(c.EVENT_TOPIC_ARN)
  )
    invalid("EVENT_TOPIC_ARN");
  for (const field of ["EVIDENCE_BUCKET", "ANALYTICS_BUCKET"] as const) {
    const v = c[field];
    if (
      v !== undefined &&
      (!/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/.test(v) ||
        v.includes("..") ||
        /^(\d+\.){3}\d+$/.test(v) ||
        placeholder.test(v))
    )
      invalid(field);
  }
  for (const field of [
    "LOCATION_MAP_NAME",
    "LOCATION_PLACE_INDEX",
    "LOCATION_ROUTE_CALCULATOR",
  ] as const) {
    const v = c[field];
    if (
      v !== undefined &&
      (!/^[A-Za-z0-9_.-]{1,100}$/.test(v) || placeholder.test(v))
    )
      invalid(field);
  }
  if (c.EMAIL_FROM && placeholder.test(c.EMAIL_FROM)) invalid("EMAIL_FROM");
}

function localDatabase(value: string) {
  try {
    const u = new URL(value);
    return (
      ["postgres:", "postgresql:"].includes(u.protocol) &&
      ["localhost", "127.0.0.1"].includes(u.hostname)
    );
  } catch {
    return false;
  }
}

import type { Pool, PoolClient } from "pg";
import { assertSchemaReady } from "./schema-readiness.js";
// Single flight prevents concurrent health requests from exhausting the pool.
// The total deadline also covers waiting for a connection. Late connections
// are destroyed; timed-out/failed transactions are never returned to the pool.
export function createReadinessCheck(
  pool: Pick<Pool, "connect">,
  timeout: () => number,
) {
  let pending: Promise<boolean> | undefined;
  return function ready(): Promise<boolean> {
    if (pending) return pending;
    const ms = timeout();
    let client: PoolClient | undefined;
    let expired = false,
      released = false,
      success = false;
    let timer: ReturnType<typeof setTimeout>;
    const release = (destroy: boolean) => {
      if (client && !released) {
        released = true;
        client.release(destroy);
      }
    };
    const work = (async () => {
      try {
        client = await pool.connect();
        if (expired) return false;
        await client.query("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY");
        if (expired) return false;
        await client.query(
          "SELECT set_config('statement_timeout',$1,true),set_config('lock_timeout',$1,true)",
          [String(ms)],
        );
        if (expired) return false;
        await client.query("SET LOCAL search_path TO pg_catalog,public");
        if (expired) return false;
        await assertSchemaReady(client);
        if (expired) return false;
        await client.query("COMMIT");
        success = !expired;
        return success;
      } catch {
        return false;
      } finally {
        release(!success);
      }
    })();
    const deadline = new Promise<boolean>((resolve) => {
      timer = setTimeout(() => {
        expired = true;
        release(true);
        resolve(false);
      }, ms);
    });
    pending = Promise.race([work, deadline]);
    void work.then(() => {
      clearTimeout(timer);
      pending = undefined;
    });
    return pending;
  };
}

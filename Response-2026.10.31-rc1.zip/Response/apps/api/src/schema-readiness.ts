import type { PoolClient } from "pg";
import contract from "../../../db/schema-contract.json" with { type: "json" };
import { inspectSchema } from "../../../scripts/schema-inspection.js";
export const requiredMigrations = Object.keys(contract.migrations);
export const migrationHashes: Record<string, string> = contract.migrations;
export function validateLedger(
  rows: { name: string; applied_at: unknown }[],
  pending = false,
) {
  const names = rows.map((r) => r.name).sort();
  if (
    (!pending && names.length !== requiredMigrations.length) ||
    names.length > requiredMigrations.length ||
    names.some((name, i) => name !== requiredMigrations[i]) ||
    rows.some(
      (r) =>
        !(r.applied_at instanceof Date) ||
        !Number.isFinite(r.applied_at.getTime()),
    )
  )
    throw new Error("Database migration ledger is not compatible");
}
export async function assertSchemaReady(db: Pick<PoolClient, "query">) {
  const ledger = await db.query(
    "SELECT name,applied_at FROM public.schema_migrations ORDER BY name",
  );
  validateLedger(ledger.rows);
  const actual = new Map(
    (await inspectSchema(db)).map((o) => [`${o.kind}:${o.key}`, o.definition]),
  );
  if (
    contract.objects.some(
      (o) => actual.get(`${o.kind}:${o.key}`) !== o.definition,
    )
  )
    throw new Error("Database schema is not compatible");
}

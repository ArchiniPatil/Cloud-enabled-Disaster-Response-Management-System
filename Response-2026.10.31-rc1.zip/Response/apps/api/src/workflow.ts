import { audit, type DB } from "./db.js";
import { recordTransition, notifyControl } from "./incidents.js";
import {
  terminalIncidents,
  terminalAssignments,
} from "../../../packages/core/src/domain.js";

// Callers lock incident first, then assignment, then team. Worker/API share this order.
export async function scheduleDeadline(
  db: DB,
  assignmentId: string,
  phase: string,
) {
  await db.query(
    "UPDATE assignment_deadlines SET completed_at=now(),outcome='PHASE_CHANGED' WHERE assignment_id=$1 AND completed_at IS NULL",
    [assignmentId],
  );
  if (terminalAssignments.includes(phase)) return;
  await db.query(
    `INSERT INTO assignment_deadlines(assignment_id,phase,due_at)
 SELECT a.id,$2,now()+CASE $2 WHEN 'OFFERED' THEN coalesce(p.offer_timeout_seconds,120) WHEN 'ACCEPTED' THEN coalesce(p.dispatch_timeout_seconds,180) ELSE coalesce(p.progress_timeout_seconds,900) END*interval '1 second'
 FROM incident_assignments a JOIN incidents i ON i.id=a.incident_id LEFT JOIN escalation_policies p ON p.id=i.policy_id WHERE a.id=$1 ON CONFLICT(assignment_id,phase) DO NOTHING`,
    [assignmentId, phase],
  );
}
export async function assignmentNotice(
  db: DB,
  incidentId: string,
  assignmentId: string,
  phase: string,
) {
  await notifyControl(db, incidentId, `assignment-${assignmentId}-${phase}`);
  await db.query(
    `INSERT INTO notification_jobs(incident_id,recipient_id,channel,dedupe_key,status)
 SELECT a.incident_id,m.user_id,'IN_APP',$2||':'||m.user_id,'AVAILABLE' FROM incident_assignments a JOIN team_memberships m ON m.team_id=a.team_id JOIN user_profiles u ON u.id=m.user_id AND u.status='ACTIVE'
 WHERE a.id=$1 ON CONFLICT(dedupe_key) DO NOTHING`,
    [assignmentId, `assignment:${assignmentId}:${phase}`],
  );
}
export async function requestReview(
  db: DB,
  incidentId: string,
  reason: string,
) {
  await db.query(
    "UPDATE incidents SET escalation_state='CONTROL_REVIEW_REQUIRED',updated_at=now() WHERE id=$1",
    [incidentId],
  );
  await notifyControl(db, incidentId, reason);
}
export async function scheduleReview(db: DB, incidentId: string) {
  // Caller owns incident lock; one pending manual review is sufficient.
  await db.query(
    `INSERT INTO escalation_executions(incident_id,stage,due_at,force_review)
 SELECT $1,coalesce(max(stage)+1,0),now(),true FROM escalation_executions WHERE incident_id=$1
 HAVING NOT EXISTS(SELECT 1 FROM escalation_executions WHERE incident_id=$1 AND force_review AND completed_at IS NULL)`,
    [incidentId],
  );
}
export async function finishAssignment(
  db: DB,
  a: { id: string; incident_id: string; team_id: string },
  actor: string | null,
) {
  await db.query("DELETE FROM route_cache WHERE assignment_id=$1", [a.id]);
  const i = (
    await db.query("SELECT * FROM incidents WHERE id=$1", [a.incident_id])
  ).rows[0];
  if (terminalIncidents.includes(i.status)) return;
  const active = (
    await db.query(
      "SELECT status FROM incident_assignments WHERE incident_id=$1 AND status NOT IN('COMPLETED','DECLINED','CANCELLED')",
      [i.id],
    )
  ).rows;
  const current = (
    await db.query(
      "SELECT status,outcome_note FROM incident_assignments WHERE id=$1",
      [a.id],
    )
  ).rows[0];
  // Aggregate active teams, never let a second team's lower milestone move a more advanced team back.
  let next = i.status;
  if (active.some((x) => ["ARRIVED", "IN_PROGRESS"].includes(x.status)))
    next = "TEAM_ON_SCENE";
  else if (active.some((x) => x.status === "EN_ROUTE")) next = "TEAM_EN_ROUTE";
  else if (active.some((x) => x.status === "DISPATCHED")) next = "DISPATCHED";
  else if (
    !active.length &&
    current.status === "COMPLETED" &&
    i.status === "TEAM_ON_SCENE"
  )
    next = "RESOLVED";
  else if (["DISPATCHED", "TEAM_EN_ROUTE", "TEAM_ON_SCENE"].includes(i.status))
    next = "ACKNOWLEDGED";
  if (next !== i.status)
    await recordTransition(
      db,
      i.id,
      i.status,
      next,
      actor,
      current.outcome_note,
    );
  if (next === "RESOLVED") await closeSchedules(db, i.id);
  else if (["DECLINED", "CANCELLED"].includes(current.status)) {
    await requestReview(db, i.id, `withdrawal-${a.id}`);
    await scheduleReview(db, i.id);
  }
  // On-duty sharing is explicitly owned by the browser/session, not by a particular assignment.
}
export async function closeSchedules(db: DB, incidentId: string) {
  await db.query("UPDATE incidents SET escalation_state='CLOSED' WHERE id=$1", [
    incidentId,
  ]);
  await db.query(
    "UPDATE escalation_executions SET completed_at=now(),outcome='INCIDENT_CLOSED' WHERE incident_id=$1 AND completed_at IS NULL",
    [incidentId],
  );
  await db.query(
    "UPDATE assignment_deadlines d SET completed_at=now(),outcome='INCIDENT_CLOSED' FROM incident_assignments a WHERE d.assignment_id=a.id AND a.incident_id=$1 AND d.completed_at IS NULL",
    [incidentId],
  );
}
export async function cancelAssignment(
  db: DB,
  a: { id: string; status: string; incident_id: string; team_id: string },
  actor: string | null,
  note: string,
) {
  await db.query(
    "UPDATE incident_assignments SET status='CANCELLED',outcome_note=$2,updated_at=now() WHERE id=$1",
    [a.id, note],
  );
  await scheduleDeadline(db, a.id, "CANCELLED");
  await audit(db, actor, "ASSIGNMENT_STATUS", "assignment", a.id, {
    from: a.status,
    to: "CANCELLED",
    note,
  });
  await assignmentNotice(db, a.incident_id, a.id, "CANCELLED");
  await db.query("DELETE FROM route_cache WHERE assignment_id=$1", [a.id]);
}

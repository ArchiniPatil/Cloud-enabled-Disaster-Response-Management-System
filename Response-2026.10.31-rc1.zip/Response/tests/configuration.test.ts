import { parseConfig, strongSecret } from "../apps/api/src/config-validation";
import { databaseOptions } from "../apps/api/src/database-config";
import { expect, it } from "vitest";
import { randomBytes } from "node:crypto";
import { spawnSync } from "node:child_process";
function productionEnv(overrides: Record<string, string | undefined> = {}) {
  const env: Record<string, string | undefined> = {
    PATH: process.env.PATH,
    NODE_ENV: "production",
    AUTH_MODE: "cognito",
    AWS_REGION: "ap-south-1",
    APP_ORIGIN: "https://response.acme.org",
    API_ORIGIN: "https://api.acme.org",
    DATABASE_URL: `postgresql://response_app:${randomBytes(24).toString("hex")}@db.internal:5432/response`,
    SESSION_KEY: randomBytes(48).toString("base64url"),
    COGNITO_POOL_ID: "ap-south-1_a8B9c0D1e",
    COGNITO_CLIENT_ID: "7t8p4u1k9m2n6r0s3v5w8x1y4z",
    COGNITO_DOMAIN: "https://response-acme.auth.ap-south-1.amazoncognito.com",
    EVENT_TOPIC_ARN: "arn:aws:sns:ap-south-1:123456789012:response-events",
    ...overrides,
  };
  return env;
}
function production(overrides: Record<string, string | undefined> = {}) {
  const env = productionEnv(overrides);
  return spawnSync(
    process.execPath,
    [
      "--import",
      "tsx",
      "--input-type=module",
      "-e",
      "await import('./apps/api/src/config.ts'); console.log('accepted')",
    ],
    { env, encoding: "utf8", timeout: 10000 },
  );
}
it("accepts valid production settings without optional integrations", () => {
  expect(production().status).toBe(0);
});
it("rejects missing production database and Cognito settings", () => {
  expect(
    production({
      DATABASE_URL: undefined,
      COGNITO_POOL_ID: undefined,
      COGNITO_CLIENT_ID: undefined,
      COGNITO_DOMAIN: undefined,
    }).status,
  ).not.toBe(0);
});
it("rejects a one-character production encryption key", () => {
  expect(production({ SESSION_KEY: "x" }).status).not.toBe(0);
});
it("rejects production fixture authentication", () => {
  expect(production({ AUTH_MODE: "demo" }).status).not.toBe(0);
});

it.each([
  "DATABASE_URL",
  "SESSION_KEY",
  "COGNITO_POOL_ID",
  "COGNITO_CLIENT_ID",
  "COGNITO_DOMAIN",
  "APP_ORIGIN",
  "API_ORIGIN",
  "AWS_REGION",
  "EVENT_TOPIC_ARN",
])("requires production setting %s", (field) => {
  expect(() => parseConfig(productionEnv({ [field]: undefined }))).toThrow();
});
it.each([
  ["DATABASE_URL", "https://user:password@db.internal/response"],
  ["DATABASE_URL", "postgresql://user:password@db.internal/response"],
  ["DATABASE_URL", "postgresql://user:strong-password@db.internal"],
  ["COGNITO_POOL_ID", "us-east-1_a8B9c0D1e"],
  ["COGNITO_POOL_ID", "not-a-pool"],
  ["COGNITO_CLIENT_ID", "invalid!client"],
  ["COGNITO_CLIENT_ID", "example"],
  ["COGNITO_ISSUER", "https://attacker.acme.org/pool"],
  ["COGNITO_DOMAIN", "https://response-acme.auth.us-east-1.amazoncognito.com"],
  ["COGNITO_DOMAIN", "https://login.acme.org/path"],
  ["COGNITO_DOMAIN", "https://user:password@login.acme.org"],
  ["COGNITO_DOMAIN", "http://login.acme.org"],
  ["APP_ORIGIN", "https://response.acme.org/path"],
  ["API_ORIGIN", "https://user:password@api.acme.org"],
  ["API_ORIGIN", "https://localhost"],
  ["AWS_REGION", "not-a-region"],
  ["PORT", "70000"],
  ["READINESS_TIMEOUT_MS", "0"],
  ["READINESS_TIMEOUT_MS", "6000"],
  ["EVENT_TOPIC_ARN", "arn:aws:sns:us-east-1:123456789012:events"],
  ["EVIDENCE_BUCKET", "Invalid Bucket"],
  ["ANALYTICS_BUCKET", "example-bucket"],
  ["LOCATION_MAP_NAME", "invalid map name"],
  ["EMAIL_FROM", "not-an-email"],
  ["NOTIFICATION_TRANSPORT", "simulator"],
  ["EVENT_TRANSPORT", "database"],
])("rejects malformed or contradictory %s (%#)", (field, value) => {
  expect(() => parseConfig(productionEnv({ [field]: value }))).toThrow();
});
it.each([
  "x",
  "dummy",
  "changeme".repeat(8),
  "a".repeat(64),
  "0123456789abcdef".repeat(4),
  "replace-me-with-a-very-long-encryption-secret-value",
])("rejects weak/placeholder session material %#", (value) => {
  expect(() => parseConfig(productionEnv({ SESSION_KEY: value }))).toThrow();
});
it("accepts the exact derived Cognito issuer and optional provider settings", () => {
  expect(() =>
    parseConfig(
      productionEnv({
        COGNITO_ISSUER:
          "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_a8B9c0D1e",
        EVIDENCE_BUCKET: "response-acme-evidence",
        ANALYTICS_BUCKET: "response-acme-analytics",
        LOCATION_MAP_NAME: "response-map",
        EMAIL_FROM: "updates@acme.org",
        SMS_ENABLED: "true",
      }),
    ),
  ).not.toThrow();
});
it("accepts canonical custom Cognito domains", () => {
  expect(() =>
    parseConfig(productionEnv({ COGNITO_DOMAIN: "https://login.acme.org" })),
  ).not.toThrow();
});
it("accepts secret references and rejects contradictory sources", () => {
  const refs = {
    DATABASE_URL: undefined,
    DATABASE_SECRET_ARN:
      "arn:aws:secretsmanager:ap-south-1:123456789012:secret:response-db-Ab12Cd",
    SESSION_KEY: undefined,
    SESSION_SECRET_ARN:
      "arn:aws:secretsmanager:ap-south-1:123456789012:secret:response-session-Ef34Gh",
  };
  expect(() => parseConfig(productionEnv(refs))).not.toThrow();
  expect(() =>
    parseConfig(
      productionEnv({ ...refs, DATABASE_URL: productionEnv().DATABASE_URL }),
    ),
  ).toThrow();
  expect(() =>
    parseConfig(
      productionEnv({ ...refs, SESSION_KEY: productionEnv().SESSION_KEY }),
    ),
  ).toThrow();
  expect(() =>
    parseConfig(
      productionEnv({ ...refs, SESSION_SECRET_ARN: refs.DATABASE_SECRET_ARN }),
    ),
  ).toThrow();
  expect(() =>
    parseConfig(productionEnv({ ...refs, SESSION_SECRET_ARN: "not-an-arn" })),
  ).toThrow();
});
it.each(["disable", "require", "prefer", "verify-ca"])(
  "rejects TLS downgrade sslmode=%s",
  (mode) => {
    expect(() =>
      parseConfig(
        productionEnv({
          DATABASE_URL: productionEnv().DATABASE_URL + `?sslmode=${mode}`,
        }),
      ),
    ).toThrow();
  },
);
it("enforces verified TLS without URL options overriding pg settings", async () => {
  const c = parseConfig(
    productionEnv({
      DATABASE_URL: productionEnv().DATABASE_URL + "?sslmode=verify-full",
    }),
  );
  const opts = await databaseOptions(c, async () => {
    throw new Error("Unexpected secret lookup");
  });
  expect(opts.ssl).toEqual({ rejectUnauthorized: true });
  expect(opts.connectionString).not.toContain("sslmode");
});
it("keeps explicit local demo and incomplete local Cognito configuration usable", () => {
  expect(
    parseConfig({ NODE_ENV: "development", AUTH_MODE: "demo" }).AUTH_MODE,
  ).toBe("demo");
  expect(parseConfig({ NODE_ENV: "development" }).AUTH_MODE).toBe("cognito");
  expect(
    parseConfig({
      NODE_ENV: "development",
      AUTH_MODE: "cognito",
      EVENT_TRANSPORT: "database",
      DATABASE_URL:
        "postgresql://response:local-development-only@127.0.0.1:5432/response_cognito",
    }).EVENT_TRANSPORT,
  ).toBe("database");
});
it("does not expose input values in parser errors or child-process stderr", () => {
  const sentinel = "sensitive-not-for-output-4f1d";
  for (const overrides of [
    { DATABASE_URL: sentinel },
    { COGNITO_POOL_ID: sentinel },
    { PORT: sentinel },
    { SESSION_KEY: sentinel },
    { API_ORIGIN: sentinel },
  ]) {
    try {
      parseConfig(productionEnv(overrides));
      throw new Error("Unexpected acceptance");
    } catch (error) {
      expect(String(error)).not.toContain(sentinel);
      expect(String(error)).not.toBe("Error: Unexpected acceptance");
    }
  }
  const child = production({ DATABASE_URL: sentinel, SESSION_KEY: sentinel });
  expect(child.status).toBe(1);
  expect(child.stderr + child.stdout).not.toContain(sentinel);
  expect(() =>
    parseConfig({
      NODE_ENV: "development",
      AUTH_MODE: "demo",
      DATABASE_URL: sentinel,
    }),
  ).toThrow("loopback-only");
});
it.each([
  "apps/api/src/server.ts",
  "apps/api/src/worker.ts",
  "apps/api/src/lambda.ts",
  "scripts/migrate.ts",
  "scripts/migration-handler.ts",
  "scripts/bootstrap-admin.ts",
  "apps/api/src/sms-receipts.ts",
])("fails closed at the %s entry point before external access", (entry) => {
  const r = spawnSync(
    process.execPath,
    [
      "--import",
      "tsx",
      "--input-type=module",
      "-e",
      `await import('./${entry}')`,
    ],
    {
      env: productionEnv({ SESSION_KEY: "x", DATABASE_URL: undefined }),
      encoding: "utf8",
      timeout: 5000,
    },
  );
  expect(r.status).toBe(1);
  expect(r.stderr).toMatch(/Invalid production configuration/);
  expect(r.stdout).not.toContain("api_started");
});
it("validates database and session secret payloads after resolution", async () => {
  const env = productionEnv({
    DATABASE_URL: undefined,
    DATABASE_SECRET_ARN:
      "arn:aws:secretsmanager:ap-south-1:123456789012:secret:response-db-Ab12Cd",
    SESSION_KEY: undefined,
    SESSION_SECRET_ARN:
      "arn:aws:secretsmanager:ap-south-1:123456789012:secret:response-session-Ef34Gh",
  });
  const credentials = {
    host: "postgres.internal",
    port: 5432,
    username: "response_app",
    password: randomBytes(24).toString("hex"),
    dbname: "response",
  };
  const key = randomBytes(48).toString("base64url");
  const c = parseConfig(env),
    opts = await databaseOptions(c, async (arn) =>
      arn === c.DATABASE_SECRET_ARN ? JSON.stringify(credentials) : key,
    );
  expect(opts.database).toBe("response");
  expect(opts.ssl).toEqual({ rejectUnauthorized: true });
  expect(c.SESSION_KEY).toBe(key);
  for (const body of [
    "not-json",
    JSON.stringify({ ...credentials, password: "x" }),
    JSON.stringify({ ...credentials, host: undefined }),
    JSON.stringify({ ...credentials, port: 0 }),
    JSON.stringify({ ...credentials, dbname: undefined }),
  ]) {
    await expect(
      databaseOptions(parseConfig(env), async () => body),
    ).rejects.toThrow("Database secret could not be loaded or validated");
  }
  await expect(
    databaseOptions(parseConfig(env), async (arn) =>
      arn === env.DATABASE_SECRET_ARN ? JSON.stringify(credentials) : "x",
    ),
  ).rejects.toThrow("Session secret could not be loaded or validated");
  const sentinel = "private-service-error-and-secret-value";
  try {
    await databaseOptions(parseConfig(env), async () => {
      throw new Error(sentinel);
    });
  } catch (error) {
    expect(String(error)).not.toContain(sentinel);
  }
  expect(strongSecret(key)).toBe(true);
});

it.each([
  ["API_ORIGIN", "https://127.23.4.5"],
  ["APP_ORIGIN", "https://response.invalid"],
  ["EVENT_TOPIC_ARN", "arn:aws:sns:ap-south-1:123456789012:events.fifo"],
  ["NODE_TLS_REJECT_UNAUTHORIZED", "0"],
])(
  "rejects unsupported or unsafe production configuration %s",
  (field, value) => {
    expect(() => parseConfig(productionEnv({ [field]: value }))).toThrow();
  },
);

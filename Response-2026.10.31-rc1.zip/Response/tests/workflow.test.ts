import { beforeAll, beforeEach, afterAll, expect, it, vi } from "vitest";
import request from "supertest";
import { randomUUID } from "node:crypto";
import { execFileSync } from "node:child_process";
import { app } from "../apps/api/src/app";
import { pool } from "../apps/api/src/db";
import { migrate } from "../scripts/migrations";
import { runEscalations } from "../apps/api/src/jobs";
const origin = "http://localhost:5173";
type Client = {
  agent: ReturnType<typeof request.agent>;
  csrf: string;
  user: any;
};
let citizen: Client,
  authority: Client,
  rescuer: Client,
  admin: Client,
  teamId: string;
async function login(role: string): Promise<Client> {
  const agent = request.agent(app);
  await agent
    .post("/api/v1/auth/demo")
    .set("Origin", origin)
    .send({ email: `${role}@demo.invalid` })
    .expect(200);
  const { body } = await agent.get("/api/v1/auth/me").expect(200);
  return { agent, csrf: body.csrf, user: body.user };
}
function post(c: Client, path: string, body: object) {
  return c.agent
    .post(`/api/v1${path}`)
    .set("Origin", origin)
    .set("X-CSRF-Token", c.csrf)
    .set("Idempotency-Key", randomUUID())
    .send(body);
}
function patch(c: Client, path: string, body: object) {
  return c.agent
    .patch(`/api/v1${path}`)
    .set("Origin", origin)
    .set("X-CSRF-Token", c.csrf)
    .send(body);
}
async function incident() {
  const r = await post(citizen, "/incidents", {
    category: "MEDICAL",
    severity: "CRITICAL",
    kind: "EMERGENCY",
    latitude: 19.076,
    longitude: 72.8777,
    description: "Isolated workflow exercise",
  }).expect(201);
  await post(authority, `/incidents/${r.body.id}/status`, {
    status: "ACKNOWLEDGED",
  }).expect(200);
  return r.body.id as string;
}
async function offer(id?: string) {
  const incidentId = id ?? (await incident());
  return (
    await post(authority, "/assignments", { incidentId, teamId }).expect(201)
  ).body;
}
async function advance(a: any, to = "ARRIVED") {
  for (const status of [
    "ACCEPTED",
    "DISPATCHED",
    "EN_ROUTE",
    "ARRIVED",
    "IN_PROGRESS",
    "COMPLETED",
  ]) {
    await post(
      status === "DISPATCHED" ? authority : rescuer,
      `/assignments/${a.id}/status`,
      {
        status,
        note:
          status === "COMPLETED" ? "Assistance completed; needs checked" : "",
      },
    ).expect(200);
    if (status === to) break;
  }
}
async function row(id: string) {
  return (await pool.query("SELECT * FROM incidents WHERE id=$1", [id]))
    .rows[0];
}
beforeAll(async () => {
  if (!new URL(process.env.DATABASE_URL!).pathname.endsWith("_test"))
    throw Error("Dedicated test DB required");
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public");
  await migrate();
  execFileSync(process.execPath, ["--import", "tsx", "scripts/seed.ts"], {
    env: process.env,
    stdio: "pipe",
  });
  citizen = await login("citizen");
  authority = await login("authority");
  rescuer = await login("rescuer");
  admin = await login("admin");
  teamId = (
    await pool.query("SELECT team_id FROM team_memberships WHERE user_id=$1", [
      rescuer.user.id,
    ])
  ).rows[0].team_id;
});
beforeEach(async () => {
  await pool.query(
    "UPDATE incident_assignments SET status='CANCELLED' WHERE status NOT IN('COMPLETED','DECLINED','CANCELLED'); UPDATE location_sessions SET active=false; UPDATE escalation_executions SET completed_at=now() WHERE completed_at IS NULL",
  );
  await post(rescuer, `/teams/${teamId}/duty`, {
    availability: "AVAILABLE",
  }).expect(200);
  const s = await post(rescuer, "/locations/sessions", { teamId }).expect(201);
  await pool.query("UPDATE rescue_teams SET location_at=NULL WHERE id=$1", [
    teamId,
  ]);
  await post(rescuer, "/locations/updates", {
    sessionId: s.body.id,
    latitude: 19.077,
    longitude: 72.878,
    accuracy: 10,
    observedAt: new Date().toISOString(),
  }).expect(202);
});
afterAll(async () => {
  vi.restoreAllMocks();
  await pool.end();
});
it("cancels an arrived assignment without leaving the incident stuck", async () => {
  const a = await offer();
  await advance(a);
  await post(authority, `/assignments/${a.id}/status`, {
    status: "CANCELLED",
    note: "Unsafe scene; replacement needed",
  }).expect(200);
  expect((await row(a.incident_id)).status).toBe("ACKNOWLEDGED");
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM audit_events WHERE entity_id=$1 AND details->>'to'='CANCELLED'",
        [a.id],
      )
    ).rows[0].n,
  ).toBe(1);
});
it("closes an on-scene incident unable to respond atomically with its assignment", async () => {
  const a = await offer();
  await advance(a);
  await post(authority, `/incidents/${a.incident_id}/status`, {
    status: "UNABLE_TO_RESPOND",
    note: "Area inaccessible; control room notified",
  }).expect(200);
  expect((await row(a.incident_id)).status).toBe("UNABLE_TO_RESPOND");
  expect(
    (
      await pool.query("SELECT status FROM incident_assignments WHERE id=$1", [
        a.id,
      ])
    ).rows[0].status,
  ).toBe("CANCELLED");
});
it("persists a dispatch deadline when acceptance pauses geographic escalation", async () => {
  const a = await offer();
  await advance(a, "ACCEPTED");
  await runEscalations();
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM assignment_deadlines WHERE assignment_id=$1 AND phase='ACCEPTED' AND completed_at IS NULL",
        [a.id],
      )
    ).rows[0].n,
  ).toBe(1);
});
it("returns not found without auditing a nonexistent resource update", async () => {
  const id = randomUUID();
  await patch(admin, `/admin/resources/${id}`, {
    quantity: 5,
    status: "AVAILABLE",
  }).expect(404);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM audit_events WHERE entity_id=$1",
        [id],
      )
    ).rows[0].n,
  ).toBe(0);
});

it.each(["ARRIVED", "IN_PROGRESS"])(
  "rescuer can report inability from %s without closing the incident",
  async (stage) => {
    const a = await offer();
    await advance(a, stage);
    await post(rescuer, `/assignments/${a.id}/status`, {
      status: "CANCELLED",
      note: "Unsafe access; unable to continue",
    }).expect(200);
    expect((await row(a.incident_id)).status).toBe("ACKNOWLEDGED");
    const replacement = await offer(a.incident_id);
    expect(replacement.id).not.toBe(a.id);
    expect(
      (
        await pool.query(
          "SELECT count(*)::int n FROM incident_assignments WHERE incident_id=$1",
          [a.incident_id],
        )
      ).rows[0].n,
    ).toBe(2);
  },
);
it("serializes duplicate acceptance with one audit and one dispatch deadline", async () => {
  const a = await offer();
  const results = await Promise.all(
    [1, 2].map(() =>
      post(rescuer, `/assignments/${a.id}/status`, { status: "ACCEPTED" }),
    ),
  );
  expect(results.map((r) => r.status)).toEqual([200, 200]);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM audit_events WHERE entity_id=$1 AND details->>'to'='ACCEPTED'",
        [a.id],
      )
    ).rows[0].n,
  ).toBe(1);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM assignment_deadlines WHERE assignment_id=$1 AND completed_at IS NULL",
        [a.id],
      )
    ).rows[0].n,
  ).toBe(1);
});
it.each(["ARRIVED", "IN_PROGRESS", "COMPLETED"])(
  "rejects skipping directly from offered to %s",
  async (status) => {
    const a = await offer();
    await post(rescuer, `/assignments/${a.id}/status`, {
      status,
      note: "Attempted skipped milestone",
    }).expect(409);
    expect((await row(a.incident_id)).status).toBe("ACKNOWLEDGED");
  },
);
it("decline requires a reason, releases capacity and keeps history", async () => {
  const a = await offer();
  await post(rescuer, `/assignments/${a.id}/status`, {
    status: "DECLINED",
  }).expect(400);
  await post(rescuer, `/assignments/${a.id}/status`, {
    status: "DECLINED",
    note: "Required equipment unavailable",
  }).expect(200);
  expect((await row(a.incident_id)).status).toBe("ACKNOWLEDGED");
  await offer(a.incident_id);
});
it.each(["CANCELLED", "UNABLE_TO_RESPOND", "RESOLVED"])(
  "prevents ordinary reassignment and escalation of %s incidents",
  async (status) => {
    const a = await offer();
    if (status === "RESOLVED") await advance(a, "COMPLETED");
    else
      await post(authority, `/incidents/${a.incident_id}/status`, {
        status,
        note: "Reviewed terminal outcome for exercise",
      }).expect(200);
    await post(authority, "/assignments", {
      incidentId: a.incident_id,
      teamId,
    }).expect(409);
    await post(authority, `/incidents/${a.incident_id}/escalate`, {}).expect(
      409,
    );
    const detail = await authority.agent
      .get(`/api/v1/incidents/${a.incident_id}`)
      .expect(200);
    expect(detail.body.can_assign).toBe(false);
    expect(detail.body.can_escalate).toBe(false);
  },
);
it("serializes competing manual offers and preserves team capacity", async () => {
  const ids = await Promise.all([incident(), incident()]);
  const results = await Promise.all(
    ids.map((incidentId) =>
      post(authority, "/assignments", { incidentId, teamId }),
    ),
  );
  expect(results.map((r) => r.status).sort()).toEqual([201, 409]);
});
it("serializes cancellation against acceptance without a surviving active assignment", async () => {
  const a = await offer();
  const result = await Promise.all([
    post(rescuer, `/assignments/${a.id}/status`, { status: "ACCEPTED" }),
    post(authority, `/incidents/${a.incident_id}/status`, {
      status: "CANCELLED",
      note: "Exercise cancelled by coordinator",
    }),
  ]);
  expect(result[1].status).toBe(200);
  expect([200, 404, 409]).toContain(result[0].status);
  expect(
    (
      await pool.query("SELECT status FROM incident_assignments WHERE id=$1", [
        a.id,
      ])
    ).rows[0].status,
  ).toBe("CANCELLED");
});
it("citizen cancellation is ownership-scoped and repeat-safe", async () => {
  const r = await post(citizen, "/incidents", {
    category: "MEDICAL",
    kind: "REPORT",
    severity: "LOW",
    latitude: 19,
    longitude: 72.9,
  }).expect(201);
  const id = r.body.id;
  await post(citizen, `/incidents/${id}/status`, {
    status: "CANCELLED",
  }).expect(200);
  await post(citizen, `/incidents/${id}/status`, {
    status: "CANCELLED",
  }).expect(200);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM incident_status_history WHERE incident_id=$1 AND to_status='CANCELLED'",
        [id],
      )
    ).rows[0].n,
  ).toBe(1);
  const other = await otherUser("CITIZEN");
  await post(other, `/incidents/${id}/status`, { status: "CANCELLED" }).expect(
    404,
  );
});
async function otherUser(
  role: string,
  departmentId = authority.user.department_id,
  jurisdictionId = authority.user.jurisdiction_id,
): Promise<Client> {
  const id = randomUUID(),
    token = randomUUID(),
    csrf = randomUUID();
  await pool.query(
    "INSERT INTO user_profiles(id,cognito_sub,email,name,role,department_id,jurisdiction_id) VALUES($1,$2,$3,'Isolated test user',$4,$5,$6)",
    [
      id,
      `demo:${id}`,
      `${id}@demo.invalid`,
      role,
      departmentId,
      jurisdictionId,
    ],
  );
  const { hash } = await import("../apps/api/src/auth");
  await pool.query(
    "INSERT INTO sessions(id_hash,user_id,csrf,version,access_expires,expires_at) VALUES($1,$2,$3,1,now()+interval '15 minutes',now()+interval '1 hour')",
    [hash(token), id, csrf],
  );
  if (role === "AUTHORITY")
    await pool.query("INSERT INTO user_permissions VALUES($1,'DISPATCH')", [
      id,
    ]);
  const agent = request.agent(app).set("Cookie", `response_session=${token}`);
  return {
    agent,
    csrf,
    user: {
      id,
      role,
      department_id: departmentId,
      jurisdiction_id: jurisdictionId,
    },
  };
}
async function otherTeam(
  departmentId = authority.user.department_id,
  lat = 19.077,
  lon = 72.878,
) {
  const user = await otherUser("RESCUER", departmentId);
  const t = (
    await pool.query(
      "INSERT INTO rescue_teams(name,department_id,jurisdiction_id,availability,location,location_at,accuracy) VALUES('Isolated second team',$1,$2,'AVAILABLE',ST_SetSRID(ST_MakePoint($3,$4),4326)::geography,now(),10) RETURNING id",
      [departmentId, authority.user.jurisdiction_id, lon, lat],
    )
  ).rows[0].id;
  await pool.query("INSERT INTO team_memberships VALUES($1,$2)", [
    t,
    user.user.id,
  ]);
  await pool.query(
    "INSERT INTO team_capabilities(team_id,capability) VALUES($1,'FIRST_AID')",
    [t],
  );
  await post(user, "/locations/sessions", { teamId: t }).expect(201);
  return { teamId: t, user };
}
it("rejects unrelated rescuers and limits action metadata to their own team", async () => {
  const a = await offer();
  const other = await otherTeam();
  await post(other.user, `/assignments/${a.id}/status`, {
    status: "ACCEPTED",
  }).expect(404);
  const b = (
    await post(admin, "/assignments", {
      incidentId: a.incident_id,
      teamId: other.teamId,
    }).expect(201)
  ).body;
  const detail = await rescuer.agent
    .get(`/api/v1/incidents/${a.incident_id}`)
    .expect(200);
  expect(
    detail.body.assignments.find((x: any) => x.id === b.id).allowed_actions,
  ).toEqual([]);
  await post(rescuer, `/assignments/${b.id}/status`, {
    status: "ACCEPTED",
  }).expect(404);
});
it("keeps a multi-team incident on scene until all active teams finish or withdraw", async () => {
  const a = await offer();
  const other = await otherTeam();
  const b = (
    await post(admin, "/assignments", {
      incidentId: a.incident_id,
      teamId: other.teamId,
    }).expect(201)
  ).body;
  await advance(a);
  await post(other.user, `/assignments/${b.id}/status`, {
    status: "ACCEPTED",
  }).expect(200);
  await post(admin, `/assignments/${b.id}/status`, {
    status: "DISPATCHED",
  }).expect(200);
  expect((await row(a.incident_id)).status).toBe("TEAM_ON_SCENE");
  await post(admin, `/assignments/${b.id}/status`, {
    status: "CANCELLED",
    note: "One team sufficient at scene",
  }).expect(200);
  expect((await row(a.incident_id)).status).toBe("TEAM_ON_SCENE");
  await post(rescuer, `/assignments/${a.id}/status`, {
    status: "IN_PROGRESS",
  }).expect(200);
  await post(rescuer, `/assignments/${a.id}/status`, {
    status: "COMPLETED",
    note: "All remaining needs addressed",
  }).expect(200);
  expect((await row(a.incident_id)).status).toBe("RESOLVED");
});
it("enforces department and jurisdiction scope including cross-department incident closure", async () => {
  const a = await offer();
  const dep = (
    await pool.query("SELECT id FROM departments WHERE name='Fire and Rescue'")
  ).rows[0].id;
  await pool.query("INSERT INTO incident_departments VALUES($1,$2)", [
    a.incident_id,
    dep,
  ]);
  const other = await otherTeam(dep);
  const b = (
    await post(admin, "/assignments", {
      incidentId: a.incident_id,
      teamId: other.teamId,
    }).expect(201)
  ).body;
  await post(authority, `/assignments/${b.id}/status`, {
    status: "CANCELLED",
    note: "Outside department attempt",
  }).expect(404);
  await post(authority, `/incidents/${a.incident_id}/status`, {
    status: "UNABLE_TO_RESPOND",
    note: "Cannot close another department work",
  }).expect(404);
  expect(
    (
      await pool.query("SELECT status FROM incident_assignments WHERE id=$1", [
        a.id,
      ])
    ).rows[0].status,
  ).toBe("OFFERED");
  const j = (
    await pool.query(
      "INSERT INTO jurisdictions(name,boundary) VALUES($1,ST_Multi(ST_MakeEnvelope(0,0,1,1,4326))) RETURNING id",
      [randomUUID()],
    )
  ).rows[0].id;
  const outside = await otherUser("AUTHORITY", authority.user.department_id, j);
  await post(outside, `/incidents/${a.incident_id}/status`, {
    status: "CANCELLED",
    note: "Wrong jurisdiction",
  }).expect(404);
});
it("expires offers durably and refuses acceptance even before a worker processes expiry", async () => {
  const a = await offer();
  await pool.query(
    "UPDATE assignment_deadlines SET due_at=now()-interval '1 second' WHERE assignment_id=$1",
    [a.id],
  );
  await post(rescuer, `/assignments/${a.id}/status`, {
    status: "ACCEPTED",
  }).expect(409);
  const { runAssignmentDeadlines } = await import("../apps/api/src/jobs");
  await Promise.all([runAssignmentDeadlines(), runAssignmentDeadlines()]);
  expect(
    (
      await pool.query("SELECT status FROM incident_assignments WHERE id=$1", [
        a.id,
      ])
    ).rows[0].status,
  ).toBe("CANCELLED");
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM audit_events WHERE entity_id=$1 AND action='ASSIGNMENT_DEADLINE'",
        [a.id],
      )
    ).rows[0].n,
  ).toBe(1);
  await post(rescuer, `/assignments/${a.id}/status`, {
    status: "ACCEPTED",
  }).expect(404);
});
it.each(["ACCEPTED", "EN_ROUTE", "IN_PROGRESS"])(
  "deadline expiry at %s requests review without fabricating outcomes and survives worker restart",
  async (phase) => {
    const a = await offer();
    await advance(a, phase);
    const before = await row(a.incident_id);
    await pool.query(
      "UPDATE assignment_deadlines SET due_at=now()-interval '1 second' WHERE assignment_id=$1 AND completed_at IS NULL",
      [a.id],
    );
    execFileSync(
      process.execPath,
      [
        "--import",
        "tsx",
        "--input-type=module",
        "-e",
        "const {runAssignmentDeadlines}=await import('./apps/api/src/jobs.ts');await runAssignmentDeadlines();const {pool}=await import('./apps/api/src/db.ts');await pool.end();",
      ],
      { env: process.env, stdio: "pipe" },
    );
    const { runAssignmentDeadlines } = await import("../apps/api/src/jobs");
    await runAssignmentDeadlines();
    expect((await row(a.incident_id)).status).toBe(before.status);
    expect((await row(a.incident_id)).escalation_state).toBe(
      "CONTROL_REVIEW_REQUIRED",
    );
    expect(
      (
        await pool.query(
          "SELECT status FROM incident_assignments WHERE id=$1",
          [a.id],
        )
      ).rows[0].status,
    ).toBe(phase);
    expect(
      (
        await pool.query(
          "SELECT count(*)::int n FROM audit_events WHERE entity_id=$1 AND action='ASSIGNMENT_DEADLINE'",
          [a.id],
        )
      ).rows[0].n,
    ).toBe(1);
  },
);
it("configured windows are persisted and dispatch supersedes its acceptance deadline", async () => {
  const p = (await pool.query("SELECT * FROM escalation_policies LIMIT 1"))
    .rows[0];
  await admin.agent
    .put(`/api/v1/admin/policies/${p.id}`)
    .set("Origin", origin)
    .set("X-CSRF-Token", admin.csrf)
    .send({
      radii: [5000, 10000],
      delays: [0, 60],
      offerTimeoutSeconds: 70,
      dispatchTimeoutSeconds: 80,
      progressTimeoutSeconds: 100,
    })
    .expect(200);
  try {
    const a = await offer();
    await advance(a, "ACCEPTED");
    expect(
      (
        await pool.query(
          "SELECT round(extract(epoch FROM due_at-created_at))::int seconds FROM assignment_deadlines WHERE assignment_id=$1 AND phase='ACCEPTED'",
          [a.id],
        )
      ).rows[0].seconds,
    ).toBe(80);
    await post(authority, `/assignments/${a.id}/status`, {
      status: "DISPATCHED",
    }).expect(200);
    expect(
      (
        await pool.query(
          "SELECT phase FROM assignment_deadlines WHERE assignment_id=$1 AND completed_at IS NULL",
          [a.id],
        )
      ).rows.map((x) => x.phase),
    ).toEqual(["DISPATCHED"]);
  } finally {
    await pool.query(
      "UPDATE escalation_policies SET radii_m=$2,delays_seconds=$3,offer_timeout_seconds=$4,dispatch_timeout_seconds=$5,progress_timeout_seconds=$6 WHERE id=$1",
      [
        p.id,
        p.radii_m,
        p.delays_seconds,
        p.offer_timeout_seconds,
        p.dispatch_timeout_seconds,
        p.progress_timeout_seconds,
      ],
    );
  }
});
it("geographic rings expand without repeatedly alerting the same team and stop at a finite review", async () => {
  const id = await incident(),
    far = await otherTeam(authority.user.department_id, 19.145, 72.8777);
  await runEscalations();
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM notification_jobs WHERE incident_id=$1 AND recipient_id=$2 AND dedupe_key LIKE 'eligible:%'",
        [id, far.user.user.id],
      )
    ).rows[0].n,
  ).toBe(0);
  await pool.query(
    "UPDATE escalation_executions SET due_at=now() WHERE incident_id=$1 AND completed_at IS NULL",
    [id],
  );
  await Promise.all([runEscalations(), runEscalations()]);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM notification_jobs WHERE incident_id=$1 AND recipient_id=$2 AND dedupe_key LIKE 'eligible:%'",
        [id, far.user.user.id],
      )
    ).rows[0].n,
  ).toBe(1);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM notification_jobs WHERE incident_id=$1 AND recipient_id=$2 AND dedupe_key LIKE 'eligible:%'",
        [id, rescuer.user.id],
      )
    ).rows[0].n,
  ).toBe(1);
  await pool.query(
    "UPDATE escalation_executions SET due_at=now() WHERE incident_id=$1 AND completed_at IS NULL",
    [id],
  );
  await runEscalations();
  await runEscalations();
  expect(
    (
      await pool.query(
        "SELECT radius_m FROM escalation_executions WHERE incident_id=$1 ORDER BY stage",
        [id],
      )
    ).rows.map((x) => x.radius_m),
  ).toEqual([5000, 10000, 25000]);
  expect((await row(id)).escalation_state).toBe("REGIONAL_REVIEW_REQUIRED");
  const outcomes = (
    await pool.query(
      "SELECT outcome FROM escalation_executions WHERE incident_id=$1 ORDER BY stage",
      [id],
    )
  ).rows.map((x) => x.outcome);
  expect(outcomes[1]).toBe("ALERTED_1_TEAMS");
  expect(outcomes[2]).toBe("ALERTED_0_TEAMS:REGIONAL_REVIEW_REQUIRED");
});
it.each(["missing", "stale", "inaccurate", "off-duty", "inactive"])(
  "excludes %s team locations or availability from eligibility",
  async (kind) => {
    const id = await incident();
    const sql: Record<string, string> = {
      missing: "location=NULL",
      stale: "location_at=now()-interval '2 minutes'",
      inaccurate: "accuracy=300",
      "off-duty": "availability='OFF_DUTY'",
      inactive: "location_at=now()",
    };
    await pool.query(`UPDATE rescue_teams SET ${sql[kind]} WHERE id=$1`, [
      teamId,
    ]);
    if (kind === "inactive")
      await pool.query(
        "UPDATE user_profiles SET status='INACTIVE' WHERE id=$1",
        [rescuer.user.id],
      );
    try {
      const r = await authority.agent
        .get(`/api/v1/incidents/${id}/eligible-teams`)
        .expect(200);
      expect(r.body.items.some((t: any) => t.id === teamId)).toBe(false);
    } finally {
      await pool.query("UPDATE user_profiles SET status='ACTIVE' WHERE id=$1", [
        rescuer.user.id,
      ]);
    }
  },
);
it("does not expose precise responder coordinates to the citizen and rejects invalid samples", async () => {
  const a = await offer();
  await advance(a, "DISPATCHED");
  const r = await citizen.agent
    .get(`/api/v1/locations/incidents/${a.incident_id}`)
    .expect(200);
  expect(r.body.teams[0].tracking).toBe("LIVE");
  expect(r.body.teams[0]).not.toHaveProperty("latitude");
  expect(r.body.teams[0]).not.toHaveProperty("longitude");
  const s = (
    await pool.query(
      "SELECT id FROM location_sessions WHERE team_id=$1 AND active",
      [teamId],
    )
  ).rows[0].id;
  await post(rescuer, "/locations/updates", {
    sessionId: s,
    latitude: 91,
    longitude: 72,
    accuracy: 10,
    observedAt: new Date().toISOString(),
  }).expect(400);
  await post(rescuer, `/teams/${teamId}/duty`, {
    availability: "OFF_DUTY",
  }).expect(200);
  await rescuer.agent.get(`/api/v1/locations/sessions/${s}`).expect(403);
  await post(rescuer, "/locations/updates", {
    sessionId: s,
    latitude: 19,
    longitude: 72,
    accuracy: 10,
    observedAt: new Date().toISOString(),
  }).expect(403);
});
async function resource(type = "MEDICAL_SUPPLIES", quantity = 3) {
  return (
    await post(authority, "/resources", {
      name: "Isolated resource",
      type,
      departmentId: authority.user.department_id,
      jurisdictionId: authority.user.jurisdiction_id,
      teamId,
      quantity,
    }).expect(201)
  ).body.id as string;
}
it.each(["SHELTER_CAPACITY", "MEDICAL_SUPPLIES"])(
  "serializes %s capacity reservations, preserves nonnegative stock and records the responsible authority",
  async (type) => {
    const id = await incident(),
      r = await resource(type);
    const results = await Promise.all(
      [1, 2].map(() =>
        post(authority, `/resources/${r}/allocate`, {
          incidentId: id,
          quantity: 2,
        }),
      ),
    );
    expect(results.map((x) => x.status).sort()).toEqual([201, 409]);
    const a = results.find((x) => x.status === 201)!.body.id;
    expect(
      (
        await pool.query(
          "SELECT created_by FROM resource_allocations WHERE id=$1",
          [a],
        )
      ).rows[0].created_by,
    ).toBe(authority.user.id);
    await patch(authority, `/resources/${r}`, {
      quantity: 1,
      status: "AVAILABLE",
    }).expect(409);
    await patch(authority, `/resources/${r}`, {
      quantity: -1,
      status: "AVAILABLE",
    }).expect(400);
    await post(citizen, `/resources/${r}/allocate`, {
      incidentId: id,
      quantity: 1,
    }).expect(403);
    await post(authority, `/resources/allocations/${a}/release`, {}).expect(
      200,
    );
    await post(authority, `/resources/allocations/${a}/release`, {}).expect(
      200,
    );
    expect(
      (
        await pool.query(
          "SELECT count(*)::int n FROM audit_events WHERE entity_id=$1 AND action='RESOURCE_RELEASED'",
          [r],
        )
      ).rows[0].n,
    ).toBe(1);
  },
);
it("records authorized field resource usage once and never consumes shelter capacity", async () => {
  const a = await offer();
  await advance(a, "DISPATCHED");
  for (const type of ["MEDICAL_SUPPLIES", "SHELTER_CAPACITY"]) {
    const r = await resource(type),
      allocation = (
        await post(authority, `/resources/${r}/allocate`, {
          incidentId: a.incident_id,
          quantity: 2,
        }).expect(201)
      ).body.id;
    await post(rescuer, `/resources/allocations/${allocation}/status`, {
      status: "DISPATCHED",
      note: "Received and used at assigned scene",
    }).expect(200);
    await post(rescuer, `/resources/allocations/${allocation}/status`, {
      status: "CONSUMED",
      note: "Supplies consumed during response",
    }).expect(type === "SHELTER_CAPACITY" ? 409 : 200);
    if (type !== "SHELTER_CAPACITY") {
      await post(rescuer, `/resources/allocations/${allocation}/status`, {
        status: "CONSUMED",
        note: "Same consumed outcome retry",
      }).expect(200);
      expect(
        (await pool.query("SELECT quantity FROM resources WHERE id=$1", [r]))
          .rows[0].quantity,
      ).toBe(1);
    }
  }
});
it("rolls back a valid resource edit if its audit write fails", async () => {
  const r = await resource();
  const db = await import("../apps/api/src/db");
  const spy = vi
    .spyOn(db, "audit")
    .mockRejectedValueOnce(new Error("Injected audit failure"));
  try {
    await patch(authority, `/resources/${r}`, {
      quantity: 8,
      status: "AVAILABLE",
    }).expect(500);
  } finally {
    spy.mockRestore();
  }
  expect(
    (await pool.query("SELECT quantity FROM resources WHERE id=$1", [r]))
      .rows[0].quantity,
  ).toBe(3);
  await patch(authority, `/resources/${r}`, {
    quantity: 8,
    status: "AVAILABLE",
  }).expect(200);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM audit_events WHERE entity_id=$1 AND action='RESOURCE_UPDATED'",
        [r],
      )
    ).rows[0].n,
  ).toBe(1);
});
it("rolls back an assignment transition and its deadline when auditing fails", async () => {
  const a = await offer();
  const db = await import("../apps/api/src/db");
  const spy = vi
    .spyOn(db, "audit")
    .mockRejectedValueOnce(new Error("Injected audit failure"));
  try {
    await post(rescuer, `/assignments/${a.id}/status`, {
      status: "ACCEPTED",
    }).expect(500);
  } finally {
    spy.mockRestore();
  }
  expect(
    (
      await pool.query("SELECT status FROM incident_assignments WHERE id=$1", [
        a.id,
      ])
    ).rows[0].status,
  ).toBe("OFFERED");
  expect(
    (
      await pool.query(
        "SELECT phase FROM assignment_deadlines WHERE assignment_id=$1 AND completed_at IS NULL",
        [a.id],
      )
    ).rows.map((x) => x.phase),
  ).toEqual(["OFFERED"]);
});
it("rejects acceptance after the team goes off duty without inventing a responder outcome", async () => {
  const a = await offer();
  await post(rescuer, `/teams/${teamId}/duty`, {
    availability: "OFF_DUTY",
  }).expect(200);
  await post(rescuer, `/assignments/${a.id}/status`, {
    status: "ACCEPTED",
  }).expect(409);
  expect(
    (
      await pool.query("SELECT status FROM incident_assignments WHERE id=$1", [
        a.id,
      ])
    ).rows[0].status,
  ).toBe("OFFERED");
});
it("resource update failure does not leave a success audit entry", async () => {
  const r = await resource();
  await pool.query(
    "CREATE FUNCTION fail_resource_update_test() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Injected resource write failure'; END $$; CREATE TRIGGER fail_resource_update_test BEFORE UPDATE ON resources FOR EACH ROW EXECUTE FUNCTION fail_resource_update_test()",
  );
  try {
    await patch(authority, `/resources/${r}`, {
      quantity: 9,
      status: "AVAILABLE",
    }).expect(500);
  } finally {
    await pool.query(
      "DROP TRIGGER fail_resource_update_test ON resources; DROP FUNCTION fail_resource_update_test()",
    );
  }
  expect(
    (await pool.query("SELECT quantity FROM resources WHERE id=$1", [r]))
      .rows[0].quantity,
  ).toBe(3);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM audit_events WHERE entity_id=$1 AND action='RESOURCE_UPDATED'",
        [r],
      )
    ).rows[0].n,
  ).toBe(0);
});
it("manual assignment and simultaneous escalation never create conflicting assignment records", async () => {
  const id = await incident();
  const results = await Promise.all([
    post(authority, "/assignments", { incidentId: id, teamId }),
    runEscalations(),
  ]);
  expect(results[0].status).toBe(201);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM incident_assignments WHERE incident_id=$1 AND status='OFFERED'",
        [id],
      )
    ).rows[0].n,
  ).toBe(1);
});
it("retries a failed deadline transaction without losing work or duplicating logical notifications", async () => {
  const a = await offer();
  await pool.query(
    "UPDATE assignment_deadlines SET due_at=now()-interval '1 second' WHERE assignment_id=$1",
    [a.id],
  );
  const db = await import("../apps/api/src/db"),
    { runAssignmentDeadlines } = await import("../apps/api/src/jobs");
  const spy = vi
    .spyOn(db, "audit")
    .mockRejectedValueOnce(new Error("Injected transient transaction failure"));
  try {
    await expect(runAssignmentDeadlines()).rejects.toThrow("Injected");
  } finally {
    spy.mockRestore();
  }
  expect(
    (
      await pool.query("SELECT status FROM incident_assignments WHERE id=$1", [
        a.id,
      ])
    ).rows[0].status,
  ).toBe("OFFERED");
  expect(
    (
      await pool.query(
        "SELECT completed_at FROM assignment_deadlines WHERE assignment_id=$1",
        [a.id],
      )
    ).rows[0].completed_at,
  ).toBeNull();
  await runAssignmentDeadlines();
  const before = (
    await pool.query(
      "SELECT count(*)::int n FROM notification_jobs WHERE incident_id=$1",
      [a.incident_id],
    )
  ).rows[0].n;
  await runAssignmentDeadlines();
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM notification_jobs WHERE incident_id=$1",
        [a.incident_id],
      )
    ).rows[0].n,
  ).toBe(before);
});
it("rescuer resource controls are hidden until their team is dispatched", async () => {
  const a = await offer(),
    r = await resource();
  await post(authority, `/resources/${r}/allocate`, {
    incidentId: a.incident_id,
    quantity: 1,
  }).expect(201);
  const before = await rescuer.agent
    .get(`/api/v1/incidents/${a.incident_id}/resource-allocations`)
    .expect(200);
  expect(before.body.items[0].allowed_actions).toEqual([]);
  await advance(a, "DISPATCHED");
  const after = await rescuer.agent
    .get(`/api/v1/incidents/${a.incident_id}/resource-allocations`)
    .expect(200);
  expect(after.body.items[0].allowed_actions).toEqual(["DISPATCHED"]);
});
it("allows only scoped resource creation, editing and explicit public location publication", async () => {
  const dep = (
    await pool.query("SELECT id FROM departments WHERE name='Fire and Rescue'")
  ).rows[0].id;
  await post(authority, "/resources", {
    name: "Wrong department resource",
    type: "SHELTER_CAPACITY",
    quantity: 3,
    departmentId: dep,
    jurisdictionId: authority.user.jurisdiction_id,
  }).expect(403);
  const r = await resource("SHELTER_CAPACITY");
  await patch(authority, `/resources/${r}/location`, {
    latitude: 19.077,
    longitude: 72.878,
    address: "Verified exercise site",
    publiclyListed: false,
  }).expect(200);
  expect(
    (
      await citizen.agent.get("/api/v1/resource-locations").expect(200)
    ).body.items.some((x: any) => x.id === r),
  ).toBe(false);
  await patch(authority, `/resources/${r}/location`, {
    latitude: 19.077,
    longitude: 72.878,
    address: "Verified exercise site",
    publiclyListed: true,
  }).expect(200);
  expect(
    (
      await citizen.agent.get("/api/v1/resource-locations").expect(200)
    ).body.items.some((x: any) => x.id === r),
  ).toBe(true);
  await patch(citizen, `/resources/${r}`, {
    quantity: 4,
    status: "AVAILABLE",
  }).expect(403);
  const wrong = await otherUser("AUTHORITY", dep);
  await patch(wrong, `/resources/${r}`, {
    quantity: 4,
    status: "AVAILABLE",
  }).expect(404);
});
it("deduplicates assignment notices and simulates external delivery without contacting providers", async () => {
  const { queueExternalNotifications, sendNotifications } =
    await import("../apps/api/src/jobs");
  const { config } = await import("../apps/api/src/config");
  const old = config.NOTIFICATION_TRANSPORT;
  config.NOTIFICATION_TRANSPORT = "simulator";
  try {
    const a = await offer();
    await Promise.all([
      post(rescuer, `/assignments/${a.id}/status`, { status: "ACCEPTED" }),
      post(rescuer, `/assignments/${a.id}/status`, { status: "ACCEPTED" }),
    ]);
    await Promise.all([
      queueExternalNotifications(a.incident_id),
      queueExternalNotifications(a.incident_id),
    ]);
    await sendNotifications();
    await sendNotifications();
    const jobs = (
      await pool.query(
        "SELECT n.id,n.status,(SELECT count(*)::int FROM notification_attempts na WHERE na.job_id=n.id) attempts FROM notification_jobs n WHERE n.incident_id=$1 AND n.channel IN('SMS','EMAIL')",
        [a.incident_id],
      )
    ).rows;
    expect(jobs.length).toBeGreaterThan(0);
    expect(
      jobs.every((j) => j.status === "SIMULATED" && j.attempts === 1),
    ).toBe(true);
    const messages = await rescuer.agent
      .get("/api/v1/notifications")
      .expect(200);
    const notice = messages.body.items.find(
      (n: any) => n.incident_id === a.incident_id,
    );
    expect(notice).not.toHaveProperty("description");
    expect(notice).not.toHaveProperty("latitude");
  } finally {
    config.NOTIFICATION_TRANSPORT = old;
  }
});
it("refuses reopened assignment actions without explicit dispatcher reopening and retains prior deadlines", async () => {
  const a = await offer();
  await advance(a, "COMPLETED");
  await post(rescuer, `/assignments/${a.id}/status`, {
    status: "ACCEPTED",
  }).expect(409);
  await post(authority, `/incidents/${a.incident_id}/status`, {
    status: "REOPENED",
  }).expect(200);
  await post(authority, "/assignments", {
    incidentId: a.incident_id,
    teamId,
  }).expect(409);
  await post(authority, `/incidents/${a.incident_id}/status`, {
    status: "ACKNOWLEDGED",
  }).expect(200);
  await offer(a.incident_id);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM assignment_deadlines WHERE assignment_id=$1 AND completed_at IS NULL",
        [a.id],
      )
    ).rows[0].n,
  ).toBe(0);
});
it("restricted runtime role can process new deadlines and audit cancellation but cannot alter schema or history", async () => {
  const a = await offer();
  const { SecretsManagerClient } =
    await import("@aws-sdk/client-secrets-manager");
  const { prepareDatabase } = await import("../scripts/prepare-database");
  const { cancelAssignment, finishAssignment } =
    await import("../apps/api/src/workflow");
  const old = process.env.APP_DB_SECRET_ARN;
  process.env.APP_DB_SECRET_ARN = "stub-only-task3-runtime-secret";
  const spy = vi
    .spyOn(SecretsManagerClient.prototype, "send")
    .mockResolvedValue({
      SecretString: JSON.stringify({
        username: "response_app",
        password: randomUUID() + randomUUID(),
      }),
    } as never);
  try {
    await prepareDatabase();
  } finally {
    spy.mockRestore();
    if (old === undefined) delete process.env.APP_DB_SECRET_ARN;
    else process.env.APP_DB_SECRET_ARN = old;
  }
  const db = await pool.connect();
  try {
    await db.query("BEGIN; SET LOCAL ROLE response_app");
    await db.query("SELECT id FROM incidents WHERE id=$1 FOR UPDATE", [
      a.incident_id,
    ]);
    await cancelAssignment(
      db,
      a,
      authority.user.id,
      "Controlled runtime role cancellation",
    );
    await finishAssignment(db, a, authority.user.id);
    await db.query("COMMIT");
    await db.query("BEGIN; SET LOCAL ROLE response_app");
    await expect(
      db.query("DELETE FROM assignment_deadlines WHERE false"),
    ).resolves.toBeDefined();
    await expect(
      db.query("ALTER TABLE assignment_deadlines ADD COLUMN bypass integer"),
    ).rejects.toThrow();
    await db.query("ROLLBACK");
    await db.query("BEGIN; SET LOCAL ROLE response_app");
    await expect(
      db.query("DELETE FROM audit_events WHERE entity_id=$1", [a.id]),
    ).rejects.toThrow();
    await db.query("ROLLBACK");
  } finally {
    await db.query("ROLLBACK");
    db.release();
  }
  expect(
    (
      await pool.query("SELECT status FROM incident_assignments WHERE id=$1", [
        a.id,
      ])
    ).rows[0].status,
  ).toBe("CANCELLED");
});
it("does not let historical reporter ownership bypass Authority department scope", async () => {
  const id = await incident();
  await pool.query("UPDATE incidents SET reporter_id=$2 WHERE id=$1", [
    id,
    authority.user.id,
  ]);
  const dep = (
    await pool.query("SELECT id FROM departments WHERE name='Fire and Rescue'")
  ).rows[0].id;
  await pool.query("DELETE FROM incident_departments WHERE incident_id=$1", [
    id,
  ]);
  await pool.query("INSERT INTO incident_departments VALUES($1,$2)", [id, dep]);
  await post(authority, `/incidents/${id}/status`, {
    status: "CANCELLED",
    note: "Historical reporter must not bypass role scope",
  }).expect(404);
});
it("retries a definitively failed notification once without duplicating a submitted delivery (SDK stub)", async () => {
  const { SNSClient } = await import("@aws-sdk/client-sns");
  const { sendNotifications } = await import("../apps/api/src/jobs");
  const { config } = await import("../apps/api/src/config");
  const old = {
    SMS_ENABLED: config.SMS_ENABLED,
    NOTIFICATION_TRANSPORT: config.NOTIFICATION_TRANSPORT,
    EMAIL_FROM: config.EMAIL_FROM,
  };
  Object.assign(config, {
    SMS_ENABLED: "true",
    NOTIFICATION_TRANSPORT: "aws",
    EMAIL_FROM: "",
  });
  const spy = vi.spyOn(SNSClient.prototype, "send");
  try {
    await pool.query(
      "UPDATE notification_jobs SET status='FAILED' WHERE channel='SMS' AND status='PENDING'",
    );
    await pool.query(
      "UPDATE user_profiles SET sms_enabled=true,phone='+999000000001' WHERE id=$1",
      [authority.user.id],
    );
    const id = await incident(),
      job = (
        await pool.query(
          "INSERT INTO notification_jobs(incident_id,recipient_id,channel,dedupe_key) VALUES($1,$2,'SMS',$3) RETURNING id",
          [id, authority.user.id, randomUUID()],
        )
      ).rows[0].id;
    spy.mockRejectedValueOnce(
      Object.assign(new Error("Stub provider rejected request"), {
        name: "RejectedStub",
        $metadata: { httpStatusCode: 400 },
      }),
    );
    await sendNotifications();
    expect(
      (
        await pool.query("SELECT status FROM notification_jobs WHERE id=$1", [
          job,
        ])
      ).rows[0].status,
    ).toBe("FAILED");
    await post(authority, `/admin/notifications/${job}/retry`, {}).expect(403);
    await post(admin, `/admin/notifications/${job}/retry`, {}).expect(200);
    spy.mockResolvedValueOnce({ MessageId: "stub-task3-provider-id" } as never);
    await sendNotifications();
    await sendNotifications();
    expect(
      (
        await pool.query("SELECT status FROM notification_jobs WHERE id=$1", [
          job,
        ])
      ).rows[0].status,
    ).toBe("SUBMITTED");
    expect(spy).toHaveBeenCalledTimes(2);
    await post(admin, `/admin/notifications/${job}/retry`, {}).expect(409);
  } finally {
    spy.mockRestore();
    Object.assign(config, old);
  }
});

import { gzipSync } from "node:zlib";
import { handler as receiptHandler } from "../apps/api/src/sms-receipts";
import { SecretsManagerClient } from "@aws-sdk/client-secrets-manager";
import { prepareDatabase } from "../scripts/prepare-database";
import { readFile, writeFile, mkdir, mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { config } from "../apps/api/src/config";
import {
  assertSchemaReady,
  requiredMigrations,
} from "../apps/api/src/schema-readiness";
import { handler } from "../apps/api/src/lambda";
import { afterAll, beforeEach, expect, it, vi } from "vitest";
import request from "supertest";
import { app } from "../apps/api/src/app";
import { pool } from "../apps/api/src/db";
import { migrate } from "../scripts/migrations";
beforeEach(async () => {
  if (!new URL(process.env.DATABASE_URL!).pathname.endsWith("_test"))
    throw new Error("Dedicated test database required");
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public");
  await migrate();
});
afterAll(async () => {
  await pool.end();
});
it("reports ready only for the migrated schema", async () => {
  const r = await request(app).get("/api/v1/health/ready").expect(200);
  expect(r.body).toEqual({ status: "ready" });
});
it("rejects a missing migration ledger", async () => {
  await pool.query("DROP TABLE schema_migrations");
  expect(
    (await request(app).get("/api/v1/health/ready").expect(503)).body,
  ).toEqual({ status: "unavailable" });
});
it("reproduces an empty ledger with no application schema", async () => {
  await pool.query(
    "DROP SCHEMA public CASCADE; CREATE SCHEMA public; CREATE TABLE schema_migrations(name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())",
  );
  expect(
    (await request(app).get("/api/v1/health/ready").expect(503)).body,
  ).toEqual({ status: "unavailable" });
});
it("rejects a ledger claiming completion when incidents is absent", async () => {
  await pool.query("ALTER TABLE incidents RENAME TO missing_incidents");
  expect(
    (await request(app).get("/api/v1/health/ready").expect(503)).body,
  ).toEqual({ status: "unavailable" });
});

it.each(["sessions", "notification_jobs", "resources", "incident_assignments"])(
  "rejects a missing required table: %s",
  async (table) => {
    await pool.query(`ALTER TABLE ${table} RENAME TO missing_${table}`);
    await request(app).get("/api/v1/health/ready").expect(503);
  },
);
it("rejects a missing migration without applying it from a health request", async () => {
  await pool.query(
    "DELETE FROM schema_migrations WHERE name='007_operational_workflows.sql'",
  );
  await request(app).get("/api/v1/health/ready").expect(503);
  expect(
    (await pool.query("SELECT count(*)::int AS n FROM schema_migrations"))
      .rows[0].n,
  ).toBe(requiredMigrations.length - 1);
});
it("rejects unknown migration versions", async () => {
  await pool.query(
    "INSERT INTO schema_migrations(name) VALUES('999_unknown.sql')",
  );
  await request(app).get("/api/v1/health/ready").expect(503);
  await expect(migrate()).rejects.toThrow("migration ledger");
});
it("rejects malformed migration ledger metadata", async () => {
  await pool.query(
    "ALTER TABLE schema_migrations ALTER COLUMN applied_at DROP DEFAULT; ALTER TABLE schema_migrations ALTER COLUMN applied_at TYPE text USING applied_at::text",
  );
  await request(app).get("/api/v1/health/ready").expect(503);
});
it.each([
  "ALTER TABLE resources DROP COLUMN address",
  "DROP INDEX active_assignment_unique",
  "ALTER TABLE audit_events DISABLE TRIGGER immutable_audit",
  "DROP TRIGGER immutable_history ON incident_status_history",
  "ALTER TABLE resources DROP CONSTRAINT resources_quantity_check",
  "ALTER TABLE resources DROP CONSTRAINT resources_quantity_check; ALTER TABLE resources ADD CONSTRAINT resources_quantity_check CHECK (quantity>=0) NOT VALID",
  "DROP FUNCTION deny_audit_mutation() CASCADE",
  "DROP EXTENSION pgcrypto CASCADE",
])("rejects missing or invalid schema objects %#", async (sql) => {
  await pool.query(sql);
  expect(
    (await request(app).get("/api/v1/health/ready").expect(503)).body,
  ).toEqual({ status: "unavailable" });
});
it("keeps liveness independent and bounds a blocked database query", async () => {
  const client = await pool.connect();
  const old = config.READINESS_TIMEOUT_MS;
  config.READINESS_TIMEOUT_MS = 100;
  try {
    await client.query(
      "BEGIN; LOCK TABLE schema_migrations IN ACCESS EXCLUSIVE MODE",
    );
    expect((await request(app).get("/api/v1/health").expect(200)).body).toEqual(
      { status: "ok" },
    );
    const start = Date.now();
    const response = await request(app).get("/api/v1/health/ready").expect(503);
    expect(Date.now() - start).toBeLessThan(1000);
    expect(response.body).toEqual({ status: "unavailable" });
    expect(response.headers["cache-control"]).toBe("no-store");
  } finally {
    await client.query("ROLLBACK");
    client.release();
    config.READINESS_TIMEOUT_MS = old;
  }
  await request(app).get("/api/v1/health/ready").expect(200);
});
it("redacts connection failures while liveness remains available", async () => {
  const spy = vi
    .spyOn(pool, "connect")
    .mockRejectedValueOnce(
      new Error(
        "postgresql://hidden:secret-value@internal-db/private SQL SELECT secret",
      ),
    );
  try {
    const r = await request(app).get("/api/v1/health/ready").expect(503);
    expect(r.body).toEqual({ status: "unavailable" });
    expect(r.text).not.toMatch(/hidden|secret-value|internal-db|SELECT|stack/);
    await request(app).get("/api/v1/health").expect(200);
  } finally {
    spy.mockRestore();
  }
});
it("validates readiness using the production-style restricted runtime role", async () => {
  // This assertion runs with the same catalog inspection under an explicitly
  // restricted transaction role, without changing credentials or global grants.
  const db = await pool.connect();
  try {
    await db.query(
      "BEGIN; CREATE ROLE readiness_probe_test NOLOGIN; GRANT USAGE ON SCHEMA public TO readiness_probe_test; GRANT SELECT ON schema_migrations TO readiness_probe_test; SET LOCAL ROLE readiness_probe_test",
    );
    await assertSchemaReady(db);
  } finally {
    await db.query("ROLLBACK");
    db.release();
  }
});
it("upgrades a representative pre-007 database without losing existing data", async () => {
  await pool.query(
    "DROP SCHEMA public CASCADE; CREATE SCHEMA public; CREATE TABLE schema_migrations(name text PRIMARY KEY,applied_at timestamptz NOT NULL DEFAULT now())",
  );
  for (const name of requiredMigrations.filter((name) => name < "007")) {
    await pool.query(await readFile(`db/migrations/${name}`, "utf8"));
    await pool.query("INSERT INTO schema_migrations(name) VALUES($1)", [name]);
  }
  const id = (
    await pool.query(
      "INSERT INTO organizations(name) VALUES('Preserved upgrade organization') RETURNING id",
    )
  ).rows[0].id;
  await request(app).get("/api/v1/health/ready").expect(503);
  await migrate();
  expect(
    (await pool.query("SELECT name FROM organizations WHERE id=$1", [id]))
      .rows[0].name,
  ).toBe("Preserved upgrade organization");
  await request(app).get("/api/v1/health/ready").expect(200);
});
it("handles CRLF SQL checkouts and refuses tampered migration assets before writes", async () => {
  const root = process.cwd(),
    temp = await mkdtemp(join(tmpdir(), "response-migrations-"));
  try {
    await mkdir(join(temp, "db/migrations"), { recursive: true });
    for (const name of requiredMigrations)
      await writeFile(
        join(temp, "db/migrations", name),
        (await readFile(`db/migrations/${name}`, "utf8")).replace(
          /\n/g,
          "\r\n",
        ),
      );
    await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public");
    process.chdir(temp);
    await migrate();
    await request(app).get("/api/v1/health/ready").expect(200);
    await writeFile(
      join(temp, "db/migrations", requiredMigrations[0]),
      "SELECT 1;",
    );
    await expect(migrate()).rejects.toThrow("checksum");
    expect(
      (await pool.query("SELECT count(*)::int AS n FROM schema_migrations"))
        .rows[0].n,
    ).toBe(requiredMigrations.length);
  } finally {
    process.chdir(root);
    await rm(temp, { recursive: true, force: true });
  }
});
it("refuses a corrupt completed schema instead of silently skipping migrations", async () => {
  await pool.query("ALTER TABLE sessions RENAME TO missing_sessions");
  await expect(migrate()).rejects.toThrow("schema");
});
it("prevents Lambda processing when the schema is incomplete", async () => {
  await pool.query("DROP TABLE processed_events");
  await expect(handler({ Records: [] })).rejects.toThrow(
    "Database unavailable",
  );
});

it("accepts additive objects and physical index tuning without weakening schema checks", async () => {
  await pool.query(
    "CREATE INDEX extra_incidents_updated ON incidents(updated_at); ALTER INDEX incidents_reporter SET (fillfactor=80); ALTER TABLE audit_events ENABLE ALWAYS TRIGGER immutable_audit",
  );
  await request(app).get("/api/v1/health/ready").expect(200);
});
it("accepts CRLF function bodies from an existing Windows-created schema", async () => {
  const definition = (
    await pool.query(
      "SELECT pg_get_functiondef('deny_audit_mutation'::regproc) AS d",
    )
  ).rows[0].d;
  await pool.query(definition.replace(/\n/g, "\r\n"));
  await request(app).get("/api/v1/health/ready").expect(200);
});
it("validates migrator runtime credentials before changing an empty database", async () => {
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public");
  const oldMode = config.NODE_ENV,
    oldArn = process.env.APP_DB_SECRET_ARN;
  config.NODE_ENV = "production";
  process.env.APP_DB_SECRET_ARN =
    "arn:aws:secretsmanager:ap-south-1:123456789012:secret:runtime-db-Ab12Cd";
  const spy = vi
    .spyOn(SecretsManagerClient.prototype, "send")
    .mockResolvedValue({
      SecretString: JSON.stringify({
        username: "response_app",
        password: "x",
        host: "db.internal",
        port: 5432,
        dbname: "response",
      }),
    } as never);
  try {
    await expect(prepareDatabase()).rejects.toThrow();
    expect(
      (
        await pool.query(
          "SELECT to_regclass('public.schema_migrations') AS table_name",
        )
      ).rows[0].table_name,
    ).toBeNull();
  } finally {
    config.NODE_ENV = oldMode;
    if (oldArn === undefined) delete process.env.APP_DB_SECRET_ARN;
    else process.env.APP_DB_SECRET_ARN = oldArn;
    spy.mockRestore();
  }
});
it("accepts supported session display settings without schema false negatives", async () => {
  const client = await pool.connect();
  try {
    await client.query(
      "BEGIN; SET LOCAL IntervalStyle TO iso_8601; SET LOCAL search_path TO public,pg_catalog",
    );
    await assertSchemaReady(client);
  } finally {
    await client.query("ROLLBACK");
    client.release();
  }
});

it("prevents optional receipt processing against an incomplete schema", async () => {
  const old = process.env.SMS_RECEIPT_LOG_GROUPS;
  process.env.SMS_RECEIPT_LOG_GROUPS = "controlled-test-log";
  try {
    await pool.query("DROP TABLE sms_delivery_receipts");
    const data = gzipSync(
      JSON.stringify({
        messageType: "DATA_MESSAGE",
        logGroup: "controlled-test-log",
        logEvents: [],
      }),
    ).toString("base64");
    await expect(receiptHandler({ awslogs: { data } })).rejects.toThrow(
      "Database unavailable",
    );
  } finally {
    if (old === undefined) delete process.env.SMS_RECEIPT_LOG_GROUPS;
    else process.env.SMS_RECEIPT_LOG_GROUPS = old;
  }
});

it("upgrades pre-008 active assignments with bounded persisted deadlines and retains data", async () => {
  await pool.query(
    "DROP SCHEMA public CASCADE; CREATE SCHEMA public; CREATE TABLE schema_migrations(name text PRIMARY KEY,applied_at timestamptz NOT NULL DEFAULT now())",
  );
  for (const name of requiredMigrations.filter((n) => n < "008")) {
    await pool.query(await readFile(`db/migrations/${name}`, "utf8"));
    await pool.query("INSERT INTO schema_migrations(name) VALUES($1)", [name]);
  }
  const u = (
    await pool.query(
      "INSERT INTO user_profiles(cognito_sub,email,name,role) VALUES('demo:upgrade','upgrade@demo.invalid','Upgrade fixture','CITIZEN') RETURNING id",
    )
  ).rows[0].id;
  const j = (
    await pool.query(
      "INSERT INTO jurisdictions(name,boundary) VALUES('Upgrade area',ST_Multi(ST_MakeEnvelope(0,0,1,1,4326))) RETURNING id",
    )
  ).rows[0].id;
  const dep = (await pool.query("SELECT id FROM departments LIMIT 1")).rows[0]
    .id;
  const t = (
    await pool.query(
      "INSERT INTO rescue_teams(name,department_id,jurisdiction_id) VALUES('Upgrade team',$1,$2) RETURNING id",
      [dep, j],
    )
  ).rows[0].id;
  const id = (
    await pool.query(
      "INSERT INTO incidents(reporter_id,category,severity,kind,location,status) VALUES($1,'MEDICAL','HIGH','EMERGENCY',ST_SetSRID(ST_MakePoint(0.5,0.5),4326),'ACKNOWLEDGED') RETURNING id",
      [u],
    )
  ).rows[0].id;
  const a = (
    await pool.query(
      "INSERT INTO incident_assignments(incident_id,team_id,status,updated_at) VALUES($1,$2,'ACCEPTED',now()-interval '1 day') RETURNING id",
      [id, t],
    )
  ).rows[0].id;
  const before = Date.now();
  await migrate();
  await migrate();
  await request(app).get("/api/v1/health/ready").expect(200);
  const result = (
    await pool.query(
      "SELECT * FROM assignment_deadlines WHERE assignment_id=$1",
      [a],
    )
  ).rows;
  expect(result).toHaveLength(1);
  expect(result[0].phase).toBe("ACCEPTED");
  expect(result[0].completed_at).toBeNull();
  expect(new Date(result[0].due_at).getTime()).toBeGreaterThan(before + 170000);
  expect(
    (
      await pool.query("SELECT status FROM incident_assignments WHERE id=$1", [
        a,
      ])
    ).rows[0].status,
  ).toBe("ACCEPTED");
});
it("rejects missing deadline schema and invalid deadline-window configuration at the database boundary", async () => {
  await expect(
    pool.query("UPDATE escalation_policies SET dispatch_timeout_seconds=0"),
  ).rejects.toThrow();
  await pool.query("DROP INDEX assignment_deadlines_due");
  await request(app).get("/api/v1/health/ready").expect(503);
});

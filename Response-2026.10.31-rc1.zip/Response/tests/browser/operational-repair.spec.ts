import { test, expect, type BrowserContext } from "@playwright/test";
async function login(c: BrowserContext, role: string) {
  const p = await c.newPage();
  await p.goto("/");
  await p.getByRole("link", { name: /Open Development/ }).click();
  await p.getByLabel("Demo role").selectOption(role);
  await p.getByRole("button", { name: "Continue with local account" }).click();
  await expect(
    p.getByRole("link", { name: /Profile & settings/ }),
  ).toBeVisible();
  return p;
}
async function post(c: BrowserContext, path: string, body: object) {
  const me = await (await c.request.get("/api/v1/auth/me")).json();
  return c.request.post(`/api/v1${path}`, {
    headers: {
      Origin: "http://localhost:5173",
      "X-CSRF-Token": me.csrf,
      "Idempotency-Key": crypto.randomUUID(),
    },
    data: body,
  });
}
test("single-tab responder can withdraw on-scene, preserving history and allowing reassignment", async ({
  browser,
}) => {
  const cc = await browser.newContext(),
    ac = await browser.newContext(),
    rc = await browser.newContext({
      geolocation: { latitude: 19.077, longitude: 72.878 },
      permissions: ["geolocation"],
    });
  try {
    await login(cc, "citizen");
    const authority = await login(ac, "authority"),
      rescuer = await login(rc, "rescuer");
    await rescuer
      .getByRole("link", { name: "Teams & resources", exact: true })
      .click();
    const duty = rescuer.getByRole("button", {
      name: /^(Start duty|End duty)$/,
    });
    await expect(duty).toBeVisible();
    if (
      await rescuer
        .getByRole("button", { name: "End duty", exact: true })
        .isVisible()
    )
      await rescuer
        .getByRole("button", { name: "End duty", exact: true })
        .click();
    await rescuer
      .getByRole("button", { name: "Start duty", exact: true })
      .click();
    await rescuer
      .getByRole("button", { name: "Share device location" })
      .click();
    await expect(
      rescuer.getByText("Your device is sharing operational location."),
    ).toBeVisible();
    const r = await post(cc, "/incidents", {
      category: "MEDICAL",
      kind: "EMERGENCY",
      severity: "CRITICAL",
      latitude: 19.076,
      longitude: 72.8777,
      description: "Task 3 browser withdrawal exercise",
    });
    expect(r.status()).toBe(201);
    const id = (await r.json()).id;
    await authority.goto(`/incidents/${id}`);
    await authority
      .getByRole("button", { name: "Acknowledge", exact: true })
      .click();
    await authority
      .getByRole("button", { name: "Find eligible teams" })
      .click();
    const select = authority.getByLabel("Eligible team");
    const team = (await select.locator("option").nth(1).getAttribute("value"))!;
    await select.selectOption(team);
    await authority.getByRole("button", { name: "Offer assignment" }).click();
    await expect(authority.getByText("Offered", { exact: true })).toBeVisible();
    // Client-side navigation within the same page keeps the one tracking owner mounted.
    await rescuer
      .getByRole("link", { name: "Incident inbox", exact: true })
      .click();
    await rescuer
      .getByRole("textbox", { name: "Search incident ID or location" })
      .fill(id);
    await rescuer.locator(`a[href="/incidents/${id}"]`).first().click();
    await expect(
      rescuer.getByText("Your device is sharing operational location."),
    ).toBeVisible();
    await rescuer
      .getByRole("button", { name: "Accepted", exact: true })
      .click();
    await authority.getByRole("button", { name: "Authorize dispatch" }).click();
    for (const name of ["En Route", "Arrived"])
      await rescuer.getByRole("button", { name, exact: true }).click();
    await rescuer
      .getByRole("button", { name: "Unable to respond", exact: true })
      .click();
    await rescuer
      .getByLabel("Reason or outcome")
      .fill("Unsafe scene; request qualified replacement");
    await rescuer
      .getByRole("button", { name: "Confirm Cancelled", exact: true })
      .click();
    await expect(
      rescuer.getByRole("heading", { name: "Responder workspace" }),
    ).toBeVisible();
    await expect(
      rescuer.getByText("Your device is sharing operational location."),
    ).toBeVisible();
    await expect(
      authority.getByText(
        "Recorded outcome / reason: Unsafe scene; request qualified replacement",
        {
          exact: true,
        },
      ),
    ).toBeVisible({ timeout: 10000 });
    await authority
      .getByRole("button", { name: "Find eligible teams" })
      .click();
    await select.selectOption(team);
    await authority.getByRole("button", { name: "Offer assignment" }).click();
    await expect(authority.getByText("Offered", { exact: true })).toBeVisible();
    // End this browser exercise through the real cancellation form.
    await authority
      .getByRole("button", { name: "Cancelled", exact: true })
      .click();
    await authority
      .getByLabel("Reason or outcome")
      .fill("End of controlled browser exercise");
    await authority
      .getByRole("button", { name: "Confirm Cancelled", exact: true })
      .click();
    await expect(
      authority.getByRole("button", { name: "Find eligible teams" }),
    ).toHaveCount(0);
    await rescuer
      .getByRole("button", { name: "Stop sharing", exact: true })
      .click();
  } finally {
    await Promise.all([cc.close(), ac.close(), rc.close()]);
  }
});
test("authority can create and update scoped shelter capacity through existing forms", async ({
  browser,
}) => {
  const c = await browser.newContext();
  try {
    const p = await login(c, "authority");
    await p
      .getByRole("link", { name: "Teams & resources", exact: true })
      .click();
    const name = `Task 3 shelter ${Date.now()}`;
    const form = p.locator("form").filter({
      has: p.getByRole("heading", {
        name: "Shelter or resource",
        exact: true,
      }),
    });
    await form.getByLabel("Name", { exact: true }).fill(name);
    await form.getByLabel("Capacity or stock").fill("4");
    await form
      .getByRole("button", { name: "Save shelter or resource" })
      .click();
    await p.getByLabel("Inventory to update").selectOption({ label: name });
    const edit = p.locator("form").filter({
      has: p.getByRole("heading", {
        name: "Inventory capacity",
        exact: true,
      }),
    });
    await edit.getByLabel("Total capacity or stock").fill("6");
    await edit.getByRole("button", { name: "Save inventory capacity" }).click();
    await expect(p.getByRole("row").filter({ hasText: name })).toContainText(
      "6 / 6",
    );
  } finally {
    await c.close();
  }
});

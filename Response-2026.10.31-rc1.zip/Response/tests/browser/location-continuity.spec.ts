import { test, expect, type Page } from "@playwright/test";
async function start(page: Page) {
  await page.goto("/");
  await page.getByRole("link", { name: /Open Development/ }).click();
  await page.getByLabel("Demo role").selectOption("rescuer");
  await page
    .getByRole("button", { name: "Continue with local account" })
    .click();
  await page
    .getByRole("link", { name: "Teams & resources", exact: true })
    .click();
  const duty = page.getByRole("button", { name: /^(Start duty|End duty)$/ });
  await expect(duty).toBeVisible();
  if (
    await page
      .getByRole("button", { name: "End duty", exact: true })
      .isVisible()
  )
    await page.getByRole("button", { name: "End duty", exact: true }).click();
  await page.getByRole("button", { name: "Start duty", exact: true }).click();
  await page.getByRole("button", { name: "Share device location" }).click();
}
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => {
    const w = window as any;
    w.__gps = { cleared: 0, success: null, failure: null };
    const sample = () => ({
      coords: { latitude: 19.077, longitude: 72.878, accuracy: 10 },
      timestamp: Date.now(),
    });
    Object.defineProperty(navigator, "geolocation", {
      configurable: true,
      value: {
        watchPosition: (success: any, failure: any) => {
          w.__gps.success = success;
          w.__gps.failure = failure;
          setTimeout(() => success(sample()), 30);
          return 73;
        },
        clearWatch: () => {
          w.__gps.cleared++;
          w.__gps.success = null;
        },
        getCurrentPosition: (success: any) => success(sample()),
      },
    });
  });
});
test("GPS continues through ordinary single-tab navigation and stops on explicit disablement", async ({
  page,
}) => {
  await start(page);
  await expect(
    page.getByText("Your device is sharing operational location."),
  ).toBeVisible();
  await page.getByRole("link", { name: "Incident inbox", exact: true }).click();
  expect(await page.evaluate(() => (window as any).__gps.cleared)).toBe(0);
  const received = page.waitForResponse(
    (r) => r.url().endsWith("/locations/updates") && r.status() === 202,
  );
  await page.evaluate(() =>
    (window as any).__gps.success({
      coords: { latitude: 19.078, longitude: 72.879, accuracy: 10 },
      timestamp: Date.now(),
    }),
  );
  await received;
  await page.getByRole("button", { name: "Stop sharing", exact: true }).click();
  await expect
    .poll(() => page.evaluate(() => (window as any).__gps.cleared))
    .toBe(1);
});
test("ending duty stops the watch and invalidates the server session", async ({
  page,
}) => {
  await start(page);
  await expect(
    page.getByText("Your device is sharing operational location."),
  ).toBeVisible();
  await page.getByRole("button", { name: "End duty", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Start duty", exact: true }),
  ).toBeVisible();
  expect(await page.evaluate(() => (window as any).__gps.cleared)).toBe(1);
  await expect(
    page.getByRole("button", { name: "Stop sharing", exact: true }),
  ).toHaveCount(0);
});
test("permission denial stops sharing without fabricated coordinates", async ({
  page,
}) => {
  await start(page);
  await expect(
    page.getByText("Your device is sharing operational location."),
  ).toBeVisible();
  await page.evaluate(() =>
    (window as any).__gps.failure({ code: 1, message: "denied" }),
  );
  await expect(
    page.getByText("Location permission denied. Sharing stopped."),
  ).toBeVisible();
  expect(await page.evaluate(() => (window as any).__gps.cleared)).toBe(1);
});
test("unsupported geolocation does not create a sharing session", async ({
  page,
}) => {
  await page.addInitScript(() =>
    Object.defineProperty(navigator, "geolocation", {
      configurable: true,
      value: undefined,
    }),
  );
  let starts = 0;
  page.on("request", (r) => {
    if (r.url().endsWith("/locations/sessions") && r.method() === "POST")
      starts++;
  });
  await start(page);
  await expect(page.getByText(/Geolocation is not supported/)).toBeVisible();
  expect(starts).toBe(0);
});
test("stale and inaccurate samples are not uploaded as live positions", async ({
  page,
}) => {
  await start(page);
  await expect(
    page.getByText("Your device is sharing operational location."),
  ).toBeVisible();
  let updates = 0;
  page.on("request", (r) => {
    if (r.url().endsWith("/locations/updates")) updates++;
  });
  await page.evaluate(() => {
    const gps = (window as any).__gps;
    gps.success({
      coords: { latitude: 19, longitude: 72, accuracy: 10 },
      timestamp: Date.now() - 120000,
    });
    gps.success({
      coords: { latitude: 19, longitude: 72, accuracy: 300 },
      timestamp: Date.now(),
    });
  });
  await expect(page.getByText(/Location is stale or inaccurate/)).toBeVisible();
  expect(updates).toBe(0);
  await page.getByRole("button", { name: "Stop sharing", exact: true }).click();
});
test("a network upload failure stops sharing and explains recovery", async ({
  page,
}) => {
  await start(page);
  await expect(
    page.getByText("Your device is sharing operational location."),
  ).toBeVisible();
  await page.route("**/locations/updates", (r) => r.abort());
  await page.evaluate(() =>
    (window as any).__gps.success({
      coords: { latitude: 19.079, longitude: 72.88, accuracy: 10 },
      timestamp: Date.now(),
    }),
  );
  await expect(
    page.getByText(/Sharing stopped; enable it again/),
  ).toBeVisible();
  expect(await page.evaluate(() => (window as any).__gps.cleared)).toBe(1);
});
test("server revocation is checked while viewing another page", async ({
  page,
}) => {
  await start(page);
  await expect(
    page.getByText("Your device is sharing operational location."),
  ).toBeVisible();
  await page.getByRole("link", { name: "Incident inbox", exact: true }).click();
  await page.route("**/locations/sessions/*", (r) =>
    r.request().method() === "GET"
      ? r.fulfill({
          status: 403,
          contentType: "application/json",
          body: JSON.stringify({
            error: {
              message: "Location authorization revoked",
              code: "TRACKING_STOPPED",
            },
          }),
        })
      : r.continue(),
  );
  await expect(
    page.getByText(/Location authorization revoked. Sharing stopped/),
  ).toBeVisible({ timeout: 15000 });
  expect(await page.evaluate(() => (window as any).__gps.cleared)).toBe(1);
});
test("logout stops the watch even away from Teams", async ({ page }) => {
  await start(page);
  await expect(
    page.getByText("Your device is sharing operational location."),
  ).toBeVisible();
  await page.getByRole("link", { name: /Profile & settings/ }).click();
  await page.getByRole("button", { name: "Log out", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Stop sharing", exact: true }),
  ).toHaveCount(0);
  expect(await page.evaluate(() => (window as any).__gps.cleared)).toBe(1);
});

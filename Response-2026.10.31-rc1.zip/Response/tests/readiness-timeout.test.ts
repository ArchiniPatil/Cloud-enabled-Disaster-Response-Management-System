import { expect, it, vi } from "vitest";
import type { Pool, PoolClient } from "pg";
import { createReadinessCheck } from "../apps/api/src/readiness";
it("bounds pool acquisition, shares concurrent probes and releases late connections", async () => {
  let resolve!: (client: PoolClient) => void;
  const connect = vi.fn(
    () =>
      new Promise<PoolClient>((r) => {
        resolve = r;
      }),
  );
  const ready = createReadinessCheck({ connect } as unknown as Pool, () => 100);
  const start = Date.now();
  expect(await Promise.all(Array.from({ length: 12 }, () => ready()))).toEqual(
    Array(12).fill(false),
  );
  expect(Date.now() - start).toBeLessThan(1000);
  expect(connect).toHaveBeenCalledTimes(1);
  const release = vi.fn(),
    query = vi.fn();
  resolve({ release, query } as unknown as PoolClient);
  await new Promise((r) => setTimeout(r, 0));
  expect(release).toHaveBeenCalledExactlyOnceWith(true);
  expect(query).not.toHaveBeenCalled();
});
it("destroys a checked-out connection once if its query never completes", async () => {
  let finish!: () => void;
  const release = vi.fn();
  const query = vi.fn(
    () =>
      new Promise<void>((r) => {
        finish = r;
      }),
  );
  const ready = createReadinessCheck(
    { connect: async () => ({ release, query }) } as unknown as Pool,
    () => 100,
  );
  expect(await ready()).toBe(false);
  expect(release).toHaveBeenCalledExactlyOnceWith(true);
  finish();
});

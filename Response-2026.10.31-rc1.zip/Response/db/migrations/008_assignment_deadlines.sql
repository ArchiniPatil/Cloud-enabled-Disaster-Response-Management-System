-- Forward-only: retain all prior assignment/history rows and statuses.
ALTER TABLE escalation_policies
 ADD COLUMN offer_timeout_seconds integer NOT NULL DEFAULT 120 CHECK(offer_timeout_seconds BETWEEN 10 AND 86400),
 ADD COLUMN dispatch_timeout_seconds integer NOT NULL DEFAULT 180 CHECK(dispatch_timeout_seconds BETWEEN 10 AND 86400),
 ADD COLUMN progress_timeout_seconds integer NOT NULL DEFAULT 900 CHECK(progress_timeout_seconds BETWEEN 10 AND 86400);
CREATE TABLE assignment_deadlines (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 assignment_id uuid NOT NULL REFERENCES incident_assignments,
 phase text NOT NULL CHECK(phase IN('OFFERED','ACCEPTED','DISPATCHED','EN_ROUTE','ARRIVED','IN_PROGRESS')),
 due_at timestamptz NOT NULL,
 completed_at timestamptz,
 outcome text,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(assignment_id,phase),
 CHECK((completed_at IS NULL)=(outcome IS NULL))
);
CREATE INDEX assignment_deadlines_due ON assignment_deadlines(due_at) WHERE completed_at IS NULL;
CREATE UNIQUE INDEX assignment_deadlines_pending ON assignment_deadlines(assignment_id) WHERE completed_at IS NULL;
-- Existing active work gets a full review window from upgrade, never a fabricated field outcome.
INSERT INTO assignment_deadlines(assignment_id,phase,due_at)
 SELECT a.id,a.status,now()+CASE a.status WHEN 'OFFERED' THEN coalesce(p.offer_timeout_seconds,120) WHEN 'ACCEPTED' THEN coalesce(p.dispatch_timeout_seconds,180) ELSE coalesce(p.progress_timeout_seconds,900) END*interval '1 second'
 FROM incident_assignments a JOIN incidents i ON i.id=a.incident_id LEFT JOIN escalation_policies p ON p.id=i.policy_id
 WHERE a.status NOT IN('COMPLETED','DECLINED','CANCELLED') AND i.status NOT IN('RESOLVED','CANCELLED','DUPLICATE','UNABLE_TO_RESPOND');
ALTER TABLE escalation_executions ADD COLUMN radius_m integer CHECK(radius_m>0);
-- Reservations are the existing inventory/shelter capacity model. Track dispatch/use explicitly.
ALTER TABLE resource_allocations
 ADD COLUMN created_by uuid REFERENCES user_profiles,
 ADD COLUMN status text NOT NULL DEFAULT 'RESERVED' CHECK(status IN('RESERVED','DISPATCHED','CONSUMED','RELEASED')),
 ADD COLUMN usage_note text NOT NULL DEFAULT '',
 ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();
UPDATE resource_allocations SET status='RELEASED' WHERE released_at IS NOT NULL;
ALTER TABLE resource_allocations ADD CONSTRAINT allocation_release_state CHECK((released_at IS NOT NULL)=(status IN('RELEASED','CONSUMED')));

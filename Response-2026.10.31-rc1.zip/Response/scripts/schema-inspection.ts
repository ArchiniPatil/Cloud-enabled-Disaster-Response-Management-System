import type { PoolClient } from "pg";
export type SchemaObject = { kind: string; key: string; definition: string };
// Capture application objects, excluding PostGIS/pgcrypto extension members.
// Definitions, types, validation and trigger enablement matter, not just names.
export async function inspectSchema(
  db: Pick<PoolClient, "query">,
): Promise<SchemaObject[]> {
  // All callers use an explicit transaction. Canonical display settings avoid
  // false differences caused by a supported server/session IntervalStyle etc.
  await db.query(
    "SET LOCAL search_path TO pg_catalog,public; SET LOCAL IntervalStyle TO postgres; SET LOCAL DateStyle TO 'ISO, MDY'; SET LOCAL extra_float_digits TO 3; SET LOCAL standard_conforming_strings TO on",
  );
  const result = await db.query(`
    WITH app AS (
      SELECT c.oid,c.relname,c.relkind FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
      WHERE n.nspname='public' AND c.relkind IN ('r','p','S') AND NOT EXISTS (
        SELECT 1 FROM pg_depend d WHERE d.classid='pg_class'::regclass AND d.objid=c.oid AND d.deptype='e')
    ), objects AS (
      SELECT 'relation' AS kind, relname::text AS key, relkind::text AS definition FROM app
      UNION ALL
      SELECT 'column',a.relname||'.'||c.attname,
        format_type(c.atttypid,c.atttypmod)||'|'||c.attnotnull||'|'||coalesce(pg_get_expr(d.adbin,d.adrelid),'')
        FROM app a JOIN pg_attribute c ON c.attrelid=a.oid AND c.attnum>0 AND NOT c.attisdropped
        LEFT JOIN pg_attrdef d ON d.adrelid=a.oid AND d.adnum=c.attnum WHERE a.relkind IN ('r','p')
      UNION ALL
      SELECT 'constraint',a.relname||'.'||c.conname,c.convalidated||'|'||pg_get_constraintdef(c.oid)
        FROM app a JOIN pg_constraint c ON c.conrelid=a.oid
      UNION ALL
      SELECT 'index',i.relname,jsonb_build_object(
          'valid',x.indisvalid,'ready',x.indisready,'unique',x.indisunique,
          'nullsNotDistinct',x.indnullsnotdistinct,'keyCount',x.indnkeyatts,
          'method',am.amname,'options',x.indoption::text,
          'columns',(SELECT jsonb_agg(pg_get_indexdef(i.oid,k,false) ORDER BY k) FROM generate_series(1,x.indnatts) k),
          'opclasses',(SELECT jsonb_agg(n.nspname||'.'||o.opcname ORDER BY u.ord) FROM unnest(x.indclass) WITH ORDINALITY u(id,ord) JOIN pg_opclass o ON o.oid=u.id JOIN pg_namespace n ON n.oid=o.opcnamespace),
          'collations',(SELECT jsonb_agg(coalesce(n.nspname||'.'||c.collname,'none') ORDER BY u.ord) FROM unnest(x.indcollation) WITH ORDINALITY u(id,ord) LEFT JOIN pg_collation c ON c.oid=u.id LEFT JOIN pg_namespace n ON n.oid=c.collnamespace),
          'predicate',pg_get_expr(x.indpred,x.indrelid))::text
        FROM app a JOIN pg_index x ON x.indrelid=a.oid JOIN pg_class i ON i.oid=x.indexrelid JOIN pg_am am ON am.oid=i.relam
      UNION ALL
      SELECT 'trigger',a.relname||'.'||t.tgname,(CASE WHEN t.tgenabled='A' THEN 'O' ELSE t.tgenabled::text END)||'|'||pg_get_triggerdef(t.oid)
        FROM app a JOIN pg_trigger t ON t.tgrelid=a.oid WHERE NOT t.tgisinternal
      UNION ALL
      SELECT 'function',p.proname||'('||pg_get_function_identity_arguments(p.oid)||')',pg_get_functiondef(p.oid)
        FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
        WHERE n.nspname='public' AND p.prokind='f' AND NOT EXISTS (
          SELECT 1 FROM pg_depend d WHERE d.classid='pg_proc'::regclass AND d.objid=p.oid AND d.deptype='e')
      UNION ALL
      SELECT 'extension',e.extname,n.nspname FROM pg_extension e JOIN pg_namespace n ON n.oid=e.extnamespace
        WHERE e.extname IN ('postgis','pgcrypto')
    ) SELECT kind,key,definition FROM objects ORDER BY kind,key`);
  return result.rows.map((o: SchemaObject) => ({
    ...o,
    definition:
      o.kind === "function"
        ? o.definition.replace(/\r\n/g, "\n")
        : o.definition,
  }));
}

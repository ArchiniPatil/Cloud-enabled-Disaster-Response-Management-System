// Maintenance only: generate from a NEW disposable local database, never an
// existing application schema. Does not provision or connect to AWS.
import pg from "pg";
import { readdir, readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { inspectSchema } from "./schema-inspection.js";
let url: URL;
try {
  url = new URL(process.env.TEST_DATABASE_URL ?? "");
} catch {
  throw new Error("A valid disposable local TEST_DATABASE_URL is required");
}
if (
  !["postgres:", "postgresql:"].includes(url.protocol) ||
  !["localhost", "127.0.0.1"].includes(url.hostname) ||
  !url.pathname.endsWith("_test")
)
  throw new Error(
    "A disposable local TEST_DATABASE_URL ending in _test is required",
  );
const db = new pg.Client({
  connectionString: url.toString(),
  connectionTimeoutMillis: 5000,
  statement_timeout: 15000,
});
let connected = false;
try {
  await db.connect();
  connected = true;
  if (
    (
      await db.query(
        "SELECT 1 FROM pg_tables WHERE schemaname='public' AND tablename<>'spatial_ref_sys'",
      )
    ).rowCount
  )
    throw new Error("Refusing to generate from a nonempty database");
  await db.query("BEGIN");
  await db.query(
    "CREATE TABLE schema_migrations(name text PRIMARY KEY,applied_at timestamptz NOT NULL DEFAULT now())",
  );
  const migrations: Record<string, string> = {};
  for (const name of (await readdir("db/migrations"))
    .filter((n) => n.endsWith(".sql"))
    .sort()) {
    const sql = (await readFile(`db/migrations/${name}`, "utf8")).replace(
      /\r\n/g,
      "\n",
    );
    migrations[name] = createHash("sha256").update(sql).digest("hex");
    await db.query(sql);
    await db.query("INSERT INTO schema_migrations(name) VALUES($1)", [name]);
  }
  const objects = await inspectSchema(db);
  await db.query("COMMIT");
  await writeFile(
    "db/schema-contract.json",
    JSON.stringify({ migrations, objects }, null, 2) + "\n",
  );
  console.log(
    `Schema contract generated: ${objects.length} objects, ${Object.keys(migrations).length} migrations`,
  );
} catch {
  if (connected) await db.query("ROLLBACK").catch(() => undefined);
  throw new Error(
    "Schema contract generation failed; use a fresh isolated test database",
  );
} finally {
  await db.end();
}

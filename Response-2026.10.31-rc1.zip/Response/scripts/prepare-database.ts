import pg from "pg";
import {
  secretArn,
  strongSecret,
  validateDatabaseSecret,
} from "../apps/api/src/config-validation.js";
import {
  GetSecretValueCommand,
  SecretsManagerClient,
} from "@aws-sdk/client-secrets-manager";
import { migrate } from "./migrations.js";
import { transaction } from "../apps/api/src/db.js";
import { config } from "../apps/api/src/config.js";
export async function prepareDatabase() {
  const arn = process.env.APP_DB_SECRET_ARN;
  if (
    !arn ||
    (config.NODE_ENV === "production" &&
      (!secretArn(arn, config.AWS_REGION) ||
        arn === config.DATABASE_SECRET_ARN))
  )
    throw new Error("A distinct valid APP_DB_SECRET_ARN is required");
  let credentials: { username: string; password: string };
  try {
    const result = await new SecretsManagerClient({
      region: config.AWS_REGION,
      maxAttempts: 2,
    }).send(new GetSecretValueCommand({ SecretId: arn }), {
      abortSignal: AbortSignal.timeout(5000),
    });
    const parsed: unknown = JSON.parse(result.SecretString!);
    const checked =
      config.NODE_ENV === "production"
        ? validateDatabaseSecret(parsed)
        : (parsed as { username: string; password: string });
    if (
      checked?.username !== "response_app" ||
      typeof checked.password !== "string" ||
      !strongSecret(checked.password, 16)
    )
      throw new Error("Unexpected runtime credentials");
    credentials = checked;
  } catch {
    throw new Error("Runtime database secret could not be loaded or validated");
  }
  // Validate secret metadata before schema writes or role/password changes.
  await migrate();
  await transaction(async (db) => {
    await db.query(
      "SELECT pg_advisory_xact_lock(hashtext('response:runtime-role'))",
    );
    if (
      !(await db.query("SELECT 1 FROM pg_roles WHERE rolname='response_app'"))
        .rowCount
    )
      await db.query(
        "CREATE ROLE response_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT",
      );
    await db.query(
      `ALTER ROLE response_app PASSWORD ${pg.escapeLiteral(credentials.password)}`,
    );
    await db.query(
      "REVOKE CREATE ON SCHEMA public FROM PUBLIC; GRANT USAGE ON SCHEMA public TO response_app; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO response_app; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO response_app; REVOKE UPDATE,DELETE,TRUNCATE ON audit_events,incident_status_history,announcement_revisions,incident_updates FROM response_app; REVOKE INSERT,UPDATE,DELETE,TRUNCATE ON schema_migrations FROM response_app",
    );
  });
}

import { readdir, readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import {
  assertSchemaReady,
  validateLedger,
  requiredMigrations,
  migrationHashes,
} from "../apps/api/src/schema-readiness.js";
import { transaction } from "../apps/api/src/db.js";
export async function migrate() {
  const names = (await readdir("db/migrations"))
    .filter((n) => n.endsWith(".sql"))
    .sort();
  if (JSON.stringify(names) !== JSON.stringify(requiredMigrations))
    throw new Error("Migration assets do not match this application version");
  const sql = new Map<string, string>();
  for (const name of names) {
    const text = await readFile(`db/migrations/${name}`, "utf8");
    // Normalize checkout line endings only; preserve all other SQL bytes.
    const normalized = text.replace(/\r\n/g, "\n");
    if (
      createHash("sha256").update(normalized).digest("hex") !==
      migrationHashes[name]
    )
      throw new Error(
        "Migration asset checksum does not match this application version",
      );
    sql.set(name, normalized);
  }
  const applied: string[] = [];
  await transaction(async (db) => {
    await db.query(
      "SELECT pg_advisory_xact_lock(hashtext('response:migrations'))",
    );
    await db.query(
      "CREATE TABLE IF NOT EXISTS schema_migrations(name text PRIMARY KEY,applied_at timestamptz NOT NULL DEFAULT now())",
    );
    validateLedger(
      (
        await db.query(
          "SELECT name,applied_at FROM public.schema_migrations ORDER BY name",
        )
      ).rows,
      true,
    );
    for (const name of names) {
      if (
        !(
          await db.query("SELECT 1 FROM schema_migrations WHERE name=$1", [
            name,
          ])
        ).rowCount
      ) {
        await db.query(sql.get(name)!);
        await db.query("INSERT INTO schema_migrations(name) VALUES($1)", [
          name,
        ]);
        applied.push(name);
      }
    }
    await assertSchemaReady(db);
  });
  for (const name of applied)
    console.log(JSON.stringify({ event: "migration_applied", name }));
}

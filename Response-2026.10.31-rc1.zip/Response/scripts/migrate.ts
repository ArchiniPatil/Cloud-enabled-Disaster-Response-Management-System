import { migrate } from "./migrations.js";
import { pool } from "../apps/api/src/db.js";
try {
  await migrate();
} catch {
  console.error(JSON.stringify({ event: "database_migration_failed" }));
  process.exitCode = 1;
} finally {
  await pool.end();
}

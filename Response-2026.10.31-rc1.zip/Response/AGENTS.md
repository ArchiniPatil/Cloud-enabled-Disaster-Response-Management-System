# Project working rules

- This public source release carries no deployment authorization. Do not provision AWS resources or change IAM without separate user approval of an account-specific plan. Keep the default local target and disabled deployment gates; budget alerts are not spending caps.
- Credentials stay in approved environment/CLI configuration, never in code, logs, chat or Git. Existing credentials on a user's laptop may not be available in this cloud workspace.
- Use this existing checkout. Each cloud task is already isolated; do not create a worktree unless the user explicitly requests it.
- Normal local setup/startup uses real Cognito accounts: `npm run setup:local` and `npm run dev:local`. Sample accounts require explicit `setup:demo` / `dev:demo` commands and .env.demo. Use `npm test` only against a database name ending in `_test`; it resets that test schema. Browser tests create labeled fixtures in the local demo database.
- Preserve authorization, CSRF, transaction locks, idempotency, append-only audit records, location privacy, TLS validation and notification-state distinctions. A request is not acceptance, dispatch or arrival.
- Keep production Cognito/AWS integrations distinct from local demo identities and stubbed adapter tests. No live AWS acceptance result may be claimed without execution.
- Update `docs/IMPLEMENTATION_STATUS.md` and `docs/TESTING.md` when changing capabilities or validation outcomes.

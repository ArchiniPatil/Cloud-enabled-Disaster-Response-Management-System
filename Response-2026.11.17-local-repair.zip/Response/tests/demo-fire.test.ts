import { beforeAll, beforeEach, afterAll, expect, it } from "vitest";
import request from "supertest";
import { randomUUID } from "node:crypto";
import { execFileSync } from "node:child_process";
import { app } from "../apps/api/src/app";
import { config } from "../apps/api/src/config";
import { pool } from "../apps/api/src/db";
import { migrate } from "../scripts/migrations";
import { runEscalations } from "../apps/api/src/jobs";
const origin = "http://localhost:5173";
function seed() {
  execFileSync(process.execPath, ["--import", "tsx", "scripts/seed.ts"], {
    env: process.env,
    stdio: "pipe",
  });
}
async function login(name: string) {
  const agent = request.agent(app);
  await agent
    .post("/api/v1/auth/demo")
    .set("Origin", origin)
    .send({ email: `${name}@demo.invalid` })
    .expect(200);
  const { body } = await agent.get("/api/v1/auth/me").expect(200);
  return { agent, csrf: body.csrf, user: body.user };
}
type Client = Awaited<ReturnType<typeof login>>;
function post(c: Client, path: string, body: object) {
  return c.agent
    .post(`/api/v1${path}`)
    .set("Origin", origin)
    .set("X-CSRF-Token", c.csrf)
    .set("Idempotency-Key", randomUUID())
    .send(body);
}
async function report(c: Client, category = "FIRE", latitude = 19.076) {
  return (
    await post(c, "/incidents", {
      category,
      severity: "HIGH",
      kind: "EMERGENCY",
      latitude,
      longitude: 72.8777,
      description: "Fictional local acceptance exercise",
    }).expect(201)
  ).body.id as string;
}
async function team(c: Client) {
  return (await c.agent.get("/api/v1/teams").expect(200)).body.items[0];
}
async function locate(c: Client, id: string) {
  await post(c, `/teams/${id}/duty`, { availability: "AVAILABLE" }).expect(200);
  const s = (await post(c, "/locations/sessions", { teamId: id }).expect(201))
    .body;
  await post(c, "/locations/updates", {
    sessionId: s.id,
    latitude: 19.077,
    longitude: 72.878,
    accuracy: 10,
    observedAt: new Date().toISOString(),
  }).expect(202);
}
beforeAll(async () => {
  if (!new URL(process.env.DATABASE_URL!).pathname.endsWith("_test"))
    throw Error("Dedicated test database required");
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public");
  await migrate();
});
beforeEach(async () => {
  // Keep PostGIS extension OIDs stable within a pooled backend. Reset only
  // this guarded test database's rows, never the application's database.
  await pool.query(
    "TRUNCATE departments,jurisdictions,organizations,categories,escalation_policies,user_profiles RESTART IDENTITY CASCADE",
  );
  seed();
});
afterAll(async () => {
  await pool.end();
});
it("Fire incident stays visible to Fire Authority with no eligible responder and stays hidden from Medical", async () => {
  const citizen = await login("citizen"),
    fire = await login("fire-authority"),
    medical = await login("authority");
  const id = await report(citizen);
  await runEscalations();
  const detail = (await fire.agent.get(`/api/v1/incidents/${id}`).expect(200))
    .body;
  expect(detail.escalation_state).toBe("NO_ELIGIBLE_TEAM");
  expect(
    (await fire.agent.get("/api/v1/incidents?view=all")).body.items.map(
      (i: any) => i.id,
    ),
  ).toContain(id);
  expect(
    (await medical.agent.get("/api/v1/incidents?view=all")).body.total,
  ).toBe(0);
  await medical.agent.get(`/api/v1/incidents/${id}`).expect(404);
  expect(
    (await fire.agent.get("/api/v1/notifications")).body.items.some(
      (n: any) => n.incident_id === id,
    ),
  ).toBe(true);
  expect(
    (await medical.agent.get("/api/v1/notifications")).body.items.some(
      (n: any) => n.incident_id === id,
    ),
  ).toBe(false);
});
it("Medical stays visible to Medical Authority and hidden from Fire Authority", async () => {
  const id = await report(await login("citizen"), "MEDICAL"),
    medical = await login("authority"),
    fire = await login("fire-authority");
  await medical.agent.get(`/api/v1/incidents/${id}`).expect(200);
  await fire.agent.get(`/api/v1/incidents/${id}`).expect(404);
  expect((await fire.agent.get("/api/v1/incidents")).body.total).toBe(0);
});
it.each([
  ["authority", "MEDICAL"],
  ["fire-authority", "FIRE"],
])("%s cannot access outside-jurisdiction reports", async (name, category) => {
  const id = await report(await login("citizen"), category, 28.6),
    authority = await login(name);
  await authority.agent.get(`/api/v1/incidents/${id}`).expect(404);
  expect(
    (await authority.agent.get("/api/v1/incidents?view=all")).body.total,
  ).toBe(0);
});
it("seed is repeatable and does not create GPS, reset duty, change existing scope or duplicate accounts/teams", async () => {
  const fire = await login("fire-rescuer"),
    t = await team(fire);
  expect(t.department).toBe("Fire and Rescue");
  expect(t.capabilities).toContain("FIRE");
  expect(t.availability).toBe("OFF_DUTY");
  expect(
    (await pool.query("SELECT count(*)::int n FROM location_sessions")).rows[0]
      .n,
  ).toBe(0);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM rescue_teams WHERE location IS NOT NULL",
      )
    ).rows[0].n,
  ).toBe(0);
  const medical = await login("authority");
  const customJurisdiction = (
    await pool.query(
      "INSERT INTO jurisdictions(name,boundary) SELECT 'Preserved custom exercise scope',boundary FROM jurisdictions WHERE id=$1 RETURNING id",
      [medical.user.jurisdiction_id],
    )
  ).rows[0].id;
  await pool.query("UPDATE user_profiles SET jurisdiction_id=$2 WHERE id=$1", [
    medical.user.id,
    customJurisdiction,
  ]);
  await pool.query(
    "UPDATE user_profiles SET name='Preserved local configuration' WHERE id=$1",
    [medical.user.id],
  );
  await post(fire, `/teams/${t.id}/duty`, { availability: "AVAILABLE" }).expect(
    200,
  );
  seed();
  expect((await team(fire)).id).toBe(t.id);
  expect((await team(fire)).availability).toBe("AVAILABLE");
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM user_profiles WHERE cognito_sub LIKE 'demo:%'",
      )
    ).rows[0].n,
  ).toBe(6);
  expect(
    (await pool.query("SELECT count(*)::int n FROM rescue_teams")).rows[0].n,
  ).toBe(2);
  expect(
    (
      await pool.query("SELECT name FROM user_profiles WHERE id=$1", [
        medical.user.id,
      ])
    ).rows[0].name,
  ).toBe("Preserved local configuration");
  expect(
    (
      await pool.query(
        "SELECT jurisdiction_id FROM user_profiles WHERE id=$1",
        [medical.user.id],
      )
    ).rows[0].jurisdiction_id,
  ).toBe(customJurisdiction);
});
it("Fire eligibility requires duty, explicit sharing, fresh accurate GPS, capability and spare capacity", async () => {
  const id = await report(await login("citizen")),
    a = await login("fire-authority"),
    r = await login("fire-rescuer"),
    t = await team(r);
  const eligible = async () =>
    (await a.agent.get(`/api/v1/incidents/${id}/eligible-teams`).expect(200))
      .body.items;
  const medicalRescuer = await login("rescuer");
  await locate(medicalRescuer, (await team(medicalRescuer)).id);
  expect(await eligible()).toHaveLength(0);
  await post(r, `/teams/${t.id}/duty`, { availability: "AVAILABLE" }).expect(
    200,
  );
  expect(await eligible()).toHaveLength(0);
  await locate(r, t.id);
  expect((await eligible()).map((x: any) => x.id)).toContain(t.id);
  await pool.query(
    "UPDATE rescue_teams SET location_at=now()-interval '2 minutes' WHERE id=$1",
    [t.id],
  );
  expect(await eligible()).toHaveLength(0);
  await pool.query(
    "UPDATE rescue_teams SET location_at=now(),accuracy=250 WHERE id=$1",
    [t.id],
  );
  expect(await eligible()).toHaveLength(0);
  await pool.query("UPDATE rescue_teams SET accuracy=10 WHERE id=$1", [t.id]);
  await pool.query(
    "UPDATE team_capabilities SET expires_at=now()-interval '1 second' WHERE team_id=$1",
    [t.id],
  );
  expect(await eligible()).toHaveLength(0);
  await pool.query(
    "UPDATE team_capabilities SET expires_at=NULL WHERE team_id=$1",
    [t.id],
  );
  await post(a, `/incidents/${id}/status`, { status: "ACKNOWLEDGED" }).expect(
    200,
  );
  await post(a, "/assignments", { incidentId: id, teamId: t.id }).expect(201);
  const second = await report(await login("citizen"));
  expect(
    (await a.agent.get(`/api/v1/incidents/${second}/eligible-teams`)).body
      .items,
  ).toHaveLength(0);
  await a.agent.get(`/api/v1/incidents/${second}`).expect(200);
});
it("Fire lifecycle completes with scoped history, notifications and audit; wrong department actions are rejected", async () => {
  const c = await login("citizen"),
    a = await login("fire-authority"),
    r = await login("fire-rescuer"),
    m = await login("authority"),
    mr = await login("rescuer"),
    admin = await login("admin");
  const id = await report(c),
    t = await team(r);
  await locate(r, t.id);
  await post(m, `/incidents/${id}/status`, { status: "ACKNOWLEDGED" }).expect(
    404,
  );
  await post(a, `/incidents/${id}/status`, { status: "ACKNOWLEDGED" }).expect(
    200,
  );
  await post(m, "/assignments", { incidentId: id, teamId: t.id }).expect(404);
  const offer = (
    await post(a, "/assignments", { incidentId: id, teamId: t.id }).expect(201)
  ).body;
  await post(mr, `/assignments/${offer.id}/status`, {
    status: "ACCEPTED",
  }).expect(404);
  for (const status of [
    "ACCEPTED",
    "DISPATCHED",
    "EN_ROUTE",
    "ARRIVED",
    "IN_PROGRESS",
    "COMPLETED",
  ])
    await post(
      status === "DISPATCHED" ? a : r,
      `/assignments/${offer.id}/status`,
      {
        status,
        note:
          status === "COMPLETED"
            ? "Fictional exercise completed; no outstanding needs"
            : "",
      },
    ).expect(200);
  expect((await c.agent.get(`/api/v1/incidents/${id}`)).body.status).toBe(
    "RESOLVED",
  );
  expect(
    (
      await pool.query(
        "SELECT to_status FROM incident_status_history WHERE incident_id=$1",
        [id],
      )
    ).rows.map((x) => x.to_status),
  ).toContain("RESOLVED");
  expect(
    (await admin.agent.get("/api/v1/admin/audit")).body.items.some(
      (x: any) => x.entity_id === id,
    ),
  ).toBe(true);
});
it.each(["fire-authority", "fire-rescuer"])(
  "%s fixture remains behind transport and Cognito-mode guards",
  async (name) => {
    const a = await login(name);
    await request(app)
      .post("/api/v1/auth/demo")
      .set("Host", "public.invalid")
      .set("Origin", origin)
      .send({ email: `${name}@demo.invalid` })
      .expect(403);
    await a.agent
      .get("/api/v1/incidents")
      .set("X-Forwarded-For", "127.0.0.1")
      .expect(403);
    const previous = config.AUTH_MODE;
    try {
      config.AUTH_MODE = "cognito";
      await a.agent.get("/api/v1/incidents").expect(401);
      await request(app)
        .post("/api/v1/auth/demo")
        .set("Origin", origin)
        .send({ email: `${name}@demo.invalid` })
        .expect(404);
    } finally {
      config.AUTH_MODE = previous;
    }
  },
);

it("adds Fire fixtures to a representative existing Medical demo without changing its records", async () => {
  const citizen = await login("citizen"),
    medical = await login("authority"),
    rescuer = await login("rescuer");
  const id = await report(citizen, "MEDICAL"),
    t = await team(rescuer);
  await locate(rescuer, t.id);
  // Remove only unused Fire fixtures in this suffix-guarded disposable test DB,
  // recreating the four-account RC1 seed state without editing historical SQL.
  await pool.query(
    "DELETE FROM team_capabilities WHERE team_id IN(SELECT id FROM rescue_teams WHERE name='Fire 01 — Demo'); DELETE FROM team_memberships WHERE team_id IN(SELECT id FROM rescue_teams WHERE name='Fire 01 — Demo'); DELETE FROM rescue_teams WHERE name='Fire 01 — Demo'; DELETE FROM user_permissions WHERE user_id IN(SELECT id FROM user_profiles WHERE cognito_sub IN('demo:fire-authority','demo:fire-rescuer')); DELETE FROM user_profiles WHERE cognito_sub IN('demo:fire-authority','demo:fire-rescuer'); DELETE FROM jurisdictions WHERE name='Fictional fire exercise area (Mumbai coordinates)'",
  );
  const before = (await pool.query("SELECT * FROM incidents WHERE id=$1", [id]))
    .rows[0];
  const beforeTeam = (
    await pool.query("SELECT * FROM rescue_teams WHERE id=$1", [t.id])
  ).rows[0];
  seed();
  seed();
  expect(
    (await pool.query("SELECT * FROM incidents WHERE id=$1", [id])).rows[0],
  ).toEqual(before);
  expect(
    (await pool.query("SELECT * FROM rescue_teams WHERE id=$1", [t.id]))
      .rows[0],
  ).toEqual(beforeTeam);
  await medical.agent.get(`/api/v1/incidents/${id}`).expect(200);
  const fire = await login("fire-authority");
  await fire.agent.get(`/api/v1/incidents/${id}`).expect(404);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM user_profiles WHERE cognito_sub LIKE 'demo:%'",
      )
    ).rows[0].n,
  ).toBe(6);
});

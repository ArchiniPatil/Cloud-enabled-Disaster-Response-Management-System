import { beforeAll, beforeEach, afterAll, expect, it } from "vitest";
import request from "supertest";
import { randomUUID } from "node:crypto";
import { execFileSync } from "node:child_process";
import { app } from "../apps/api/src/app";
import { config } from "../apps/api/src/config";
import { pool, transaction } from "../apps/api/src/db";
import { migrate } from "../scripts/migrations";
import {
  addLocalDemoFixtures,
  assertLocalDemoRepair,
} from "../scripts/local-demo-fixtures";
const origin = "http://localhost:5173";
const points = {
  FIRE: [18.56, 73.94],
  MEDICAL: [18.48, 73.87],
};
async function login(alias: string) {
  const agent = request.agent(app);
  await agent
    .post("/api/v1/auth/demo")
    .set("Origin", origin)
    .send({ email: `${alias}@demo.invalid` })
    .expect(200);
  const { body } = await agent.get("/api/v1/auth/me").expect(200);
  return { agent, csrf: body.csrf, user: body.user };
}
type Client = Awaited<ReturnType<typeof login>>;
function post(c: Client, path: string, body: object) {
  return c.agent
    .post(`/api/v1${path}`)
    .set("Origin", origin)
    .set("X-CSRF-Token", c.csrf)
    .set("Idempotency-Key", randomUUID())
    .send(body);
}
async function report(
  c: Client,
  category: keyof typeof points,
  latitude = points[category][0],
  longitude = points[category][1],
) {
  return (
    await post(c, "/incidents", {
      category,
      severity: "HIGH",
      kind: "EMERGENCY",
      latitude,
      longitude,
      description: "Controlled fictional exercise",
    }).expect(201)
  ).body.id as string;
}
const repair = () => transaction(addLocalDemoFixtures);
beforeAll(async () => {
  if (!new URL(process.env.DATABASE_URL!).pathname.endsWith("_test"))
    throw Error("Dedicated test database required");
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public");
  await migrate();
});
beforeEach(async () => {
  await pool.query(
    "TRUNCATE departments,jurisdictions,organizations,categories,escalation_policies,user_profiles RESTART IDENTITY CASCADE",
  );
  execFileSync(process.execPath, ["--import", "tsx", "scripts/seed.ts"], {
    env: process.env,
    stdio: "pipe",
  });
});
afterAll(async () => {
  await pool.end();
});
it("reproduces the reported exclusions then adds scoped access without moving reports or changing existing Mumbai identities", async () => {
  const c = await login("citizen"),
    m = await login("authority");
  const fire = await report(c, "FIRE"),
    medical = await report(c, "MEDICAL");
  await m.agent.get(`/api/v1/incidents/${fire}`).expect(404);
  await m.agent.get(`/api/v1/incidents/${medical}`).expect(404);
  await request(app)
    .post("/api/v1/auth/demo")
    .set("Origin", origin)
    .send({ email: "pune-medical-authority@demo.invalid" })
    .expect(503);
  const before = (await pool.query("SELECT * FROM incidents ORDER BY id")).rows;
  const profiles = (await pool.query("SELECT * FROM user_profiles ORDER BY id"))
    .rows;
  const teams = (await pool.query("SELECT * FROM rescue_teams ORDER BY id"))
    .rows;
  const history = (
    await pool.query("SELECT * FROM incident_status_history ORDER BY id")
  ).rows;
  await repair();
  const pa = await login("pune-medical-authority"),
    fa = await login("pune-fire-authority");
  expect(
    (
      await pa.agent.get("/api/v1/incidents?view=all").expect(200)
    ).body.items.map((i: any) => i.id),
  ).toEqual([medical]);
  expect(
    (
      await fa.agent.get("/api/v1/incidents?view=all").expect(200)
    ).body.items.map((i: any) => i.id),
  ).toEqual([fire]);
  expect(
    (await pa.agent.get("/api/v1/incidents/summary").expect(200)).body.total,
  ).toBe(1);
  await pa.agent.get(`/api/v1/incidents/${fire}`).expect(404);
  await fa.agent.get(`/api/v1/incidents/${medical}`).expect(404);
  await m.agent.get(`/api/v1/incidents/${medical}`).expect(404);
  const outside = await report(c, "MEDICAL", 18.7, 73.9);
  await pa.agent.get(`/api/v1/incidents/${outside}`).expect(404);
  const mumbai = await report(c, "MEDICAL", 19.076, 72.8777);
  await pa.agent.get(`/api/v1/incidents/${mumbai}`).expect(404);
  await m.agent.get(`/api/v1/incidents/${mumbai}`).expect(200);
  expect(
    (
      await pool.query(
        "SELECT * FROM incidents WHERE id=ANY($1::uuid[]) ORDER BY id",
        [[fire, medical]],
      )
    ).rows,
  ).toEqual(before);
  expect(
    (
      await pool.query(
        "SELECT * FROM user_profiles WHERE id=ANY($1::uuid[]) ORDER BY id",
        [profiles.map((u) => u.id)],
      )
    ).rows,
  ).toEqual(profiles);
  expect(
    (
      await pool.query(
        "SELECT * FROM rescue_teams WHERE id=ANY($1::uuid[]) ORDER BY id",
        [teams.map((t) => t.id)],
      )
    ).rows,
  ).toEqual(teams);
  expect(
    (
      await pool.query(
        "SELECT * FROM incident_status_history WHERE incident_id=ANY($1::uuid[]) ORDER BY id",
        [[fire, medical]],
      )
    ).rows,
  ).toEqual(history);
});
it.each(["MEDICAL", "FIRE"] as const)(
  "%s stays unassigned until consent, fresh GPS and a scoped offer; the complete lifecycle works",
  async (category) => {
    const c = await login("citizen"),
      id = await report(c, category);
    await repair();
    const alias = category === "MEDICAL" ? "pune-medical" : "pune-fire";
    const a = await login(`${alias}-authority`),
      r = await login(`${alias}-rescuer`);
    const t = (await r.agent.get("/api/v1/teams").expect(200)).body.items[0];
    expect(t.availability).toBe("OFF_DUTY");
    expect(
      (await r.agent.get("/api/v1/incidents").expect(200)).body.total,
    ).toBe(0);
    await r.agent.get(`/api/v1/incidents/${id}`).expect(404);
    await post(r, `/teams/${t.id}/duty`, { availability: "AVAILABLE" }).expect(
      200,
    );
    expect(
      (await a.agent.get(`/api/v1/incidents/${id}/eligible-teams`).expect(200))
        .body.items,
    ).toHaveLength(0);
    const session = (
      await post(r, "/locations/sessions", { teamId: t.id }).expect(201)
    ).body.id;
    const [latitude, longitude] = points[category];
    await post(r, "/locations/updates", {
      sessionId: session,
      latitude,
      longitude,
      accuracy: 10,
      observedAt: new Date().toISOString(),
    }).expect(202);
    expect(
      (
        await a.agent.get(`/api/v1/incidents/${id}/eligible-teams`).expect(200)
      ).body.items.map((t: any) => t.id),
    ).toContain(t.id);
    expect(
      (await r.agent.get("/api/v1/incidents").expect(200)).body.total,
    ).toBe(0);
    await post(a, `/incidents/${id}/status`, { status: "ACKNOWLEDGED" }).expect(
      200,
    );
    const offer = (
      await post(a, "/assignments", { incidentId: id, teamId: t.id }).expect(
        201,
      )
    ).body;
    expect(
      (await r.agent.get("/api/v1/incidents").expect(200)).body.items.map(
        (i: any) => i.id,
      ),
    ).toEqual([id]);
    expect(
      (await r.agent.get("/api/v1/incidents/summary").expect(200)).body.total,
    ).toBe(1);
    const other = await login(
      category === "MEDICAL" ? "pune-fire-rescuer" : "pune-medical-rescuer",
    );
    await post(other, `/assignments/${offer.id}/status`, {
      status: "ACCEPTED",
    }).expect(404);
    for (const status of [
      "ACCEPTED",
      "DISPATCHED",
      "EN_ROUTE",
      "ARRIVED",
      "IN_PROGRESS",
      "COMPLETED",
    ])
      await post(
        status === "DISPATCHED" ? a : r,
        `/assignments/${offer.id}/status`,
        { status, note: "Controlled exercise completed" },
      ).expect(200);
    expect(
      (await c.agent.get(`/api/v1/incidents/${id}`).expect(200)).body.status,
    ).toBe("RESOLVED");
  },
);
it("restores missing RC2 Fire fixtures to a representative four-account database and is repeatable without GPS fabrication", async () => {
  await pool.query(
    "DELETE FROM team_capabilities WHERE team_id IN(SELECT id FROM rescue_teams WHERE name='Fire 01 — Demo'); DELETE FROM team_memberships WHERE team_id IN(SELECT id FROM rescue_teams WHERE name='Fire 01 — Demo'); DELETE FROM rescue_teams WHERE name='Fire 01 — Demo'; DELETE FROM user_permissions WHERE user_id IN(SELECT id FROM user_profiles WHERE cognito_sub IN('demo:fire-authority','demo:fire-rescuer')); DELETE FROM user_profiles WHERE cognito_sub IN('demo:fire-authority','demo:fire-rescuer'); DELETE FROM jurisdictions WHERE name='Fictional fire exercise area (Mumbai coordinates)'",
  );
  await repair();
  await repair();
  await login("fire-authority");
  await login("fire-rescuer");
  expect(
    (await pool.query("SELECT count(*)::int n FROM user_profiles")).rows[0].n,
  ).toBe(10);
  expect(
    (await pool.query("SELECT count(*)::int n FROM rescue_teams")).rows[0].n,
  ).toBe(4);
  expect(
    (await pool.query("SELECT count(*)::int n FROM location_sessions")).rows[0]
      .n,
  ).toBe(0);
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM rescue_teams WHERE location IS NOT NULL OR availability<>'OFF_DUTY'",
      )
    ).rows[0].n,
  ).toBe(0);
});
it("rolls back all additions on a conflicting fixture identity instead of overwriting it", async () => {
  await pool.query(
    "INSERT INTO user_profiles(cognito_sub,email,name,role) VALUES('real-account-conflict','pune-fire-rescuer@demo.invalid','Protected existing account','CITIZEN')",
  );
  await expect(repair()).rejects.toThrow("customized scope/status");
  expect(
    (
      await pool.query(
        "SELECT count(*)::int n FROM jurisdictions WHERE name='Pune local exercise area (fictional)'",
      )
    ).rows[0].n,
  ).toBe(0);
  expect(
    (await pool.query("SELECT count(*)::int n FROM user_profiles")).rows[0].n,
  ).toBe(7);
});
it("refuses a customized boundary and never resets existing duty or qualifications", async () => {
  await repair();
  await pool.query(
    "UPDATE rescue_teams SET availability='AVAILABLE' WHERE name='Pune Medic 01 — Demo'",
  );
  await repair();
  expect(
    (
      await pool.query(
        "SELECT availability FROM rescue_teams WHERE name='Pune Medic 01 — Demo'",
      )
    ).rows[0].availability,
  ).toBe("AVAILABLE");
  await pool.query(
    "UPDATE jurisdictions SET boundary=ST_Multi(ST_MakeEnvelope(73.8,18.4,74,18.65,4326)) WHERE name='Pune local exercise area (fictional)'",
  );
  await expect(repair()).rejects.toThrow("boundary differs");
});
it.each([
  "pune-medical-authority",
  "pune-medical-rescuer",
  "pune-fire-authority",
  "pune-fire-rescuer",
])(
  "%s remains behind demo transport and Cognito-mode guards",
  async (alias) => {
    await repair();
    const c = await login(alias);
    await c.agent
      .get("/api/v1/incidents")
      .set("X-Forwarded-For", "127.0.0.1")
      .expect(403);
    await request(app)
      .post("/api/v1/auth/demo")
      .set("Host", "outside.invalid")
      .set("Origin", origin)
      .send({ email: `${alias}@demo.invalid` })
      .expect(403);
    const previous = config.AUTH_MODE;
    try {
      config.AUTH_MODE = "cognito";
      await c.agent.get("/api/v1/incidents").expect(401);
    } finally {
      config.AUTH_MODE = previous;
    }
  },
);
it.each([
  { NODE_ENV: "production" },
  { AUTH_MODE: "cognito" },
  { DATABASE_URL: "postgresql://example.invalid/app" },
  { DATABASE_URL: "postgresql://127.0.0.1/app?host=example.invalid" },
  { DATABASE_SECRET_ARN: "configured" },
  { SESSION_SECRET_ARN: "configured" },
])("refuses non-local or secret-backed repair configuration %#", (override) => {
  expect(() =>
    assertLocalDemoRepair({
      AUTH_MODE: "demo",
      NODE_ENV: "development",
      DATABASE_URL: process.env.DATABASE_URL,
      ...override,
    }),
  ).toThrow("explicit local demo");
});

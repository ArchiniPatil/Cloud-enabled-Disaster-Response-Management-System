import { test, expect, type BrowserContext } from "@playwright/test";
import { execFileSync } from "node:child_process";
test.beforeAll(() => {
  if (
    !process.env.DATABASE_URL ||
    !new URL(process.env.DATABASE_URL).pathname.endsWith("_test")
  )
    throw new Error("Dedicated browser test database required");
  execFileSync(
    process.execPath,
    ["--import", "tsx", "scripts/repair-demo.ts"],
    {
      env: {
        ...process.env,
        AUTH_MODE: "demo",
        NODE_ENV: "test",
        NOTIFICATION_TRANSPORT: "simulator",
      },
      stdio: "pipe",
    },
  );
});
async function login(context: BrowserContext, role: string) {
  const p = await context.newPage();
  await p.goto("/");
  await expect(
    p.getByRole("button", { name: /^Demo (Citizen|Authority|Rescuer|Admin)$/ }),
  ).toHaveCount(0);
  await p.getByRole("link", { name: /Open Development/ }).click();
  await expect(p.getByLabel("Demo role").locator("option")).toHaveCount(10);
  await p.getByLabel("Demo role").selectOption(role.toLowerCase());
  await p.getByRole("button", { name: "Continue with local account" }).click();
  await expect(
    p.getByRole("heading", {
      name: /My reports and assistance|Operations overview|Responder workspace|Administration overview/,
    }),
  ).toBeVisible();
  return p;
}
for (const scenario of [
  {
    alias: "pune-fire",
    category: "Fire",
    latitude: 18.56,
    longitude: 73.94,
    department: "Fire and Rescue",
  },
  {
    alias: "pune-medical",
    category: "Medical emergency",
    latitude: 18.48,
    longitude: 73.87,
    department: "Medical / Ambulance",
  },
])
  test(`Pune ${scenario.category} identities complete the scoped browser workflow`, async ({
    browser,
  }) => {
    const citizenContext = await browser.newContext(),
      authorityContext = await browser.newContext(),
      rescuerContext = await browser.newContext({
        geolocation: {
          latitude: scenario.latitude,
          longitude: scenario.longitude,
        },
        permissions: ["geolocation"],
      });
    const citizen = await login(citizenContext, "Citizen"),
      authority = await login(authorityContext, `${scenario.alias}-authority`),
      rescuer = await login(rescuerContext, `${scenario.alias}-rescuer`);
    await rescuer.getByRole("link", { name: "Teams & resources" }).click();
    // Wait for team data before the immediate visibility check below; otherwise
    // a fresh off-duty team can be skipped while its request is still loading.
    await expect(
      rescuer.getByRole("button", { name: /^(Start duty|End duty)$/ }),
    ).toBeVisible();
    const duty = rescuer.getByRole("button", {
      name: "Start duty",
      exact: true,
    });
    if (await duty.isVisible()) await duty.click();
    await rescuer
      .getByRole("button", { name: "Share device location" })
      .click();
    await expect(
      rescuer.getByText("Your device is sharing operational location."),
    ).toBeVisible();
    await citizen.getByRole("link", { name: /Need help/ }).click();
    await citizen
      .getByRole("button", { name: scenario.category, exact: true })
      .click();
    await citizen
      .getByLabel("Latitude", { exact: true })
      .fill(String(scenario.latitude));
    await citizen
      .getByLabel("Longitude", { exact: true })
      .fill(String(scenario.longitude));
    await citizen
      .getByLabel("Brief description")
      .fill("Browser automation: controlled demonstration");
    await citizen.getByRole("button", { name: "Submit request" }).click();
    await expect(
      citizen.getByText("Your request is saved.", { exact: false }),
    ).toBeVisible();
    const incidentPath = new URL(citizen.url()).pathname;
    await authority
      .getByRole("link", { name: "Incident inbox", exact: true })
      .click();
    await expect(
      authority
        .locator(".queue-item")
        .filter({ hasText: scenario.category })
        .first(),
    ).toBeVisible();
    await expect(authority.getByTestId("authority-scope")).toContainText(
      scenario.department,
    );
    await expect(authority.getByTestId("authority-scope")).toContainText(
      "Pune local exercise area",
    );
    const medicalContext = await browser.newContext();
    await login(medicalContext, "Authority");
    expect(
      (await medicalContext.request.get(`/api/v1${incidentPath}`)).status(),
    ).toBe(404);
    await medicalContext.close();
    await authority.goto(incidentPath);
    await authority
      .getByRole("button", { name: "Acknowledge", exact: true })
      .click();
    await authority
      .getByRole("button", { name: "Find eligible teams" })
      .click();
    const select = authority.getByRole("combobox", { name: "Eligible team" });
    const value = await select.locator("option").nth(1).getAttribute("value");
    await select.selectOption(value!);
    await authority.getByRole("button", { name: "Offer assignment" }).click();
    await expect(authority.getByText("Offered", { exact: true })).toBeVisible();
    const response = await rescuerContext.newPage();
    await response.goto(incidentPath);
    await response
      .getByRole("button", { name: "Accepted", exact: true })
      .click();
    await expect(
      authority.getByRole("button", { name: "Authorize dispatch" }),
    ).toBeVisible({ timeout: 10000 });
    await authority.getByRole("button", { name: "Authorize dispatch" }).click();
    await expect(
      response.getByRole("button", { name: "En Route", exact: true }),
    ).toBeVisible({ timeout: 10000 });
    await response
      .getByRole("button", { name: "En Route", exact: true })
      .click();
    await expect(citizen.getByText("Live", { exact: true })).toBeVisible({
      timeout: 10000,
    });
    await expect(citizen.getByText(/ETA unavailable/).first()).toBeVisible();
    for (const name of ["Arrived", "In Progress", "Completed"]) {
      await response.getByRole("button", { name, exact: true }).click();
      if (name === "Completed") {
        await response
          .getByLabel("Reason or outcome")
          .fill(
            "Controlled exercise: assistance completed, no outstanding needs",
          );
        await response
          .getByRole("button", { name: "Confirm Completed", exact: true })
          .click();
      }
    }
    await expect(
      citizen.locator(".page-head").getByText("Resolved", { exact: true }),
    ).toBeVisible({ timeout: 10000 });
    await citizen.screenshot({
      path: `test-results/${scenario.alias}-completed.png`,
      fullPage: true,
    });
    await citizen.getByRole("link", { name: /Profile & settings/ }).click();
    await citizen.getByRole("button", { name: "Log out" }).click();
    await expect(
      citizen.getByRole("heading", {
        name: /Disaster Response and Management System/,
      }),
    ).toBeVisible();
    await citizenContext.close();
    await authorityContext.close();
    await rescuerContext.close();
  });

# Final master review — 10 November 2026

## Baseline before implementation

The uploaded RC1 archive hashes to `e92f746266ccb3ce817aeb58e75c822fc04b7d3248b47458914c373872ee1507`. All 82 implementation/migration files match the preserved working tree over `eb9e622`. Public-copy documentation and deployment approval metadata intentionally differ. A complete source backup and diff were saved outside the project before changes. Historical migrations 001–008 and the dependency lockfile are preserved.

Existing source covers Citizen reports/history/updates/cancellation, scoped Authority dispatch, responder duty/consent/GPS/assignment progression, administrative configuration, resource/shelter allocation, append-only audit, persisted deadlines and durable outbox/retry. RC1 evidence records 272 full tests, 219 focused tests and 21 browser scenarios. Those counts are historical, not this release's final result.

Confirmed gap: the full category catalog includes Fire, but the demo provides only a Medical Authority/team with FIRST_AID. Matching Fire scope/capability is absent. This is a demo configuration/coverage gap; backend authorization is correct. The existing test deliberately denies Medical Authority access to Fire. Preserve that denial while adding a complete independent Fire exercise.

Reviewed the application routes/actions, authentication/session/proxy boundaries, role/scope SQL, worker/deadline/outbox logic, evidence validation, all eight SQL migrations, schema contract, local setup/seed/startup, Docker/Compose/CI, CDK identity/application definitions and deployment/publishing helpers. The AWS worker is Lambda plus Scheduler/SQS; the local worker is a long-running Node process. Compose supplies PostgreSQL only. No provider switch or new hosting architecture is required.

Incomplete/external gates: local fixture registration is intentionally not real registration; Cognito onboarding/MFA/session renewal, S3 file flow, Location maps/search/routes, messaging/email, RDS restore and deployed networking/IAM require live acceptance. Browser push, native background GPS, malicious-image scanning/EXIF stripping and distributed rate limiting are not implemented. SDK tests are stubs. The ECS-only delivery pipeline does not roll out migrations, worker or frontend; deployment must coordinate these separately.

Security baseline: loopback fixture access and cookie-reuse guard, Cognito isolation, production configuration/TLS/secret validation, CSRF and role/jurisdiction checks, parameterized SQL, transactions and immutable audit are present. Prior dependency report had two moderate CDK/minimatch findings. No new critical/high finding is asserted without evidence. Fresh dependency/security checks and all final results will be recorded below.

Deployment is not authorized by this task. Current AWS identity, effective permissions, SCP, region quotas and credits must not be inferred from historical reports. Existing explicit SCP denies require the organization's authorized policy administrator to inspect and amend the applicable policy if approved; adding IAM AdministratorAccess cannot override a deny. No deployment, IAM/SCP edit, cloud resource, production migration or pipeline trigger will run.

## Implementation and resolved defects

- `scripts/seed.ts`: adds Fire Authority (`fire-authority@demo.invalid`), Fire responder (`fire-rescuer@demo.invalid`), Fire 01 — Demo, FIRE capability and the explicitly fictional fire exercise jurisdiction. Existing Medical users/team/scope remain; the transactional advisory-lock seed is additive/idempotent and does not enable duty or manufacture GPS. No schema change/new migration is needed.
- `apps/api/src/auth.ts`: adds only the two fixed fixture emails to the allowlist. Backend loopback/session checks and Cognito isolation are unchanged.
- `apps/web/src/main.tsx`: exposes both departmental fixture choices with scope/coordinate guidance, retaining all old selector values and normal Cognito access.
- `apps/web/src/dashboard.tsx`: displays Authority department/jurisdiction from the authenticated profile and backend catalog, explaining that clearing filters preserves scope. No incident-access rule was broadened.
- `tests/demo-fire.test.ts`: ten cases for Fire and Medical visibility/isolation, no-team visibility, both jurisdiction denials, seed preservation/upgrade/repeatability, required eligibility conditions, transactional lifecycle/audit and Fire fixture-cookie isolation. Test GPS is explicitly supplied by the test client, never by the seed.
- `tests/browser/fire-workflow.spec.ts`: additional full Citizen/Fire Authority/Fire responder journey with inbox scope, negative Medical access, consent/duty/GPS simulation, assignment/acceptance/dispatch/en-route/arrival/completion and Citizen resolution/history. The existing Medical/browser/GPS cases are unchanged.
- Current-status, setup, security, testing, hosting and release documentation updated; `docs/AWS_DEPLOYMENT_PLAN.md` provides account-access blockers, ordered post-approval commands, costs and rollback.

No SQL migration, schema contract, dependency version/lockfile, provider, infrastructure/IAM definition or user database was reset/replaced. No authentication, scope, GPS, CSRF or audit assertion was weakened. Existing user work is retained. Other supplied categories remain available for reporting/admin configuration, but the canned end-to-end fixtures cover Medical and Fire only.

## Actual verification results — workspace

Linux x86_64, Node 24.19.0/npm 11.9.0, PostgreSQL 16/PostGIS 3.5, Chromium. Tests use separate review-owned `response_final_master_test`, `response_final_master_browser_test` and `response_final_container_test` databases, never the ordinary local `response` database. Environment examples contain only existing disposable local fixture values. Sensitive environment values and AWS credential contents were not logged.

| Check | Result | Exact command / context |
|---|---|---|
| New Fire/seed/authorization tests | PASS, 10/10, 11.46s | `node node_modules/vitest/vitest.mjs run tests/demo-fire.test.ts` |
| Focused security/config/readiness/workflow/Fire | PASS, 229/229, 7 files, 45.77s | `node node_modules/vitest/vitest.mjs run tests/demo-fire.test.ts tests/workflow.test.ts tests/readiness.test.ts tests/readiness-timeout.test.ts tests/configuration.test.ts tests/local-access.test.ts tests/local-access-metadata.test.ts` |
| Full suite | PASS, 282/282, 9 files, 49.91s, no skips | `npm test` with TEST_DATABASE_URL selecting the dedicated test DB |
| Browser/frontend acceptance | PASS, 22/22, 3.4m | `npm run test:e2e` with DATABASE_URL selecting the separate browser DB and CI=1 |
| TypeScript | PASS, exit 0 | `npm run typecheck` |
| Lint | PASS, exit 0 | `npm run lint` |
| Frontend/API/worker/migrator production bundles | PASS, exit 0 | `npm run build` (includes TypeScript, Vite frontend, tsup API/server/worker/Lambda and scripts) |
| Migration clean/upgrade/repeat and restricted runtime DB role | PASS, included in full suite | `npm test`; readiness tests cover pre-008 data/backfill, eight-migration contract and invalid/missing schema, integration/workflow tests enforce restricted DML/audit permissions |
| Docker/Compose | PASS | `docker compose up -d --wait db`; `DOCKER_CONFIG=/tmp/response-final-docker-config IMAGE_TAG=response-final:rc2 bash scripts/build-container.sh` |
| Built container smoke/recovery | PASS, exit 0 | `node .local/final-master/container-smoke.mjs` (ignored local probe; details below) |
| Offline template variants | PASS, all synth/assertions exit 0 | Academic, reference, optional receipts; commands below |
| Actual academic helper including analytics | PASS, synth/assertions exit 0 | `npm run cloud:plan`; `node --import tsx scripts/verify-infra.ts cdk.out/academic/DisasterResponse-academic.template.json` |
| Optional identity-only template | PASS, synth exit 0 | `node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/identity.ts' --lookups=false --quiet --output cdk.out/final-identity` |
| Dependency audit | PASS at high threshold, two moderate findings remain | `npm audit --omit=dev --audit-level=high --cache .local/npm-cache` |
| Fresh release extraction/install/tests | Recorded against exact archive in adjacent verification JSON | Independent fresh directory, locked install, focused/full/browser/static/build/infra checks before publication |
| Live AWS identity | BLOCKED | Read-only STS: missing profile, then ExpiredToken with existing environment credentials |
| Live services/Windows/physical GPS/load/RDS restore | NOT RUN | External gates, not implied by local or stubbed-provider tests |

Focused/full commands used `TEST_DATABASE_URL` for the dedicated test database; browser commands used its separate `DATABASE_URL`, `APP_ORIGIN=http://localhost:5173`, `API_ORIGIN=http://localhost:4000`, `CI=1`. All pre-existing assertions remain. Browser geolocation is simulated explicitly in Chromium; no physical GPS or native background tracking is claimed.

Offline subprocesses remove inherited `AWS_*`/`CDK_*`, set `AWS_EC2_METADATA_DISABLED=true`, `AWS_CONFIG_FILE=/dev/null`, `AWS_SHARED_CREDENTIALS_FILE=/dev/null`, and use a writable npm cache. Exact template commands:

```bash
node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/app.ts' --lookups=false --quiet -c offlinePreview=true -c hosting=academic --output cdk.out/final-academic
node --import tsx scripts/verify-infra.ts cdk.out/final-academic/DisasterResponse-academic.template.json
node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/app.ts' --lookups=false --quiet -c offlinePreview=true --output cdk.out/final-reference
node --import tsx scripts/verify-infra.ts cdk.out/final-reference/DisasterResponse-dev.template.json
node node_modules/aws-cdk/bin/cdk synth --app 'node --import tsx infra/app.ts' --lookups=false --quiet -c offlinePreview=true -c hosting=academic -c smsDeliveryLogs=sns/ap-south-1/123456789012/DirectPublishToPhoneNumber --output cdk.out/final-receipts
node --import tsx scripts/verify-infra.ts cdk.out/final-receipts/DisasterResponse-academic.template.json
```

The receipt account/log input is synthetic. No cloud lookup/deploy, production migration or billable query ran. CDK feature-flag/deprecation notices, Vite's large MapLibre chunk warning and Playwright color-environment warnings remain; they did not fail checks.

Docker image: `sha256:a539fbf60cd91895283fb168e6f04648a3a341a64ac77b92cfac5c4797e7f2a7`, Linux/amd64, Node 22, nonroot `node`. The probe uses Linux host networking solely because demo API is loopback-bound; this is not a Windows host-network claim. It runs the compiled migrator twice against a new database, seeds explicitly, checks demo cookies (including both Fire identities and cross-department rejection), API liveness/readiness and existing local smoke, persists a dispatch deadline, stops/restarts the actual worker container, verifies control-room review without fabricated dispatch, closes the incident transactionally, temporarily renames a required index to obtain redacted readiness 503/liveness 200 and worker pause, restores it, and verifies API restart/healthy status/graceful shutdown. An induced `worker_tick_failed` is expected. Only probe-owned containers were stopped/removed. The scratch harness is not a shipped script; reproducible behavior assertions are in the shipped suites.

Initial regression: missing Fire login reproduced 1 failure with 8 cases deliberately unselected by the diagnostic `-t` filter. After fixtures, 5 failed/4 passed because the new test harness repeatedly recreated PostGIS within pooled backends (`no spatial operator found for st_covers`). Resetting isolated test rows while keeping extension OIDs stable corrected the harness. Nine cases then passed; the added seed-upgrade case brings the final file to ten. The first expanded full run passed 281/281 before that extra test; the final full run passed 282/282. These diagnostic failures/unselected cases are not presented as passing tests or permanent skips.

## AWS service classification

No service is classified as live-verified in this task.

| Service/function | Implementation classification | Actual evidence / boundary |
|---|---|---|
| Cognito registration/login/MFA/refresh/recovery | Implemented, not live-tested | Pool/client/redirect/PKCE/session verification code and tests; real account email/MFA acceptance required. Local demo is separate. |
| RDS PostgreSQL/PostGIS | Implemented, not live-tested | Private/encrypted template, TLS/runtime secrets/grants/migrations; actual local PostGIS exercised. Live RDS versions/TLS/restore/networking unverified. |
| S3 evidence | Implemented, not live-tested; security hardening partial | Private/encrypted/versioned bucket, bounded signed uploads/finalization/scoped downloads; SDK stubs only. Full image decoding/malware/EXIF processing absent. |
| Amazon Location | Implemented, not live-tested | Map/place/route proxy and resource permissions; explicit unavailable fallback. Browser GPS and PostGIS scope/matching work without it. |
| SNS/SQS | Implemented, not live-tested | Outbox/event consumption, idempotency, retries, DLQ and partial batch handling tested locally/stubbed. In-app notifications are real DB records; local external delivery is SIMULATED. |
| Direct SMS | Partially implemented / disabled | Adapter/receipt handling exists; country registration/sender attributes/verified recipients/spend approval and direct-phone IAM are not configured. No SMS sent. |
| SES email | Optional implemented, not live-tested | Sender/recipient verification and live delivery required; no provider delivery receipt integration. |
| Lambda/Scheduler | Implemented, not live-tested | AWS worker/migrator/optional receipt handlers plus scheduled recovery and migration dependencies; local handler tests and synthesized templates. |
| ECS/Fargate/API routing | Implemented, not live-tested | Rebuilt nonroot local image and runtime checked; private ECS/ALB/API Gateway design synthesized. AWS worker is Lambda, not ECS. |
| Amplify frontend | Implemented, not live-tested | Static Vite build, same-origin rewrite, manual publication helper; provider cookie/proxy acceptance pending. |
| CloudWatch/Budgets | Implemented, not live-tested | Logs/retention/alarms/dashboard/budget template; real delivery/tag/cost behavior unverified. Alerts do not cap spending. |
| ACM/custom DNS | Not required for selected default-hostname release | Optional custom-domain reference requires existing verified domain/certificate. Managed default-hostname TLS not live-tested. |
| ECR/Secrets Manager | Implemented, not live-tested | Asset/runtime secret definitions and loader validation; no image push or secret retrieval in this task. |
| S3/Glue/Athena analytics | Implemented, not live-tested | Academic helper includes analytics; three dataset contracts locally tested, synth/assertions passed; no live query run. |
| CodeBuild/CodePipeline | Partial full-system delivery | Existing optional pipeline updates ECS only; migration/worker/frontend coordinated release remains manual. No pipeline triggered. |
| Browser push/native background GPS | Not implemented | Not required for the local foreground Medical/Fire release; do not imply support. |

## Security status and remaining deployment gates

No confirmed critical/high finding remains in the inspected changes/tests; no independent penetration test or blanket vulnerability-free claim is made. Two moderate dependency findings remain (CDK/nested minimatch glob amplification); npm suggests a forced breaking CDK downgrade, so the exact known lockfile is preserved pending compatible remediation. Source-level hardening concerns include broad worker evidence grants, image scanning/EXIF handling, per-process rate limits and a transparent local relay's ability to disguise remote fixture traffic. Low-severity usability/tooling concerns include large map bundles, historical documentation and native Windows/PowerShell validation pending. Never tunnel fixture ports.

Renew AWS access; verify effective SCP/IAM/quotas/credits and a cost-approved coordinated resource plan; conduct real Cognito/S3/Location/messaging/cookie/TLS/monitoring acceptance, RDS restore/reconciliation, device GPS and load/failover testing. These external checks cannot be completed with expired credentials or simulated providers. See AWS_DEPLOYMENT_PLAN.md for exact hosting and rollback actions. The deliverable is **locally verified source and a built release candidate**, not actually deployed, live-service verified or operationally production-ready.

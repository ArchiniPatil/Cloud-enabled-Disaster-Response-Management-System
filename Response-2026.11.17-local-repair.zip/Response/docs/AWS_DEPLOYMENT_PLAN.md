# AWS hosting plan for RC2 — approval required

This plan is prepared source, not an executed deployment. Region: `ap-south-1`. No AWS resource, IAM/SCP policy, production database or pipeline was modified. Current read-only STS checks on 10 November 2026 failed: the configured profile was missing; a subprocess using the existing direct environment credentials without that profile returned `ExpiredToken`. Credential values, account identifiers and principal details are not published. No service/quota inventory or billable API was called after these authentication failures.

## Prerequisites and current status

| Prerequisite | Status | Evidence / next action |
|---|---|---|
| Application and deployment source | READY for local review | Medical/Fire flows, runtime and offline checks; see FINAL_MASTER_REVIEW.md. |
| Current AWS identity/session | BLOCKED | Renew the intended CLI/SSO session securely and select an existing valid profile. Never paste credentials into chat/source. |
| Effective IAM and organization SCP | NOT VERIFIED | Earlier EC2 availability-zone and CloudFormation inventory denies are historical; current authentication failed before an effective-permission check. |
| Account plan, credits, spend and service eligibility | NOT VERIFIED | Do not reuse the historical credit balance or assume free services. Review Billing/Free Tier in the intended account. |
| Regional RDS engine/PostGIS, instance offerings and quotas | NOT VERIFIED | Verify RDS PostgreSQL 16/PostGIS, Fargate capacity, Lambda concurrency (worker reserves 2), VPC/NAT/EIP/ENI and Cognito/Location availability after access is restored. |
| CDK bootstrap and deployer roles | NOT VERIFIED | Inspect an existing CDKToolkit; bootstrap only if required and separately approved. |
| Default-hostname hosting design | READY as source | Amplify → HTTP API/VPC Link → private ALB → private ECS API → isolated RDS; AWS worker is Lambda with SQS/Scheduler. No custom domain purchase needed. |
| Live HTTPS/callbacks/cookies/health | NOT VERIFIED | Managed Amplify/API Gateway HTTPS; private internal HTTP is an existing academic tradeoff. Actual endpoints are known only after deployment. |
| Custom DNS/ACM reference option | NOT CONFIGURED / not required for selected academic path | Do not execute the paid/custom-domain reference by accident. |
| Production secrets and initial admin | NOT CONFIGURED in a live deployment | CDK generates database/session secrets; Cognito enrollment and guarded admin bootstrap follow deployment. Never seed fixtures in AWS. |
| Restore, alarms, provider acceptance and load | NOT VERIFIED | Required before operational approval. |

An explicit SCP deny cannot be overridden with IAM AdministratorAccess. The authorized organization management/delegated policy administrator must inspect every effective SCP attached to the account/OU/root, identify the denying statement and conditions, and approve a narrowly scoped exception or policy correction for the intended account/role/region, including `ec2:DescribeAvailabilityZones` where appropriate. If an AWS-managed plan restriction is involved, contact AWS Support/account administration about permitted services. Do not detach organization protections, switch accounts/regions/providers to evade them, or upgrade the billing plan automatically. Confirm the exact operation again with a read-only call after renewal; one denied read does not prove all writes are denied.

The deployer needs approved CloudFormation/CDK bootstrap and asset publication permissions; ECR and S3 asset access; creation/passing of reviewed IAM roles; and provisioning permissions for EC2 networking, RDS, Secrets Manager, Cognito, ECS/ELB, Lambda, SNS/SQS/Scheduler, Amplify/API Gateway, Location, CloudWatch and Budgets. The academic helper also selects S3/Glue/Athena analytics. The existing detailed role inventory is in DEPLOYMENT_READINESS_REVIEW.md. API/runtime secrets are separate from the migration owner secret; runtime DB grants exclude schema and immutable-audit mutation. Source permissions are not evidence of effective permissions under SCPs/boundaries.

## Ordered procedure — run only after separate deployment approval

1. Extract RC2, use Node 24 LTS, install the exact lockfile and restore the public trust bundle:

```powershell
npm ci --cache .local/npm-cache
node scripts/fetch-rds-ca.mjs
npm run typecheck
npm run lint
npm run build
```

Run the documented tests against disposable local `_test` databases as described in TESTING.md. Never set TEST_DATABASE_URL to RDS or operational data. Proxy-only environments may require Node 24's `NODE_USE_ENV_PROXY=1` and an administrator-approved CA; never disable certificate verification.

2. Renew access using your organization's approved CLI/SSO method. Select your actual profile and region in the terminal. Read-only checks:

```powershell
$env:AWS_REGION = 'ap-south-1'
$env:AWS_DEFAULT_REGION = 'ap-south-1'
aws sts get-caller-identity --region ap-south-1
aws ec2 describe-availability-zones --region ap-south-1 --query 'AvailabilityZones[].{Name:ZoneName,State:State}'
aws cloudformation describe-stacks --stack-name CDKToolkit --region ap-south-1
aws cloudformation describe-stacks --stack-name DisasterResponse-academic --region ap-south-1
```

A nonexistent stack is distinct from AccessDenied. Stop on identity/policy failures. Inspect relevant quotas/service eligibility and costs through the console or approved read-only APIs. Do not retrieve secret values or dump task/Lambda environments into reports.

3. Preview the coordinated source plan offline:

```powershell
npm run cloud:plan
node --import tsx scripts/verify-infra.ts cdk.out/academic/DisasterResponse-academic.template.json
```

This helper includes analytics; the optional pipeline/SES configurations are selected only when their corresponding configuration is provided. Review the generated resources and IAM changes, current account inventory and existing-data migration/backup plan. Public RC2 defaults to **no deployment approval**. An operator must record the separately approved credit allowance/window in `config/academic-deployment.json`, leaving cash spending and account upgrades disabled. This is operational configuration, not a missing application implementation. Never reuse someone else's recorded approval.

4. If an existing deployment/database is found: schedule maintenance, stop incompatible writers/consumers, retain matched previous secure artifacts and take an approved recoverable backup/snapshot. Verify a restore to a separate database before production cutover. Backup/restore can incur costs and was not performed here. Do not assume a schema migration dependency automatically stops old worker invocations.

5. After approval, bootstrap only if the inspected bootstrap is absent/incompatible:

```powershell
$account = aws sts get-caller-identity --query Account --output text
if ($LASTEXITCODE -ne 0 -or $account -notmatch '^\d{12}$') { throw 'Identity verification failed' }
npx cdk bootstrap "aws://$account/ap-south-1"
```

6. Set the approved budget contact and explicit deployment gate in your terminal, then deploy the coordinated stack:

```powershell
$env:AWS_BUDGET_EMAIL = 'your-alert-email@example.com' # replace with the approved contact
$env:APPROVE_ACADEMIC_DEPLOYMENT = 'REVIEWED_CREDIT_FUNDED_DEMO'
npm run cloud:deploy
```

These are resource-creating, cost-incurring commands and were **NOT RUN**. The helper separately requires `provisioningApproved=true` and a positive approved credit allowance in the policy. It builds/publishes assets and writes `.local/academic-outputs.json`. The migration custom resource installs 001–008 and restricted runtime grants before API/new worker dependencies become active. No new migration is required for RC2; the new demo fixtures are never part of cloud migration. The default API runs production Cognito mode. Do not call `db:seed` in AWS.

7. Publish the matching frontend manually (PowerShell):

```powershell
./scripts/publish-frontend.ps1 -OutputsFile .local/academic-outputs.json
```

The helper checks live stack outputs, builds/uploads the frontend to Amplify `dev`, waits and probes readiness. The optional existing pipeline updates ECS only; it does not deploy the database schema, worker Lambda or frontend. Do not use it as a substitute for this coordinated release.

8. Follow AWS_WINDOWS_DEPLOYMENT.md for real Cognito registration, verified email/TOTP, first-admin bootstrap using the actual migration-function output, scoped operational invitations and configuration. Configure evidence/maps/email only with verified outputs and provider permissions. Keep SMS disabled; do not contact emergency services. Confirm budget/operations email subscriptions.

9. Validate live frontend/API readiness independently from liveness; Cognito registration/login/MFA/refresh/logout; role/jurisdiction isolation; Medical/Fire dispatch with consenting test users; real S3 upload/finalization/privacy; Location access; SQS retry/DLQ/Scheduler; worker heartbeat and persisted deadlines; alarm delivery; RDS TLS/runtime grants and restore. Provider variable presence or local stubs cannot satisfy these checks. Physical-device GPS and load/failover remain separate acceptance work.

## Rollback and cost control

Stop writes/consumers on a failed rollout, preserve diagnostics and prefer a forward fix. Keep matched previous security-fixed API, worker and frontend artifacts. An ECS image rollback does not reverse SQL or worker/frontend changes. Never remove migration-ledger rows or reverse migrations 001–008. If a database restore is required, restore into a separate instance, validate schema/TLS/grants and reconcile post-backup events/evidence before an explicit connection cutover. Retain the failed database until reviewed retention decisions are made. Live rollback/restore has not been verified.

Planning estimate only, not a current AWS price quote: **roughly US$100–180/month** for a continuously running small academic stack, or approximately **US$5–15 for a light one-day exercise** with promptly removed stateless resources. Assumptions: 730 hours/month, one NAT gateway, one internal ALB, one 0.25-vCPU/0.5-GiB task (occasional second task), one single-AZ db.t4g.micro with 20-GiB storage, modest logs/storage/traffic, no SMS/domain purchase, no sustained builds or large analytics scans.

| Approximate monthly component | Planning range (USD) |
|---|---:|
| NAT/public IPv4 | 40–60 |
| ALB | 20–35 |
| Fargate API compute | 10–20 |
| RDS compute/storage | 20–40 |
| Secrets/logs/light auxiliary usage | 5–20 |

Actual Mumbai prices, taxes, data transfer, RDS CPU credits/backups, ALB/NAT traffic, Amplify transfer/builds, Location requests, Cognito features, ECR, Lambda/SNS/SQS/Scheduler, Athena scans and optional pipeline/SES can exceed these allowances. Verify in the AWS Pricing Calculator before approval. Credits are not guaranteed to cover every service or last until teardown. The configured budget is an alert, **not a spending cap**; the 24-hour field is not an automatic shutdown. Assign a teardown owner and reminder. Retained RDS/snapshots, buckets/versions, identity pools, ECR images, logs, secrets and bootstrap assets can keep charging after app use or stack deletion. No teardown command is authorized by this plan.

import { loadEnvFile } from "node:process";
import { fileURLToPath } from "node:url";
import {
  existsSync,
  mkdirSync,
  openSync,
  closeSync,
  readFileSync,
  copyFileSync,
  writeFileSync,
  statSync,
} from "node:fs";
import { spawnSync } from "node:child_process";
import { createConnection } from "node:net";
import { createHash } from "node:crypto";
import { assertLocalDemoRepair } from "./local-demo-fixtures.ts";
import { parseConfig } from "../apps/api/src/config-validation.ts";

process.chdir(fileURLToPath(new URL("..", import.meta.url)));
function command(cmd, args, options = {}) {
  const result = spawnSync(cmd, args, {
    encoding: "utf8",
    timeout: 120000,
    ...options,
  });
  if (result.error || result.status !== 0)
    throw new Error(
      `${cmd === process.execPath ? "Repair process" : cmd} failed; operation stopped. No credential output is displayed.`,
    );
  return result.stdout?.trim() ?? "";
}
function occupied(port) {
  return new Promise((resolve) => {
    const socket = createConnection({ host: "127.0.0.1", port });
    socket.setTimeout(1000);
    socket.once("connect", () => {
      socket.destroy();
      resolve(true);
    });
    socket.once("error", (error) => {
      socket.destroy();
      resolve(error.code !== "ECONNREFUSED");
    });
    socket.once("timeout", () => {
      socket.destroy();
      resolve(true);
    });
  });
}
try {
  if (!existsSync(".env.demo"))
    throw new Error(
      "Missing .env.demo; use the supplied updater to prepare the verified local template without overwriting existing configuration.",
    );
  loadEnvFile(".env.demo");
  assertLocalDemoRepair(process.env);
  const config = parseConfig(process.env);
  if (config.NOTIFICATION_TRANSPORT !== "simulator")
    throw new Error("Local repair requires the notification simulator.");
  if ((await occupied(config.PORT)) || (await occupied(5173)))
    throw new Error(
      "Close the running application terminals first. The database must remain running; no process was stopped automatically.",
    );
  const context = command("docker", ["context", "show"]);
  const endpoint =
    process.env.DOCKER_HOST ||
    command("docker", [
      "context",
      "inspect",
      context,
      "--format",
      "{{.Endpoints.docker.Host}}",
    ]);
  if (!endpoint.startsWith("unix://") && !endpoint.startsWith("npipe://"))
    throw new Error(
      "Repair requires a local Docker socket or Windows named pipe.",
    );
  const url = new URL(config.DATABASE_URL);
  const port = url.port || "5432";
  const candidates = command("docker", [
    "ps",
    "--filter",
    `publish=${port}`,
    "--format",
    "{{.Names}}",
  ])
    .split(/\r?\n/)
    .filter(Boolean)
    .filter((name) =>
      command("docker", ["port", name, "5432/tcp"])
        .split(/\r?\n/)
        .some((p) => p === `127.0.0.1:${port}` || p === `[::1]:${port}`),
    );
  if (candidates.length !== 1)
    throw new Error(
      "Exactly one existing loopback-published PostgreSQL container must match .env.demo. No container or volume was created.",
    );
  const container = candidates[0],
    user = decodeURIComponent(url.username),
    database = decodeURIComponent(url.pathname.slice(1));
  if (
    !/^[A-Za-z_][A-Za-z0-9_-]*$/.test(user) ||
    !/^[A-Za-z_][A-Za-z0-9_-]*$/.test(database)
  )
    throw new Error("Unsupported local database identifier; repair stopped.");
  const dir = `.local/backups/demo-repair-${new Date().toISOString().replace(/[:.]/g, "-")}`;
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  copyFileSync(".env.demo", `${dir}/env.demo.backup`);
  const dump = `${dir}/database.sql`,
    fd = openSync(dump, "wx", 0o600);
  try {
    command(
      "docker",
      [
        "exec",
        container,
        "pg_dump",
        "-U",
        user,
        "-d",
        database,
        "--no-owner",
        "--no-privileges",
      ],
      { stdio: ["ignore", fd, "pipe"] },
    );
  } finally {
    closeSync(fd);
  }
  if (
    !statSync(dump).size ||
    !readFileSync(dump, "utf8").includes("PostgreSQL database dump complete")
  )
    throw new Error(
      "Backup verification failed; database repair was not attempted.",
    );
  writeFileSync(
    `${dir}/backup.json`,
    JSON.stringify(
      {
        sha256: createHash("sha256").update(readFileSync(dump)).digest("hex"),
        bytes: statSync(dump).size,
        createdAt: new Date().toISOString(),
        note: "Private logical database backup; no roles or grants. Do not publish. Restore only to a separate local database for validation.",
      },
      null,
      2,
    ),
    { mode: 0o600 },
  );
  console.log(`Private database/configuration backup verified: ${dir}`);
  command(process.execPath, ["--import", "tsx", "scripts/repair-demo.ts"], {
    stdio: "inherit",
  });
  console.log(
    "Repair complete. Run npm run dev:demo in this folder. Choose Pune Medical or Pune Fire Authority for the existing reports; responders still require explicit duty/GPS consent and an assignment offer.",
  );
} catch (error) {
  console.error(
    error instanceof Error ? error.message : "Local repair stopped.",
  );
  process.exitCode = 1;
}

import {
  assertLocalDemoRepair,
  addLocalDemoFixtures,
} from "./local-demo-fixtures.js";
assertLocalDemoRepair(process.env);
// Dynamic imports keep forbidden modes away from DB/secret initialization.
const { pool, transaction, audit } = await import("../apps/api/src/db.js");
const { assertSchemaReady } =
  await import("../apps/api/src/schema-readiness.js");
try {
  await transaction(async (db) => {
    await assertSchemaReady(db);
    await addLocalDemoFixtures(db);
    await audit(
      db,
      null,
      "LOCAL_DEMO_FIXTURES_REPAIRED",
      "configuration",
      "pune-local-exercise-v1",
      { source: "explicit-local-repair" },
    );
  });
  console.log(
    "Local fixtures ready: Mumbai preserved; Pune Medical and Fire accounts available. Reports, assignments, duty and GPS were not changed.",
  );
} catch {
  console.error(
    "Local fixture repair failed and was rolled back. Check existing fixture scope, schema, organization and qualification status; no credentials are printed.",
  );
  process.exitCode = 1;
} finally {
  await pool.end();
}

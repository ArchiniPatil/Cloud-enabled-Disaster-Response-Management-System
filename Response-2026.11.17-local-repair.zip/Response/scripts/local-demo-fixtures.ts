import type { PoolClient } from "pg";

// Deliberately bounded fictional exercises, never administrative boundaries.
export const puneExerciseBounds = [73.75, 18.4, 74.0, 18.65] as const;
export function assertLocalDemoRepair(env: Record<string, string | undefined>) {
  let local = false;
  try {
    const url = new URL(env.DATABASE_URL ?? "");
    local =
      ["postgres:", "postgresql:"].includes(url.protocol) &&
      ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname) &&
      !url.search &&
      !url.hash &&
      url.pathname.length > 1;
  } catch {
    /* Refuse before connecting or retrieving any secret. */
  }
  if (
    env.AUTH_MODE !== "demo" ||
    !["development", "test"].includes(env.NODE_ENV ?? "development") ||
    !local ||
    env.DATABASE_SECRET_ARN ||
    env.SESSION_SECRET_ARN
  )
    throw new Error(
      "Repair requires explicit local demo configuration; production, Cognito and secret-backed databases are forbidden.",
    );
}

// Caller owns the transaction. Never update existing scope, duty, GPS or reports.
export async function addLocalDemoFixtures(db: Pick<PoolClient, "query">) {
  await db.query("SELECT pg_advisory_xact_lock(hashtext('demo-seed'))");
  const org = (
    await db.query(
      "SELECT id FROM organizations WHERE name='Demonstration response organization' AND active",
    )
  ).rows[0];
  if (!org)
    throw new Error(
      "Existing active demo organization required; no records changed.",
    );
  const specs = [
    {
      jurisdiction: "Fictional fire exercise area (Mumbai coordinates)",
      bounds: [72.7, 18.8, 73.1, 19.4],
      department: "Fire and Rescue",
      authority: "fire-authority",
      rescuer: "fire-rescuer",
      team: "Fire 01 — Demo",
      capability: "FIRE",
    },
    {
      jurisdiction: "Pune local exercise area (fictional)",
      bounds: puneExerciseBounds,
      department: "Medical / Ambulance",
      authority: "pune-medical-authority",
      rescuer: "pune-medical-rescuer",
      team: "Pune Medic 01 — Demo",
      capability: "FIRST_AID",
    },
    {
      jurisdiction: "Pune local exercise area (fictional)",
      bounds: puneExerciseBounds,
      department: "Fire and Rescue",
      authority: "pune-fire-authority",
      rescuer: "pune-fire-rescuer",
      team: "Pune Fire 01 — Demo",
      capability: "FIRE",
    },
  ];
  for (const s of specs) {
    const department = (
      await db.query("SELECT id FROM departments WHERE name=$1", [s.department])
    ).rows[0];
    if (!department)
      throw new Error("Required demo department missing; no records changed.");
    const j =
      (
        await db.query(
          "SELECT id,ST_Equals(boundary,ST_Multi(ST_MakeEnvelope($2,$3,$4,$5,4326))) AS matches FROM jurisdictions WHERE name=$1",
          [s.jurisdiction, ...s.bounds],
        )
      ).rows[0] ??
      (
        await db.query(
          "INSERT INTO jurisdictions(name,boundary) VALUES($1,ST_Multi(ST_MakeEnvelope($2,$3,$4,$5,4326))) RETURNING id,true AS matches",
          [s.jurisdiction, ...s.bounds],
        )
      ).rows[0];
    if (!j.matches)
      throw new Error(
        "Existing exercise boundary differs; refusing to overwrite customized coverage.",
      );
    const users: Record<string, string> = {};
    for (const [alias, role] of [
      [s.authority, "AUTHORITY"],
      [s.rescuer, "RESCUER"],
    ]) {
      const email = `${alias}@demo.invalid`;
      const u =
        (await db.query("SELECT * FROM user_profiles WHERE email=$1", [email]))
          .rows[0] ??
        (
          await db.query(
            "INSERT INTO user_profiles(cognito_sub,email,name,role,department_id,jurisdiction_id) VALUES($1,$2,$3,$4,$5,$6) RETURNING *",
            [
              `demo:${alias}`,
              email,
              `${s.team} ${role === "AUTHORITY" ? "coordinator" : "responder"}`,
              role,
              department.id,
              j.id,
            ],
          )
        ).rows[0];
      if (
        u.cognito_sub !== `demo:${alias}` ||
        u.role !== role ||
        u.status !== "ACTIVE" ||
        u.department_id !== department.id ||
        u.jurisdiction_id !== j.id
      )
        throw new Error(
          "An existing fixture identity has customized scope/status; repair stopped without overwriting it.",
        );
      users[role] = u.id;
    }
    for (const permission of ["DISPATCH", "ANNOUNCE"])
      await db.query(
        "INSERT INTO user_permissions VALUES($1,$2) ON CONFLICT DO NOTHING",
        [users.AUTHORITY, permission],
      );
    const teams = (
      await db.query("SELECT * FROM rescue_teams WHERE name=$1", [s.team])
    ).rows;
    if (teams.length > 1)
      throw new Error("Ambiguous demo team name; no records changed.");
    const t =
      teams[0] ??
      (
        await db.query(
          "INSERT INTO rescue_teams(name,organization_id,department_id,jurisdiction_id,vehicle) VALUES($1,$2,$3,$4,'Fictional local exercise vehicle') RETURNING *",
          [s.team, org.id, department.id, j.id],
        )
      ).rows[0];
    if (
      t.organization_id !== org.id ||
      t.department_id !== department.id ||
      t.jurisdiction_id !== j.id
    )
      throw new Error("Existing team scope differs; refusing to overwrite it.");
    const memberships = (
      await db.query("SELECT team_id FROM team_memberships WHERE user_id=$1", [
        users.RESCUER,
      ])
    ).rows;
    if (memberships.some((m) => m.team_id !== t.id))
      throw new Error(
        "Fixture responder already belongs to another team; no records changed.",
      );
    await db.query(
      "INSERT INTO team_memberships VALUES($1,$2) ON CONFLICT DO NOTHING",
      [t.id, users.RESCUER],
    );
    const capability = (
      await db.query(
        "SELECT expires_at FROM team_capabilities WHERE team_id=$1 AND capability=$2",
        [t.id, s.capability],
      )
    ).rows[0];
    if (
      capability?.expires_at &&
      new Date(capability.expires_at).getTime() <= Date.now()
    )
      throw new Error(
        "Existing qualification expired; repair will not renew it automatically.",
      );
    await db.query(
      "INSERT INTO team_capabilities(team_id,capability) VALUES($1,$2) ON CONFLICT DO NOTHING",
      [t.id, s.capability],
    );
  }
}
